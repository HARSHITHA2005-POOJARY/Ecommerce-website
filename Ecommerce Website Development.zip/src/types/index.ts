export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  discount?: number;
  category: string;
  image: string;
  rating: number;
  reviews: number;
  inStock: boolean;
  brand: string;
  tags?: string[];
  sellerId?: string;
  sellerName?: string;
  stock?: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  role?: 'customer' | 'admin' | 'seller';
}

export interface Seller {
  id: string;
  name: string;
  email: string;
  businessName: string;
  phone: string;
  gst?: string;
  commission: number; // Percentage (e.g., 15 means 15%)
  bankDetails?: {
    accountNumber: string;
    ifsc: string;
    accountHolderName: string;
  };
  address: string;
  approved: boolean;
  createdAt: Date;
  totalSales: number;
  totalCommission: number;
}

export interface Employee {
  id: string;
  name: string;
  email: string;
  password?: string;
  phone: string;
  designation: string;
  department: string;
  joiningDate: Date;
  salary: number;
  status: 'active' | 'inactive';
  approved: boolean; // Employee must be approved by admin to login
  address: string;
  emergencyContact: {
    name: string;
    phone: string;
    relation: string;
  };
  // Attendance schedule
  schedule?: {
    checkInTime: string; // e.g., "09:00"
    checkOutTime: string; // e.g., "18:00"
    workingDays: number[]; // 0-6 (Sunday-Saturday)
  };
}

export interface Attendance {
  id: string;
  employeeId: string;
  employeeName: string;
  date: Date;
  status: 'present' | 'absent' | 'half-day' | 'leave';
  checkIn?: string;
  checkOut?: string;
  remarks?: string;
  isLate?: boolean; // If checked in after scheduled time
  isEarly?: boolean; // If checked out before scheduled time
}

export interface Address {
  id: string;
  name: string;
  phone: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  state: string;
  pincode: string;
  isDefault: boolean;
}

export interface Order {
  id: string;
  orderId: string;
  userId: string;
  userName: string;
  userEmail: string;
  items: CartItem[];
  total: number;
  status: 'pending' | 'confirmed' | 'shipped' | 'delivered' | 'cancelled';
  address: Address;
  createdAt: Date;
  deliveryDate?: Date;
  paymentMethod?: string;
  trackingNumber?: string;
}