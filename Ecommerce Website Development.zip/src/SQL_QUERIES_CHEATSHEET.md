# 🔍 SQL Queries Cheatsheet for ShopHub Database

Use these queries in the **Supabase SQL Editor** to analyze your database.

---

## 📊 Audit Log Queries

### Get All Recent Audit Logs
```sql
SELECT * FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
ORDER BY key DESC 
LIMIT 100;
```

### Get Logs from Today
```sql
SELECT * FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND (value->>'timestamp')::timestamp::date = CURRENT_DATE
ORDER BY value->>'timestamp' DESC;
```

### Get Logs from Specific Date
```sql
SELECT * FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND (value->>'timestamp')::timestamp::date = '2024-12-11'
ORDER BY value->>'timestamp' DESC;
```

### Get Logs from Date Range
```sql
SELECT * FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND (value->>'timestamp')::timestamp BETWEEN '2024-12-01' AND '2024-12-31'
ORDER BY value->>'timestamp' DESC;
```

---

## 👤 User Activity Queries

### Get All Actions by Specific User
```sql
SELECT 
  value->>'timestamp' as timestamp,
  value->>'action' as action,
  value->>'entityType' as entity_type,
  value->>'entityName' as entity_name,
  value->>'success' as success
FROM kv_store_6d108759 
WHERE key LIKE 'audit:user:USER_ID_HERE:%'
ORDER BY value->>'timestamp' DESC;
```

### Get User Login History
```sql
SELECT 
  value->>'timestamp' as login_time,
  value->>'userEmail' as email,
  value->>'ipAddress' as ip_address,
  value->>'success' as success
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND value->>'action' IN ('LOGIN', 'LOGIN_FAILED')
ORDER BY value->>'timestamp' DESC
LIMIT 50;
```

### Count Actions per User
```sql
SELECT 
  value->>'userEmail' as user_email,
  value->>'userRole' as user_role,
  COUNT(*) as action_count
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND value->>'userEmail' IS NOT NULL
GROUP BY value->>'userEmail', value->>'userRole'
ORDER BY action_count DESC;
```

### Most Active Users (Last 7 Days)
```sql
SELECT 
  value->>'userEmail' as user_email,
  COUNT(*) as actions,
  COUNT(CASE WHEN value->>'success' = 'true' THEN 1 END) as successful,
  COUNT(CASE WHEN value->>'success' = 'false' THEN 1 END) as failed
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND (value->>'timestamp')::timestamp > NOW() - INTERVAL '7 days'
AND value->>'userEmail' IS NOT NULL
GROUP BY value->>'userEmail'
ORDER BY actions DESC
LIMIT 20;
```

---

## 🔐 Security Queries

### Get All Failed Actions
```sql
SELECT 
  value->>'timestamp' as timestamp,
  value->>'action' as action,
  value->>'userEmail' as user,
  value->>'entityType' as entity,
  value->>'errorMessage' as error,
  value->>'ipAddress' as ip_address
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND value->>'success' = 'false'
ORDER BY value->>'timestamp' DESC;
```

### Get Failed Login Attempts
```sql
SELECT 
  value->>'timestamp' as timestamp,
  value->>'userEmail' as attempted_email,
  value->>'ipAddress' as ip_address,
  value->>'errorMessage' as error
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND value->>'action' = 'LOGIN_FAILED'
ORDER BY value->>'timestamp' DESC;
```

### Detect Suspicious Activity (Multiple Failed Logins)
```sql
SELECT 
  value->>'ipAddress' as ip_address,
  value->>'userEmail' as attempted_email,
  COUNT(*) as failed_attempts,
  MIN((value->>'timestamp')::timestamp) as first_attempt,
  MAX((value->>'timestamp')::timestamp) as last_attempt
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND value->>'action' = 'LOGIN_FAILED'
AND (value->>'timestamp')::timestamp > NOW() - INTERVAL '24 hours'
GROUP BY value->>'ipAddress', value->>'userEmail'
HAVING COUNT(*) > 3
ORDER BY failed_attempts DESC;
```

### After-Hours Activity (Outside 9 AM - 6 PM)
```sql
SELECT 
  value->>'timestamp' as timestamp,
  value->>'userEmail' as user,
  value->>'action' as action,
  value->>'entityType' as entity
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND (value->>'timestamp')::timestamp::date = CURRENT_DATE
AND (
  EXTRACT(HOUR FROM (value->>'timestamp')::timestamp) < 9
  OR EXTRACT(HOUR FROM (value->>'timestamp')::timestamp) >= 18
)
ORDER BY value->>'timestamp' DESC;
```

---

## 📦 Product Queries

### Get All Product Actions
```sql
SELECT 
  value->>'timestamp' as timestamp,
  value->>'action' as action,
  value->>'entityName' as product_name,
  value->>'userEmail' as user,
  value->>'success' as success
FROM kv_store_6d108759 
WHERE key LIKE 'audit:entity:PRODUCT:%'
ORDER BY value->>'timestamp' DESC;
```

### Product Modification History
```sql
SELECT 
  value->>'timestamp' as timestamp,
  value->>'action' as action,
  value->>'entityName' as product_name,
  value->>'userEmail' as modified_by,
  value->>'details' as details
FROM kv_store_6d108759 
WHERE key LIKE 'audit:entity:PRODUCT:PRODUCT_ID_HERE:%'
ORDER BY value->>'timestamp' DESC;
```

### Recently Added Products
```sql
SELECT 
  value->>'timestamp' as added_at,
  value->>'entityName' as product_name,
  value->>'userEmail' as added_by,
  value->>'details' as details
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND value->>'action' = 'PRODUCT_ADD'
ORDER BY value->>'timestamp' DESC
LIMIT 20;
```

### Deleted Products
```sql
SELECT 
  value->>'timestamp' as deleted_at,
  value->>'entityName' as product_name,
  value->>'userEmail' as deleted_by,
  value->>'details' as details
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND value->>'action' = 'PRODUCT_DELETE'
ORDER BY value->>'timestamp' DESC;
```

---

## 🛒 Order Queries

### Recent Orders
```sql
SELECT 
  value->>'timestamp' as order_time,
  value->>'entityName' as order_info,
  value->>'userEmail' as customer,
  value->>'details' as details
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND value->>'action' = 'ORDER_CREATE'
ORDER BY value->>'timestamp' DESC
LIMIT 50;
```

### Order Status Changes
```sql
SELECT 
  value->>'timestamp' as changed_at,
  value->>'entityName' as order_info,
  value->>'userEmail' as changed_by,
  value->>'details' as details
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND value->>'action' = 'ORDER_STATUS_CHANGE'
ORDER BY value->>'timestamp' DESC;
```

### Cancelled Orders
```sql
SELECT 
  value->>'timestamp' as cancelled_at,
  value->>'entityName' as order_info,
  value->>'userEmail' as cancelled_by,
  value->>'details' as details
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND value->>'action' = 'ORDER_CANCEL'
ORDER BY value->>'timestamp' DESC;
```

---

## 👥 Employee Queries

### Employee Attendance Today
```sql
SELECT 
  value->>'timestamp' as time,
  value->>'entityName' as employee_status,
  value->>'details' as details
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND value->>'action' = 'ATTENDANCE_MARK'
AND (value->>'timestamp')::timestamp::date = CURRENT_DATE
ORDER BY value->>'timestamp' DESC;
```

### Employee Actions History
```sql
SELECT 
  value->>'timestamp' as timestamp,
  value->>'action' as action,
  value->>'entityName' as employee_name,
  value->>'userEmail' as performed_by
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND value->>'action' LIKE 'EMPLOYEE_%'
ORDER BY value->>'timestamp' DESC;
```

### Attendance Summary (Last 30 Days)
```sql
SELECT 
  value->>'userEmail' as employee,
  value->>'details'->>'status' as status,
  COUNT(*) as count
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND value->>'action' = 'ATTENDANCE_MARK'
AND (value->>'timestamp')::timestamp > NOW() - INTERVAL '30 days'
GROUP BY value->>'userEmail', value->>'details'->>'status'
ORDER BY employee, status;
```

---

## 🏪 Seller Queries

### Seller Approvals
```sql
SELECT 
  value->>'timestamp' as approved_at,
  value->>'entityName' as seller_name,
  value->>'userEmail' as approved_by
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND value->>'action' = 'SELLER_APPROVE'
ORDER BY value->>'timestamp' DESC;
```

### Commission Changes
```sql
SELECT 
  value->>'timestamp' as changed_at,
  value->>'entityName' as seller_name,
  value->>'userEmail' as changed_by,
  value->>'details' as details
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND value->>'action' = 'COMMISSION_UPDATE'
ORDER BY value->>'timestamp' DESC;
```

---

## 📈 Statistics Queries

### Actions by Type (Count)
```sql
SELECT 
  value->>'action' as action_type,
  COUNT(*) as count,
  COUNT(CASE WHEN value->>'success' = 'true' THEN 1 END) as successful,
  COUNT(CASE WHEN value->>'success' = 'false' THEN 1 END) as failed
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
GROUP BY value->>'action'
ORDER BY count DESC;
```

### Actions by Entity Type
```sql
SELECT 
  value->>'entityType' as entity_type,
  COUNT(*) as count
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
GROUP BY value->>'entityType'
ORDER BY count DESC;
```

### Hourly Activity Pattern
```sql
SELECT 
  EXTRACT(HOUR FROM (value->>'timestamp')::timestamp) as hour,
  COUNT(*) as actions
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND (value->>'timestamp')::timestamp::date = CURRENT_DATE
GROUP BY hour
ORDER BY hour;
```

### Daily Activity (Last 30 Days)
```sql
SELECT 
  (value->>'timestamp')::timestamp::date as date,
  COUNT(*) as total_actions,
  COUNT(CASE WHEN value->>'success' = 'true' THEN 1 END) as successful,
  COUNT(CASE WHEN value->>'success' = 'false' THEN 1 END) as failed
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND (value->>'timestamp')::timestamp > NOW() - INTERVAL '30 days'
GROUP BY date
ORDER BY date DESC;
```

### Success Rate by Action
```sql
SELECT 
  value->>'action' as action,
  COUNT(*) as total,
  COUNT(CASE WHEN value->>'success' = 'true' THEN 1 END) as successful,
  ROUND(
    100.0 * COUNT(CASE WHEN value->>'success' = 'true' THEN 1 END) / COUNT(*),
    2
  ) as success_rate_percent
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
GROUP BY value->>'action'
HAVING COUNT(*) > 5
ORDER BY success_rate_percent ASC;
```

---

## 🧹 Maintenance Queries

### Count Total Audit Logs
```sql
SELECT COUNT(*) as total_audit_logs
FROM kv_store_6d108759 
WHERE key LIKE 'audit:%';
```

### Find Oldest and Newest Logs
```sql
SELECT 
  MIN((value->>'timestamp')::timestamp) as oldest_log,
  MAX((value->>'timestamp')::timestamp) as newest_log
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%';
```

### Storage Size by Key Prefix
```sql
SELECT 
  SUBSTRING(key FROM 1 FOR 20) as key_prefix,
  COUNT(*) as count,
  pg_size_pretty(SUM(LENGTH(value::text))::bigint) as size
FROM kv_store_6d108759 
GROUP BY key_prefix
ORDER BY COUNT(*) DESC;
```

### List Old Logs (Older than 90 days)
```sql
SELECT 
  key,
  value->>'timestamp' as timestamp
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND (value->>'timestamp')::timestamp < NOW() - INTERVAL '90 days'
ORDER BY value->>'timestamp';
```

---

## 🎯 Common Use Case Queries

### Who Modified This Specific Item?
```sql
-- Replace ENTITY_TYPE with: PRODUCT, ORDER, USER, etc.
-- Replace ENTITY_ID with actual ID
SELECT 
  value->>'timestamp' as when,
  value->>'action' as what,
  value->>'userEmail' as who,
  value->>'details' as details
FROM kv_store_6d108759 
WHERE key LIKE 'audit:entity:ENTITY_TYPE:ENTITY_ID:%'
ORDER BY value->>'timestamp' DESC;
```

### What Did User X Do Today?
```sql
-- Replace USER_EMAIL with actual email
SELECT 
  value->>'timestamp' as time,
  value->>'action' as action,
  value->>'entityType' as entity,
  value->>'entityName' as item,
  value->>'success' as success
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND value->>'userEmail' = 'USER_EMAIL'
AND (value->>'timestamp')::timestamp::date = CURRENT_DATE
ORDER BY value->>'timestamp' DESC;
```

### System Health Check
```sql
SELECT 
  'Total Actions' as metric,
  COUNT(*)::text as value
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND (value->>'timestamp')::timestamp > NOW() - INTERVAL '24 hours'

UNION ALL

SELECT 
  'Failed Actions' as metric,
  COUNT(*)::text as value
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND value->>'success' = 'false'
AND (value->>'timestamp')::timestamp > NOW() - INTERVAL '24 hours'

UNION ALL

SELECT 
  'Unique Users' as metric,
  COUNT(DISTINCT value->>'userEmail')::text as value
FROM kv_store_6d108759 
WHERE key LIKE 'audit:2%'
AND (value->>'timestamp')::timestamp > NOW() - INTERVAL '24 hours'
AND value->>'userEmail' IS NOT NULL;
```

---

## 💡 Pro Tips

1. **Replace placeholders**: Change `USER_ID_HERE`, `PRODUCT_ID_HERE`, etc. with actual values
2. **Adjust time ranges**: Modify `INTERVAL '7 days'` to your needs
3. **Limit results**: Add `LIMIT 100` to large queries
4. **Export results**: Use Supabase's export button to save as CSV
5. **Save frequently used queries**: Bookmark them in Supabase
6. **Use indexes**: If queries are slow, consider adding indexes
7. **Regular cleanup**: Delete old logs to maintain performance

---

## 📚 JSON Field Access

Access nested JSON fields using `->` and `->>`:

```sql
-- Get nested field as text
value->>'details'->>'price'

-- Get nested object
value->'details'

-- Get array element
value->'tags'->0
```

---

**Need More Help?**
- See full documentation: `/DATABASE_AUDIT_GUIDE.md`
- Quick reference: `/HOW_TO_CHECK_DATABASE.md`
- Admin Dashboard: Audit Logs tab for visual interface
