# ShopHub - Setup Modes

✅ **Good News**: Your application now works in **TWO MODES**:

## 🟢 Mode 1: LocalStorage Mode (Currently Active)

**Status**: ✅ Working right now!

The app automatically falls back to using browser localStorage when the backend isn't available. This means:

- ✅ You can add employees
- ✅ You can mark attendance
- ✅ You can manage products
- ✅ All data is saved in your browser
- ✅ **Employee login works** (uses email only - any password accepted)
- ⚠️ Data is temporary (cleared when you clear browser data)
- ⚠️ No real password validation in this mode
- ⚠️ Data won't sync across devices

**You can use the app right now!** Just:
1. Login as admin (or create an admin account)
2. Go to Admin Dashboard
3. Add employees with schedules
4. Employees can login using just their email (password field can be anything)
5. Mark attendance and view payroll

---

## 🔵 Mode 2: Full Backend Mode (Requires Setup)

**Status**: ⏳ Requires backend server setup

When you set up the backend, you get:

- ✅ Persistent data storage in PostgreSQL
- ✅ Employee login/logout functionality
- ✅ Real-time data sync
- ✅ Multiple user sessions
- ✅ Production-ready features

### How to Enable Backend Mode:

#### Step 1: Navigate to Backend Directory
```bash
cd backend
```

#### Step 2: Install Dependencies
```bash
npm install
```

#### Step 3: Set Up Environment Variables

Create a `.env` file in the `/backend` directory:

```env
DATABASE_URL="postgresql://username:password@localhost:5432/shophub?schema=public"
JWT_SECRET="your-super-secret-jwt-key-change-this-in-production"
PORT=5000
```

Replace `username` and `password` with your PostgreSQL credentials.

#### Step 4: Run Database Migrations
```bash
npx prisma migrate dev
```

This creates the database tables and applies the schema.

#### Step 5: (Optional) Seed Sample Data
```bash
npm run seed
```

This adds sample products and admin user.

#### Step 6: Start the Backend Server
```bash
npm run dev
```

You should see:
```
🚀 Server running on port 5000
✅ Database connected successfully
```

#### Step 7: Refresh Your Browser

Once the backend is running, the app will automatically switch from localStorage mode to backend mode!

---

## How to Check Which Mode You're In

- If you see "Backend not available, falling back to localStorage" in the browser console, you're in LocalStorage mode
- If API calls succeed without errors, you're in Backend mode
- LocalStorage mode: Data saved in browser only
- Backend mode: Data saved in PostgreSQL database

---

## Troubleshooting

### Backend Won't Start

**PostgreSQL not running?**
```bash
# Mac (Homebrew)
brew services start postgresql

# Linux
sudo systemctl start postgresql

# Windows - Check Services app
```

**Port 5000 already in use?**

Change the PORT in your backend `.env` file to something else like 5001.

### App Still Using LocalStorage

- Make sure backend server is running on `http://localhost:5000`
- Check browser console for connection errors
- Try refreshing the page
- Clear browser cache if needed

---

## What's Already Working

✅ All React components fixed (forwardRef warnings resolved)  
✅ Dialog accessibility (DialogDescription added)  
✅ Automatic localStorage fallback  
✅ Error handling for network issues  
✅ Employee management UI  
✅ Attendance tracking  
✅ Payroll calculations  

You're all set to use the app! Backend setup is optional for testing.