import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  signup: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('user');
    return saved ? JSON.parse(saved) : null;
  });

  const checkIfSeller = (email: string): boolean => {
    const sellers = localStorage.getItem('sellers');
    if (sellers) {
      const sellerList = JSON.parse(sellers);
      return sellerList.some((s: any) => s.email === email && s.approved);
    }
    return false;
  };

  useEffect(() => {
    if (user) {
      localStorage.setItem('user', JSON.stringify(user));
    } else {
      localStorage.removeItem('user');
    }
  }, [user]);

  const login = async (email: string, password: string) => {
    // Mock login - In real app, this would call an API
    await new Promise((resolve) => setTimeout(resolve, 1000));
    
    // Check if admin credentials
    const isAdmin = email === 'admin@shophub.com' && password === 'admin123';
    
    // Check if seller (look in sellers list)
    const isSeller = checkIfSeller(email);
    
    const mockUser: User = {
      id: isAdmin ? 'admin-1' : (isSeller ? `seller-${Date.now()}` : Date.now().toString()),
      name: isAdmin ? 'Admin User' : (isSeller ? 'Seller User' : 'John Doe'),
      email: email,
      avatar: undefined,
      role: isAdmin ? 'admin' : (isSeller ? 'seller' : 'customer'),
    };
    
    setUser(mockUser);
  };

  const signup = async (name: string, email: string, password: string) => {
    // Mock signup - In real app, this would call an API
    await new Promise((resolve) => setTimeout(resolve, 1000));
    
    const mockUser: User = {
      id: Date.now().toString(),
      name: name,
      email: email,
      avatar: undefined,
      role: 'customer',
    };
    
    setUser(mockUser);
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        signup,
        logout,
        isAuthenticated: !!user,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};
