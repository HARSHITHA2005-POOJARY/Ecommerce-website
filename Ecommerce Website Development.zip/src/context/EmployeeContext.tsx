import React, { createContext, useContext, useState, useEffect } from 'react';
import { Employee, Attendance } from '../types';
import api from '../utils/api';
import { toast } from 'sonner';

interface EmployeeContextType {
  employees: Employee[];
  attendance: Attendance[];
  currentEmployee: Employee | null;
  loading: boolean;
  employeeLogin: (email: string, password: string) => Promise<boolean>;
  employeeLogout: () => void;
  addEmployee: (employee: Omit<Employee, 'id'>) => Promise<void>;
  updateEmployee: (id: string, updates: Partial<Employee>) => Promise<void>;
  deleteEmployee: (id: string) => Promise<void>;
  getEmployee: (id: string) => Employee | undefined;
  markAttendance: (employeeId: string, status: Attendance['status'], checkIn?: string, checkOut?: string, remarks?: string) => Promise<void>;
  getEmployeeAttendance: (employeeId: string, month?: number, year?: number) => Promise<Attendance[]>;
  updateAttendance: (id: string, updates: Partial<Attendance>) => Promise<void>;
  getMonthlyAttendanceStats: (employeeId: string, month: number, year: number) => {
    present: number;
    absent: number;
    halfDay: number;
    leave: number;
  };
  calculateMonthlySalary: (employeeId: string, month: number, year: number) => number;
  getTodayAttendance: (employeeId: string) => Attendance | undefined;
  isWorkingDay: (employeeId: string) => boolean;
  isLateCheckIn: (employeeId: string, checkInTime: string) => boolean;
  refreshEmployees: () => Promise<void>;
  refreshAttendance: (employeeId?: string) => Promise<void>;
}

const EmployeeContext = createContext<EmployeeContextType | undefined>(undefined);

export const EmployeeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [employees, setEmployees] = useState<Employee[]>(() => {
    const saved = localStorage.getItem('employees');
    return saved ? JSON.parse(saved) : [];
  });
  const [attendance, setAttendance] = useState<Attendance[]>(() => {
    const saved = localStorage.getItem('attendance');
    return saved ? JSON.parse(saved) : [];
  });
  const [currentEmployee, setCurrentEmployee] = useState<Employee | null>(() => {
    const saved = localStorage.getItem('currentEmployee');
    return saved ? JSON.parse(saved) : null;
  });
  const [loading, setLoading] = useState(true);
  const [useBackend, setUseBackend] = useState(true);

  // Save to localStorage whenever data changes
  useEffect(() => {
    localStorage.setItem('employees', JSON.stringify(employees));
  }, [employees]);

  useEffect(() => {
    localStorage.setItem('attendance', JSON.stringify(attendance));
  }, [attendance]);

  // Fetch employees on mount (for admin)
  useEffect(() => {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');
    
    if (token && user) {
      const userData = JSON.parse(user);
      // Only fetch all employees if user is admin
      if (userData.role === 'ADMIN') {
        fetchEmployees();
      }
    }
    setLoading(false);
  }, []);

  // Restore employee session on mount
  useEffect(() => {
    const employeeToken = localStorage.getItem('employeeToken');
    if (employeeToken && !currentEmployee) {
      fetchEmployeeProfile();
    }
  }, []);

  useEffect(() => {
    if (currentEmployee) {
      localStorage.setItem('currentEmployee', JSON.stringify(currentEmployee));
    } else {
      localStorage.removeItem('currentEmployee');
    }
  }, [currentEmployee]);

  const fetchEmployees = async () => {
    try {
      setLoading(true);
      const response = await api.get('/employees');
      const backendEmployees = response.data || [];
      
      // Transform all employees from backend format to frontend format
      const transformedEmployees = backendEmployees.map((emp: any) => transformBackendToFrontend(emp));
      
      setEmployees(transformedEmployees);
    } catch (error: any) {
      console.error('Error fetching employees:', error);
      setEmployees([]);
    } finally {
      setLoading(false);
    }
  };

  const fetchEmployeeProfile = async () => {
    try {
      const response = await api.get('/employeeAuth/me');
      const transformedEmployee = transformBackendToFrontend(response.data);
      setCurrentEmployee(transformedEmployee);
    } catch (error) {
      console.error('Error fetching employee profile:', error);
      localStorage.removeItem('employeeToken');
      setCurrentEmployee(null);
    }
  };

  const employeeLogin = async (email: string, password: string): Promise<boolean> => {
    if (useBackend) {
      try {
        const response = await api.post('/employeeAuth/login', { email, password });
        
        const { employee, token } = response.data;
        
        // Transform employee data from backend format
        const transformedEmployee = transformBackendToFrontend(employee);
        
        // Save token separately for employees
        localStorage.setItem('employeeToken', token);
        localStorage.setItem('token', token); // Also set as main token for API calls
        
        setCurrentEmployee(transformedEmployee);
        
        // Fetch attendance data for the logged-in employee
        await getEmployeeAttendance(transformedEmployee.id);
        
        return true;
      } catch (error: any) {
        console.error('Employee login error:', error);
        console.warn('Backend not available, trying localStorage login');
        setUseBackend(false);
        // Fall through to localStorage implementation
      }
    }
    
    // LocalStorage fallback login
    const employee = employees.find(emp => emp.email === email);
    
    if (!employee) {
      toast.error('Employee not found');
      return false;
    }
    
    if (!employee.approved) {
      toast.error('Your account is pending approval. Please contact admin.');
      return false;
    }
    
    if (employee.status !== 'active') {
      toast.error('Your account is inactive. Please contact admin.');
      return false;
    }
    
    // In localStorage mode, we'll do a simple password check
    // Note: In production, passwords should be hashed
    // For now, we'll create a mock token
    const mockToken = `mock_token_${employee.id}_${Date.now()}`;
    
    localStorage.setItem('employeeToken', mockToken);
    localStorage.setItem('token', mockToken);
    
    setCurrentEmployee(employee);
    
    // Load attendance data for this employee
    const empAttendance = attendance.filter(att => att.employeeId === employee.id);
    if (empAttendance.length === 0) {
      // Initialize empty attendance if none exists
      setAttendance([]);
    }
    
    toast.success(`Welcome back, ${employee.name}!`);
    return true;
  };

  const employeeLogout = () => {
    localStorage.removeItem('employeeToken');
    localStorage.removeItem('token');
    localStorage.removeItem('currentEmployee');
    setCurrentEmployee(null);
  };

  const addEmployee = async (employeeData: Omit<Employee, 'id'>) => {
    // Try backend first
    if (useBackend) {
      try {
        // Transform the data to match backend schema
        const backendData = {
          name: employeeData.name,
          email: employeeData.email,
          password: employeeData.password,
          phone: employeeData.phone,
          designation: employeeData.designation,
          department: employeeData.department,
          joiningDate: employeeData.joiningDate,
          salary: employeeData.salary,
          status: employeeData.status.toUpperCase(), // 'active' -> 'ACTIVE'
          approved: employeeData.approved,
          address: employeeData.address,
          emergencyName: employeeData.emergencyContact?.name || '',
          emergencyPhone: employeeData.emergencyContact?.phone || '',
          emergencyRelation: employeeData.emergencyContact?.relation || '',
          scheduleCheckInTime: employeeData.schedule?.checkInTime,
          scheduleCheckOutTime: employeeData.schedule?.checkOutTime,
          scheduleWorkingDays: employeeData.schedule?.workingDays || [] // Now an array of numbers
        };

        const response = await api.post('/employees', backendData);
        
        // Transform response back to frontend format
        const frontendEmployee = transformBackendToFrontend(response.data);
        setEmployees((prev) => [frontendEmployee, ...prev]);
        return;
      } catch (error: any) {
        console.warn('Backend not available, falling back to localStorage');
        setUseBackend(false);
        // Fall through to localStorage implementation
      }
    }
    
    // LocalStorage fallback
    const newEmployee: Employee = {
      id: `emp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      ...employeeData,
      password: employeeData.password, // Store password for localStorage login
    };
    
    setEmployees((prev) => [newEmployee, ...prev]);
  };

  const updateEmployee = async (id: string, updates: Partial<Employee>) => {
    try {
      const response = await api.put(`/employees/${id}`, updates);
      setEmployees((prev) =>
        prev.map((employee) => (employee.id === id ? response.data : employee))
      );
      
      // Update current employee if it's the same one
      if (currentEmployee?.id === id) {
        setCurrentEmployee(response.data);
      }
    } catch (error: any) {
      console.error('Error updating employee:', error);
      throw new Error(error.message || 'Failed to update employee');
    }
  };

  const deleteEmployee = async (id: string) => {
    if (useBackend) {
      try {
        await api.delete(`/employees/${id}`);
        setEmployees((prev) => prev.filter((employee) => employee.id !== id));
        return;
      } catch (error: any) {
        console.warn('Backend not available, using localStorage');
        setUseBackend(false);
      }
    }
    
    // LocalStorage fallback
    setEmployees((prev) => prev.filter((employee) => employee.id !== id));
  };

  const getEmployee = (id: string) => {
    // First check if it's the current employee
    if (currentEmployee?.id === id) {
      return currentEmployee;
    }
    // Otherwise search in employees list
    return employees.find((employee) => employee.id === id);
  };

  const markAttendance = async (
    employeeId: string,
    status: Attendance['status'],
    checkIn?: string,
    checkOut?: string,
    remarks?: string
  ) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (useBackend) {
      try {
        // Map frontend status to backend status
        const backendStatus = status.toUpperCase().replace('-', '_'); // 'half-day' -> 'HALF_DAY'

        const response = await api.post('/attendance', {
          employeeId,
          date: today.toISOString(),
          status: backendStatus,
          checkIn,
          checkOut,
          remarks,
        });

        // Update local attendance state
        const newAttendance: Attendance = {
          id: response.data.id,
          employeeId,
          employeeName: response.data.employee?.name || '',
          date: new Date(response.data.date),
          status,
          checkIn,
          checkOut,
          remarks,
        };

        setAttendance((prev) => {
          // Remove existing attendance for today if any
          const filtered = prev.filter(
            (att) =>
              !(att.employeeId === employeeId &&
                new Date(att.date).toDateString() === today.toDateString())
          );
          return [...filtered, newAttendance];
        });
        return;
      } catch (error: any) {
        console.warn('Backend not available, using localStorage');
        setUseBackend(false);
        // Fall through to localStorage implementation
      }
    }

    // LocalStorage fallback
    const employee = getEmployee(employeeId);
    const newAttendance: Attendance = {
      id: `att_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      employeeId,
      employeeName: employee?.name || '',
      date: today,
      status,
      checkIn,
      checkOut,
      remarks,
    };

    setAttendance((prev) => {
      // Remove existing attendance for today if any
      const filtered = prev.filter(
        (att) =>
          !(att.employeeId === employeeId &&
            new Date(att.date).toDateString() === today.toDateString())
      );
      return [...filtered, newAttendance];
    });
  };

  const getEmployeeAttendance = async (
    employeeId: string,
    month?: number,
    year?: number
  ): Promise<Attendance[]> => {
    try {
      const params: any = {};
      if (month !== undefined && year !== undefined) {
        params.month = month + 1; // Backend expects 1-12, frontend uses 0-11
        params.year = year;
      }

      const response = await api.get(`/attendance/employee/${employeeId}`, { params });
      
      const attendanceData = response.data?.attendance || [];
      
      // Map backend attendance to frontend format
      const mappedAttendance: Attendance[] = attendanceData.map((att: any) => ({
        id: att.id,
        employeeId: att.employeeId,
        employeeName: att.employee?.name || '',
        date: new Date(att.date),
        status: att.status.toLowerCase().replace('_', '-'), // 'HALF_DAY' -> 'half-day'
        checkIn: att.checkIn,
        checkOut: att.checkOut,
        remarks: att.remarks,
      }));

      setAttendance(mappedAttendance);
      return mappedAttendance;
    } catch (error: any) {
      console.error('Error fetching attendance:', error);
      return [];
    }
  };

  const updateAttendance = async (id: string, updates: Partial<Attendance>) => {
    try {
      // Map frontend status to backend if status is being updated
      const backendUpdates: any = { ...updates };
      if (updates.status) {
        backendUpdates.status = updates.status.toUpperCase().replace('-', '_');
      }

      await api.put(`/attendance/${id}`, backendUpdates);
      
      setAttendance((prev) =>
        prev.map((att) => (att.id === id ? { ...att, ...updates } : att))
      );
    } catch (error: any) {
      console.error('Error updating attendance:', error);
      throw new Error(error.message || 'Failed to update attendance');
    }
  };

  const getMonthlyAttendanceStats = (employeeId: string, month: number, year: number) => {
    const monthAttendance = attendance.filter((att) => {
      if (att.employeeId !== employeeId) return false;
      const attDate = new Date(att.date);
      return attDate.getMonth() === month && attDate.getFullYear() === year;
    });

    return {
      present: monthAttendance.filter((att) => att.status === 'present').length,
      absent: monthAttendance.filter((att) => att.status === 'absent').length,
      halfDay: monthAttendance.filter((att) => att.status === 'half-day').length,
      leave: monthAttendance.filter((att) => att.status === 'leave').length,
    };
  };

  const calculateMonthlySalary = (employeeId: string, month: number, year: number) => {
    const employee = getEmployee(employeeId);
    if (!employee) return 0;

    const stats = getMonthlyAttendanceStats(employeeId, month, year);
    const totalDays = new Date(year, month + 1, 0).getDate(); // Days in month

    // Calculate working days (present + half-day counted as 0.5)
    const workingDays = stats.present + stats.halfDay * 0.5;

    // Daily salary
    const dailySalary = employee.salary / totalDays;

    // Calculate salary based on attendance
    return Math.round(dailySalary * workingDays);
  };

  const getTodayAttendance = (employeeId: string): Attendance | undefined => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    return attendance.find(
      (att) =>
        att.employeeId === employeeId &&
        new Date(att.date).toDateString() === today.toDateString()
    );
  };

  const isWorkingDay = (employeeId: string): boolean => {
    const employee = getEmployee(employeeId);
    if (!employee || !employee.schedule) return true;
    
    const today = new Date().getDay();
    return employee.schedule.workingDays.includes(today);
  };

  const isLateCheckIn = (employeeId: string, checkInTime: string): boolean => {
    const employee = getEmployee(employeeId);
    if (!employee || !employee.schedule) return false;
    
    const [hours, minutes] = checkInTime.split(':');
    const [schedHours, schedMins] = employee.schedule.checkInTime.split(':');
    
    const checkInMinutes = parseInt(hours) * 60 + parseInt(minutes);
    const scheduledMinutes = parseInt(schedHours) * 60 + parseInt(schedMins);
    
    return checkInMinutes > scheduledMinutes;
  };

  const refreshEmployees = async () => {
    await fetchEmployees();
  };

  const refreshAttendance = async (employeeId?: string) => {
    if (employeeId) {
      await getEmployeeAttendance(employeeId);
    } else if (currentEmployee) {
      await getEmployeeAttendance(currentEmployee.id);
    }
  };

  return (
    <EmployeeContext.Provider
      value={{
        employees,
        attendance,
        currentEmployee,
        loading,
        employeeLogin,
        employeeLogout,
        addEmployee,
        updateEmployee,
        deleteEmployee,
        getEmployee,
        markAttendance,
        getEmployeeAttendance,
        updateAttendance,
        getMonthlyAttendanceStats,
        calculateMonthlySalary,
        getTodayAttendance,
        isWorkingDay,
        isLateCheckIn,
        refreshEmployees,
        refreshAttendance,
      }}
    >
      {children}
    </EmployeeContext.Provider>
  );
};

export const useEmployee = () => {
  const context = useContext(EmployeeContext);
  if (!context) {
    throw new Error('useEmployee must be used within EmployeeProvider');
  }
  return context;
};

// Helper function to transform backend data to frontend format
const transformBackendToFrontend = (backendEmployee: any): Employee => {
  return {
    id: backendEmployee.id,
    name: backendEmployee.name,
    email: backendEmployee.email,
    phone: backendEmployee.phone,
    designation: backendEmployee.designation,
    department: backendEmployee.department,
    joiningDate: backendEmployee.joiningDate,
    salary: backendEmployee.salary,
    status: backendEmployee.status.toLowerCase(),
    approved: backendEmployee.approved,
    address: backendEmployee.address,
    emergencyContact: {
      name: backendEmployee.emergencyName,
      phone: backendEmployee.emergencyPhone,
      relation: backendEmployee.emergencyRelation,
    },
    schedule: {
      checkInTime: backendEmployee.scheduleCheckInTime,
      checkOutTime: backendEmployee.scheduleCheckOutTime,
      workingDays: backendEmployee.scheduleWorkingDays,
    },
  };
};