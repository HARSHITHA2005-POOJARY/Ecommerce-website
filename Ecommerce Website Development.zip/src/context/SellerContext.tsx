import React, { createContext, useContext, useState, useEffect } from 'react';
import { Seller } from '../types';

interface SellerContextType {
  sellers: Seller[];
  addSeller: (seller: Omit<Seller, 'id' | 'createdAt' | 'totalSales' | 'totalCommission'>) => void;
  updateSeller: (id: string, updates: Partial<Seller>) => void;
  deleteSeller: (id: string) => void;
  getSeller: (id: string) => Seller | undefined;
  approveSeller: (id: string) => void;
  updateCommission: (id: string, commission: number) => void;
  getSellerSales: (sellerId: string) => number;
}

const SellerContext = createContext<SellerContextType | undefined>(undefined);

const defaultSellers: Seller[] = [
  {
    id: 'seller-1',
    name: 'Test Seller',
    email: 'test@seller.com',
    businessName: 'Test Shop',
    phone: '+91 9876543210',
    gst: '22AAAAA0000A1Z5',
    commission: 15,
    address: '123 Business Street, Mumbai, Maharashtra 400001',
    approved: true,
    createdAt: new Date('2024-01-01'),
    totalSales: 0,
    totalCommission: 0,
  },
];

export const SellerProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [sellers, setSellers] = useState<Seller[]>(() => {
    const saved = localStorage.getItem('sellers');
    if (saved) {
      return JSON.parse(saved);
    }
    // Initialize with default seller
    localStorage.setItem('sellers', JSON.stringify(defaultSellers));
    return defaultSellers;
  });

  useEffect(() => {
    localStorage.setItem('sellers', JSON.stringify(sellers));
  }, [sellers]);

  const addSeller = (sellerData: Omit<Seller, 'id' | 'createdAt' | 'totalSales' | 'totalCommission'>) => {
    const newSeller: Seller = {
      ...sellerData,
      id: Date.now().toString(),
      createdAt: new Date(),
      totalSales: 0,
      totalCommission: 0,
    };
    setSellers((prev) => [...prev, newSeller]);
  };

  const updateSeller = (id: string, updates: Partial<Seller>) => {
    setSellers((prev) =>
      prev.map((seller) => (seller.id === id ? { ...seller, ...updates } : seller))
    );
  };

  const deleteSeller = (id: string) => {
    setSellers((prev) => prev.filter((seller) => seller.id !== id));
  };

  const getSeller = (id: string) => {
    return sellers.find((seller) => seller.id === id);
  };

  const approveSeller = (id: string) => {
    updateSeller(id, { approved: true });
  };

  const updateCommission = (id: string, commission: number) => {
    updateSeller(id, { commission });
  };

  const getSellerSales = (sellerId: string) => {
    const seller = getSeller(sellerId);
    return seller?.totalSales || 0;
  };

  return (
    <SellerContext.Provider
      value={{
        sellers,
        addSeller,
        updateSeller,
        deleteSeller,
        getSeller,
        approveSeller,
        updateCommission,
        getSellerSales,
      }}
    >
      {children}
    </SellerContext.Provider>
  );
};

export const useSeller = () => {
  const context = useContext(SellerContext);
  if (!context) {
    throw new Error('useSeller must be used within SellerProvider');
  }
  return context;
};
