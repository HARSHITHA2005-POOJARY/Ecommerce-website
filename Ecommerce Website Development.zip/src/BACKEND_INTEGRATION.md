# 🔗 Frontend-Backend Integration Guide

This guide explains how to connect your React frontend to the Node.js backend API.

---

## 📋 Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [What Changed](#what-changed)
3. [API Configuration](#api-configuration)
4. [Converting Context to API Calls](#converting-context-to-api-calls)
5. [Authentication Flow](#authentication-flow)
6. [Step-by-Step Migration](#step-by-step-migration)
7. [Testing](#testing)

---

## 🏗 Architecture Overview

### Before (Frontend Only)
```
React App
   ├── LocalStorage (Data)
   ├── Context API (State)
   └── Mock Auth
```

### After (Full Stack)
```
React App ←→ API (Port 5000) ←→ PostgreSQL Database
   ├── Axios/Fetch           ├── Express Routes
   ├── Context API           ├── Controllers
   ├── JWT Tokens            ├── Prisma ORM
   └── State Management      └── Business Logic
```

---

## 🔄 What Changed

### Frontend (Your Current Setup)
- ✅ UI Components (No changes needed)
- ✅ Styling (No changes needed)
- ✅ Pages & Routes (No changes needed)
- ⚠️ **Context Files** (Need to be updated to call APIs)
- ⚠️ **LocalStorage** (Will be replaced with API calls)

### New Backend (Just Created)
- ✅ PostgreSQL Database
- ✅ Express API Server
- ✅ JWT Authentication
- ✅ All CRUD operations
- ✅ Business logic

---

## ⚙️ API Configuration

### 1. Install Axios (Frontend)

```bash
# In your main project directory (not backend)
npm install axios
```

### 2. Create API Client

Create `/utils/api.ts` in your frontend:

```typescript
import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

// Create axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Add auth token to requests
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Handle response errors
api.interceptors.response.use(
  (response) => response.data,
  (error) => {
    if (error.response?.status === 401) {
      // Token expired or invalid
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error.response?.data || error);
  }
);

export default api;
```

---

## 🔐 Authentication Flow

### Updated AuthContext

Here's how to update `/context/AuthContext.tsx`:

```typescript
import React, { createContext, useContext, useState, useEffect } from 'react';
import api from '../utils/api';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  signup: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  // Check if user is logged in on mount
  useEffect(() => {
    const token = localStorage.getItem('token');
    const savedUser = localStorage.getItem('user');
    
    if (token && savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    try {
      const response = await api.post('/auth/login', { email, password });
      
      const { user, token } = response.data;
      
      // Save to localStorage
      localStorage.setItem('token', token);
      localStorage.setItem('user', JSON.stringify(user));
      
      setUser(user);
    } catch (error: any) {
      throw new Error(error.message || 'Login failed');
    }
  };

  const signup = async (name: string, email: string, password: string) => {
    try {
      const response = await api.post('/auth/register', { name, email, password });
      
      const { user, token } = response.data;
      
      localStorage.setItem('token', token);
      localStorage.setItem('user', JSON.stringify(user));
      
      setUser(user);
    } catch (error: any) {
      throw new Error(error.message || 'Signup failed');
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        signup,
        logout,
        isAuthenticated: !!user,
        loading
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
```

---

## 📦 Converting ProductContext

### Updated ProductContext

```typescript
import React, { createContext, useContext, useState, useEffect } from 'react';
import api from '../utils/api';
import { Product } from '../types';

interface ProductContextType {
  products: Product[];
  loading: boolean;
  addProduct: (product: Omit<Product, 'id'>) => Promise<void>;
  updateProduct: (id: string, updates: Partial<Product>) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  refreshProducts: () => Promise<void>;
}

const ProductContext = createContext<ProductContextType | undefined>(undefined);

export const ProductProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  // Fetch products on mount
  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const response = await api.get('/products');
      setProducts(response.data);
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoading(false);
    }
  };

  const addProduct = async (productData: Omit<Product, 'id'>) => {
    try {
      const response = await api.post('/products', productData);
      setProducts(prev => [response.data, ...prev]);
    } catch (error: any) {
      throw new Error(error.message || 'Failed to add product');
    }
  };

  const updateProduct = async (id: string, updates: Partial<Product>) => {
    try {
      const response = await api.put(`/products/${id}`, updates);
      setProducts(prev => 
        prev.map(p => p.id === id ? response.data : p)
      );
    } catch (error: any) {
      throw new Error(error.message || 'Failed to update product');
    }
  };

  const deleteProduct = async (id: string) => {
    try {
      await api.delete(`/products/${id}`);
      setProducts(prev => prev.filter(p => p.id !== id));
    } catch (error: any) {
      throw new Error(error.message || 'Failed to delete product');
    }
  };

  return (
    <ProductContext.Provider
      value={{
        products,
        loading,
        addProduct,
        updateProduct,
        deleteProduct,
        refreshProducts: fetchProducts
      }}
    >
      {children}
    </ProductContext.Provider>
  );
};

export const useProducts = () => {
  const context = useContext(ProductContext);
  if (!context) throw new Error('useProducts must be used within ProductProvider');
  return context;
};
```

---

## 🛒 Converting CartContext

### Updated CartContext

```typescript
import React, { createContext, useContext, useState, useEffect } from 'react';
import api from '../utils/api';
import { Product } from '../types';
import { useAuth } from './AuthContext';

interface CartItem {
  product: Product;
  quantity: number;
}

interface CartContextType {
  cart: CartItem[];
  loading: boolean;
  addToCart: (product: Product) => Promise<void>;
  updateQuantity: (productId: string, quantity: number) => Promise<void>;
  removeFromCart: (productId: string) => Promise<void>;
  clearCart: () => Promise<void>;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(false);
  const { isAuthenticated } = useAuth();

  // Fetch cart when user is authenticated
  useEffect(() => {
    if (isAuthenticated) {
      fetchCart();
    } else {
      setCart([]);
    }
  }, [isAuthenticated]);

  const fetchCart = async () => {
    try {
      setLoading(true);
      const response = await api.get('/cart');
      // Transform API response to CartItem format
      const cartItems = response.data.map((item: any) => ({
        product: item.product,
        quantity: item.quantity
      }));
      setCart(cartItems);
    } catch (error) {
      console.error('Error fetching cart:', error);
    } finally {
      setLoading(false);
    }
  };

  const addToCart = async (product: Product) => {
    try {
      await api.post('/cart/add', {
        productId: product.id,
        quantity: 1
      });
      await fetchCart(); // Refresh cart
    } catch (error: any) {
      throw new Error(error.message || 'Failed to add to cart');
    }
  };

  const updateQuantity = async (productId: string, quantity: number) => {
    try {
      await api.put(`/cart/update/${productId}`, { quantity });
      await fetchCart(); // Refresh cart
    } catch (error: any) {
      throw new Error(error.message || 'Failed to update quantity');
    }
  };

  const removeFromCart = async (productId: string) => {
    try {
      await api.delete(`/cart/remove/${productId}`);
      await fetchCart(); // Refresh cart
    } catch (error: any) {
      throw new Error(error.message || 'Failed to remove from cart');
    }
  };

  const clearCart = async () => {
    try {
      await api.delete('/cart/clear');
      setCart([]);
    } catch (error: any) {
      throw new Error(error.message || 'Failed to clear cart');
    }
  };

  return (
    <CartContext.Provider
      value={{
        cart,
        loading,
        addToCart,
        updateQuantity,
        removeFromCart,
        clearCart
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) throw new Error('useCart must be used within CartProvider');
  return context;
};
```

---

## 📝 Step-by-Step Migration

### Phase 1: Setup Backend ✅
- [x] Backend created with all routes
- [x] Database setup
- [x] API documented

### Phase 2: Frontend Updates (Next Steps)

1. **Install Dependencies**
   ```bash
   npm install axios
   ```

2. **Create API Utility**
   - Create `/utils/api.ts` (code provided above)

3. **Update AuthContext**
   - Replace mock login with API calls
   - Add token management
   - (Code provided above)

4. **Update ProductContext**
   - Replace LocalStorage with API calls
   - (Code provided above)

5. **Update CartContext**
   - Replace LocalStorage with API calls
   - (Code provided above)

6. **Update OrderContext**
   - Similar pattern as ProductContext

7. **Update SellerContext**
   - Call `/api/sellers` endpoints

8. **Update EmployeeContext**
   - Call `/api/employees` endpoints

9. **Environment Variables**
   Create `.env` in frontend root:
   ```env
   REACT_APP_API_URL=http://localhost:5000/api
   ```

10. **Test Each Feature**
    - Login/Signup
    - Browse products
    - Add to cart
    - Checkout
    - Admin panel
    - Seller dashboard

---

## 🧪 Testing Integration

### 1. Start Backend
```bash
cd backend
npm run dev
```

### 2. Start Frontend
```bash
# In root directory
npm start
```

### 3. Test Login
- Open `http://localhost:3000`
- Click Login
- Use: `admin@shophub.com` / `admin123`
- Check Network tab in DevTools
- Should see API call to `http://localhost:5000/api/auth/login`

### 4. Test Products
- Browse products
- Check Network tab
- Should see `GET http://localhost:5000/api/products`

### 5. Test Cart
- Add product to cart (must be logged in)
- Check Network tab
- Should see `POST http://localhost:5000/api/cart/add`

---

## 🔍 Debugging

### Check if Backend is Running
```bash
curl http://localhost:5000/api/health
```

### Check CORS
If you get CORS errors, verify `FRONTEND_URL` in backend `.env`:
```env
FRONTEND_URL=http://localhost:3000
```

### Check Authentication
```bash
# Test login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@shophub.com","password":"admin123"}'
```

### Common Issues

**Issue:** "Network Error"
- **Solution:** Backend not running. Start with `npm run dev`

**Issue:** "CORS Error"
- **Solution:** Check `FRONTEND_URL` in backend `.env`

**Issue:** "401 Unauthorized"
- **Solution:** Token missing or expired. Login again.

**Issue:** "Cannot find module 'axios'"
- **Solution:** `npm install axios`

---

## 📊 Migration Checklist

- [ ] Backend running on port 5000
- [ ] Frontend has axios installed
- [ ] `/utils/api.ts` created
- [ ] AuthContext updated
- [ ] ProductContext updated
- [ ] CartContext updated
- [ ] OrderContext updated
- [ ] SellerContext updated
- [ ] EmployeeContext updated
- [ ] Login working
- [ ] Products loading from API
- [ ] Cart persisting to database
- [ ] Orders creating successfully
- [ ] Admin panel functional
- [ ] Seller dashboard functional

---

## 🚀 Benefits of Backend Integration

### Before (Frontend Only)
- ❌ Data lost on browser clear
- ❌ No real authentication
- ❌ No data sharing between devices
- ❌ Limited to browser storage (5MB)
- ❌ No real security

### After (Full Stack)
- ✅ Data persists in database
- ✅ Real JWT authentication
- ✅ Access from any device
- ✅ Unlimited data storage
- ✅ Role-based security
- ✅ API can be used by mobile apps
- ✅ Scalable architecture
- ✅ Production-ready

---

## 📚 Next Steps

1. Complete frontend context updates
2. Test all features
3. Add error handling
4. Implement loading states
5. Add toast notifications for API errors
6. Deploy backend to Heroku/Railway
7. Deploy frontend to Vercel/Netlify
8. Update frontend API URL to production

---

## 🆘 Need Help?

- Review backend `/backend/README.md`
- Check API documentation in backend
- Test endpoints with Postman
- Check browser console for errors
- Verify network tab in DevTools

---

**🎉 Once integrated, you'll have a full-stack production-ready e-commerce platform!**
