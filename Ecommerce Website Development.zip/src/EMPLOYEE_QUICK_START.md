# Employee Management - Quick Start Guide

## 🚀 Get Started in 3 Minutes (LocalStorage Mode)

### Step 1: Login as Admin
1. Click the "Login" button in the header
2. Go to the "Admin Login" tab
3. Enter any credentials or use:
   - Email: `admin@shophub.com`
   - Password: `admin123`
4. Click "Login as Admin"

### Step 2: Add an Employee
1. You'll be taken to the Admin Dashboard
2. Click the "Employees" tab
3. Click "Add New Employee" button
4. Fill in the employee details:
   - **Name**: John Doe
   - **Email**: john@shophub.com
   - **Password**: password123 (stored for localStorage login)
   - **Phone**: 9876543210
   - **Designation**: Sales Manager
   - **Department**: Sales
   - **Salary**: ₹50000
   - **Status**: Active
   - **Approved**: ✅ Check this box (required for login)
   - **Schedule**: 
     - Check-in: 09:00
     - Check-out: 18:00
     - Working Days: Monday to Friday (1,2,3,4,5)
5. Click "Add Employee"

### Step 3: Employee Login
1. Logout from admin (click username → Logout)
2. Go to "Login" page
3. Click "Employee Login" tab
4. Enter:
   - Email: john@shophub.com
   - Password: (any password works in localStorage mode)
5. Click "Login as Employee"

### Step 4: Mark Attendance
1. You'll see the Employee Dashboard
2. The "Today's Attendance" card shows:
   - Working day status
   - Check-in time
   - Current status
3. Click "Mark Present" to mark attendance
4. The system records:
   - Check-in time
   - Whether you're late
   - Attendance status

### Step 5: View Attendance History
1. Go to the "Attendance" tab
2. Select month and year
3. View your attendance records
4. See statistics:
   - Present days
   - Absent days
   - Half-days
   - Leave days

### Step 6: View Payroll
1. Go to the "Payroll" tab
2. See your salary breakdown:
   - Base salary: ₹50,000
   - Days worked: Based on attendance
   - Calculated salary: Prorated based on attendance
3. Monthly breakdown shows:
   - Total days in month
   - Working days
   - Salary calculation

## 🎯 Admin Features

### Managing Employees
- **View All**: See list of all employees
- **Edit**: Update employee details
- **Delete**: Remove employees
- **Approve/Reject**: Control who can login

### Managing Attendance
- **View All**: See attendance of all employees
- **Mark Attendance**: Admin can mark for any employee
- **Edit Records**: Update attendance status
- **Attendance Reports**: Filter by month/year

### Managing Payroll
- **View Salaries**: See all employee salaries
- **Calculate Pay**: Automatic based on attendance
- **Monthly Reports**: Export salary data

## 📊 Attendance Rules

### Status Types:
- **Present**: Full day work (1.0 day)
- **Half-day**: Partial work (0.5 day)
- **Absent**: No work (0.0 day)
- **Leave**: Approved leave (0.0 day)

### Salary Calculation:
```
Daily Rate = Monthly Salary ÷ Total Days in Month
Working Days = Present Days + (Half-days × 0.5)
Final Salary = Daily Rate × Working Days
```

### Late Check-in Detection:
- Compares your check-in time with scheduled time
- Marks as "Late" if you check in after scheduled time
- Example: If schedule is 09:00, checking in at 09:15 = Late

### Working Days:
- 0 = Sunday
- 1 = Monday
- 2 = Tuesday
- 3 = Wednesday
- 4 = Thursday
- 5 = Friday
- 6 = Saturday

## 🔄 Data Persistence

### LocalStorage Mode:
- ✅ All data saved in browser
- ✅ Survives page refresh
- ⚠️ Cleared if you clear browser data
- ⚠️ Not shared across devices/browsers

### Backend Mode (Optional):
- ✅ Permanent storage in PostgreSQL
- ✅ Sync across devices
- ✅ Real password validation
- ✅ Production-ready

## 🧪 Testing Scenarios

### Scenario 1: Regular Work Day
1. Login as employee
2. Mark "Present"
3. Check-in time recorded
4. At end of day, can mark check-out

### Scenario 2: Late Arrival
1. Login after scheduled time (e.g., 10:00 when schedule is 09:00)
2. Mark "Present"
3. System marks as "Late"

### Scenario 3: Half Day
1. Login as employee
2. Mark "Half-day"
3. Salary calculation uses 0.5 multiplier

### Scenario 4: Monthly Payroll
1. Mark attendance for multiple days
2. Go to Payroll tab
3. See calculated salary based on actual attendance

## 💡 Tips

- **Always approve employees** before they can login
- **Set realistic schedules** for working hours
- **Mark attendance daily** for accurate payroll
- **Check late status** to monitor punctuality
- **Review payroll monthly** before processing

## 🆘 Troubleshooting

### Employee Can't Login?
- ✅ Check if employee is **Approved** (Admin → Employees → Check approved status)
- ✅ Check if status is **Active**
- ✅ Verify email is correct

### Attendance Not Showing?
- ✅ Check if attendance was marked for the employee
- ✅ Verify date range in filters
- ✅ Refresh the page

### Salary Showing Zero?
- ✅ Mark some attendance first
- ✅ Check the selected month has attendance records
- ✅ Verify employee salary is set

### Data Lost?
- ⚠️ In localStorage mode, clearing browser data = losing everything
- ✅ Use backend mode for permanent storage
- ✅ Or export data regularly (feature coming soon)

## 📞 Need Backend Mode?

If you need:
- Permanent data storage
- Multi-device access
- Real authentication
- Production deployment

See **SETUP_MODES.md** for backend setup instructions!

---

**Ready to go!** Start by adding your first employee and testing the attendance system. 🎉
