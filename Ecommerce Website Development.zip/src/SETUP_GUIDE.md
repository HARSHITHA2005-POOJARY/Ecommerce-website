# 🛍️ ShopHub E-commerce Platform - Complete Setup Guide

## 📖 Table of Contents
1. [What is ShopHub?](#what-is-shophub)
2. [Required Software & Platforms](#required-software--platforms)
3. [Package Dependencies Explained](#package-dependencies-explained)
4. [Installation Steps](#installation-steps)
5. [Application Structure](#application-structure)
6. [How It Works](#how-it-works)
7. [Features Breakdown](#features-breakdown)

---

## 🎯 What is ShopHub?

ShopHub is a **full-featured e-commerce web application** similar to Amazon, Flipkart, or Shopsy. It's a complete online shopping platform where:

- **Customers** can browse products, add items to cart, checkout, and track orders
- **Admins** can manage products, view orders, and see analytics
- Everything runs in your **web browser** (no mobile app needed)
- All data is stored **locally** in your browser (no database required for demo)

### Technology Stack
- **Frontend Framework**: React 18 (JavaScript library for building user interfaces)
- **Language**: TypeScript (JavaScript with type safety)
- **Styling**: Tailwind CSS v4 (utility-first CSS framework)
- **Build Tool**: Vite (fast development server and bundler)
- **UI Components**: Shadcn/UI (pre-built accessible components)

---

## 💻 Required Software & Platforms

### Step 1: Install Node.js

**What is Node.js?**
- A JavaScript runtime that lets you run JavaScript code outside the browser
- Required to run the development server and build tools

**Download & Install:**
1. Go to: https://nodejs.org/
2. Download **LTS (Long Term Support)** version
3. Run the installer
4. Follow the installation wizard (accept defaults)

**Verify Installation:**
```bash
# Open Command Prompt (Windows) or Terminal (Mac/Linux)
node --version
# Should show: v18.x.x or higher

npm --version
# Should show: v9.x.x or higher
```

**Platform-Specific Notes:**
- **Windows**: Download the `.msi` installer
- **macOS**: Download the `.pkg` installer or use `brew install node`
- **Linux**: Use package manager like `sudo apt install nodejs npm`

### Step 2: Choose a Code Editor (Optional but Recommended)

**Visual Studio Code (VS Code)**
- Download: https://code.visualstudio.com/
- Free, powerful, and most popular for React development
- Helpful extensions:
  - ES7+ React/Redux/React-Native snippets
  - Tailwind CSS IntelliSense
  - TypeScript and JavaScript Language Features

**Alternatives:**
- WebStorm (paid, full-featured)
- Sublime Text
- Atom

### Step 3: Install Git (Optional)

**What is Git?**
- Version control system for tracking code changes
- Only needed if you want to clone repositories

**Download:**
- https://git-scm.com/downloads

---

## 📦 Package Dependencies Explained

### Core Packages (package.json)

#### 1. **React & React DOM**
```json
"react": "^18.3.1",
"react-dom": "^18.3.1"
```
- **What it does**: The main library for building user interfaces
- **React**: Core library with components, hooks, state management
- **React DOM**: Renders React components to the browser DOM
- **Why we need it**: Foundation of the entire application

#### 2. **TypeScript**
```json
"typescript": "^5.0.0",
"@types/react": "^18.3.0",
"@types/react-dom": "^18.3.0"
```
- **What it does**: Adds static typing to JavaScript
- **Why we need it**: Catch errors before runtime, better IDE support, safer code
- **Example**: Ensures product prices are numbers, not strings

#### 3. **Vite**
```json
"vite": "^5.0.0",
"@vitejs/plugin-react": "^4.0.0"
```
- **What it does**: Super-fast build tool and development server
- **Why we need it**: 
  - Instant hot module replacement (changes appear immediately)
  - Fast builds for production
  - Modern JavaScript features support

#### 4. **Tailwind CSS**
```json
"tailwindcss": "^4.0.0"
```
- **What it does**: Utility-first CSS framework
- **Why we need it**: 
  - Write CSS using classes like `bg-blue-500`, `text-center`
  - Responsive design with `md:`, `lg:` prefixes
  - No need to write custom CSS
- **Example**: `<button className="bg-blue-600 text-white px-4 py-2 rounded">`

#### 5. **Lucide React**
```json
"lucide-react": "latest"
```
- **What it does**: Icon library with 1000+ icons
- **Why we need it**: Beautiful, consistent icons throughout the app
- **Examples**: Shopping cart icon, user icon, search icon
- **Usage**: `import { ShoppingCart } from 'lucide-react'`

#### 6. **Sonner**
```json
"sonner": "^2.0.3"
```
- **What it does**: Toast notification library
- **Why we need it**: Show success/error messages to users
- **Examples**: 
  - "Product added to cart!"
  - "Order placed successfully!"
  - "Please fill all required fields"

#### 7. **Shadcn/UI Components**
- **What it does**: Pre-built, accessible UI components
- **Why we need it**: 
  - Saves development time
  - Consistent design
  - Accessible by default
- **Components included**:
  - Buttons, Cards, Dialogs, Forms
  - Tables, Tabs, Inputs, Selects
  - Dropdown menus, Tooltips, Badges
  - And 40+ more components

### Development Dependencies

#### 8. **ESLint**
```json
"eslint": "^8.0.0"
```
- **What it does**: Lints (checks) your code for errors and style issues
- **Why we need it**: Maintain code quality and consistency

---

## 🚀 Installation Steps

### Step 1: Get the Project Files

**Option A: If you have the ZIP file**
```bash
# Extract the ZIP file to a folder
# For example: C:\Users\YourName\Desktop\shophub
```

**Option B: If using Git**
```bash
git clone <repository-url>
cd shophub
```

### Step 2: Open Terminal/Command Prompt

**Windows:**
1. Press `Windows + R`
2. Type `cmd` and press Enter
3. Navigate to project folder:
   ```bash
   cd C:\Users\YourName\Desktop\shophub
   ```

**macOS/Linux:**
1. Open Terminal
2. Navigate to project folder:
   ```bash
   cd ~/Desktop/shophub
   ```

### Step 3: Install Dependencies

```bash
npm install
```

**What happens here:**
- npm reads `package.json`
- Downloads all required packages from npmjs.com
- Creates a `node_modules` folder with all dependencies
- This may take 2-5 minutes depending on internet speed

**Expected output:**
```
added 1234 packages in 2m
```

### Step 4: Start Development Server

```bash
npm run dev
```

**What happens here:**
- Vite starts a local development server
- Compiles your React/TypeScript code
- Opens the app in your browser

**Expected output:**
```
  VITE v5.0.0  ready in 500 ms

  ➜  Local:   http://localhost:5173/
  ➜  Network: use --host to expose
  ➜  press h + enter to show help
```

### Step 5: Open in Browser

1. Open your web browser (Chrome, Firefox, Edge, Safari)
2. Go to: `http://localhost:5173`
3. You should see the ShopHub homepage!

---

## 📁 Application Structure

### Entry Point Flow

```
index.html (loads)
    ↓
main.tsx (React entry)
    ↓
App.tsx (Main component)
    ↓
All Pages & Components
```

### File Structure Explained

#### `/App.tsx` - Main Application Controller
- **What it does**: Manages page navigation and routing
- **Contains**: Page state, navigation logic, component rendering
- **Renders**: Different pages based on current route (home, products, cart, etc.)

#### `/components/` - Reusable UI Components

**Main Pages:**
- `HomePage.tsx` - Landing page with hero section, featured products
- `ProductList.tsx` - Shows all products with filters and search
- `ProductDetail.tsx` - Individual product details page
- `CartPage.tsx` - Shopping cart with items and totals
- `CheckoutPage.tsx` - Checkout form and order placement
- `OrderTrackingPage.tsx` - View and track orders
- `AdminDashboard.tsx` - Admin panel for product/order management
- `AuthPages.tsx` - Login and signup forms

**Layout Components:**
- `Header.tsx` - Top navigation with search, cart, user menu
- `Footer.tsx` - Bottom section with links and copyright

**UI Components (`/components/ui/`):**
- Pre-built components from Shadcn/UI
- Styled, accessible, and ready to use
- Examples: Button, Card, Dialog, Table, Input, etc.

#### `/context/` - State Management

**What is Context?**
- React's way to share data between components without prop drilling
- Like a global store that any component can access

**Context Files:**

1. **AuthContext.tsx**
   - Manages user authentication state
   - Functions: login, logout, signup
   - Stores: current user, isAuthenticated

2. **CartContext.tsx**
   - Manages shopping cart
   - Functions: addToCart, removeFromCart, updateQuantity
   - Stores: cart items, total, count

3. **OrderContext.tsx**
   - Manages orders
   - Functions: createOrder, updateOrderStatus
   - Stores: all orders with status tracking

4. **ProductContext.tsx**
   - Manages product catalog
   - Functions: addProduct, updateProduct, deleteProduct
   - Stores: all products

#### `/data/` - Static Data

**products.ts**
- Contains 36 pre-loaded products
- Product details: name, price, image, description, category
- Can be modified via admin panel

#### `/types/` - TypeScript Type Definitions

**index.ts**
- Defines data structures for:
  - Product, User, CartItem, Order
  - Ensures type safety throughout app

#### `/styles/` - Global Styles

**globals.css**
- Tailwind CSS imports
- Custom CSS variables
- Typography settings
- Global reset styles

---

## ⚙️ How It Works

### User Flow - Customer Journey

#### 1. **Landing on Homepage**
```
User → Opens http://localhost:5173
     → Sees HomePage.tsx
     → Featured products, hero banner, categories
```

#### 2. **Browsing Products**
```
User → Clicks "Shop Now" or category
     → Goes to ProductList.tsx
     → Sees all products with search/filter
     → Can search by name or filter by category
```

#### 3. **Viewing Product Details**
```
User → Clicks on a product
     → Goes to ProductDetail.tsx
     → Sees full details, reviews, rating
     → Can add to cart
```

#### 4. **Adding to Cart**
```
User → Clicks "Add to Cart"
     → CartContext.addToCart() called
     → Item added to localStorage
     → Cart count updates in header
     → Toast notification: "Added to cart!"
```

#### 5. **Viewing Cart**
```
User → Clicks cart icon in header
     → Goes to CartPage.tsx
     → Sees all cart items
     → Can update quantity or remove items
     → Sees total price in ₹
```

#### 6. **Checkout Process**
```
User → Clicks "Proceed to Checkout"
     → Goes to CheckoutPage.tsx
     → Fills shipping address, payment details
     → Clicks "Place Order"
     → OrderContext.createOrder() called
     → Order saved to localStorage
     → Redirected to OrderTrackingPage
```

#### 7. **Tracking Orders**
```
User → Views OrderTrackingPage.tsx
     → Sees all orders with status
     → Can track: Pending → Confirmed → Shipped → Delivered
```

### Admin Flow - Management Journey

#### 1. **Admin Login**
```
Admin → Clicks "Login"
      → Enters admin@shophub.com / admin123
      → AuthContext.login() validates
      → User role set to 'admin'
      → Admin button appears in header
```

#### 2. **Accessing Dashboard**
```
Admin → Clicks "Admin" in header
      → Goes to AdminDashboard.tsx
      → Sees analytics: revenue, orders, products
```

#### 3. **Managing Products**
```
Admin → Clicks "Products" tab
      → Sees all products in table
      → Can Add/Edit/Delete products
      → Changes saved to ProductContext
      → Updates reflected immediately
```

#### 4. **Managing Orders**
```
Admin → Clicks "Orders" tab
      → Sees all customer orders
      → Can change status (dropdown)
      → Customer sees updated status
```

### Data Persistence

**LocalStorage Usage:**
```javascript
// When user adds to cart
localStorage.setItem('cart', JSON.stringify(cartItems))

// When page reloads
const savedCart = localStorage.getItem('cart')
const cart = savedCart ? JSON.parse(savedCart) : []
```

**What gets stored:**
- User authentication state
- Shopping cart items
- Product catalog (including admin changes)
- Order history

**Note:** Clearing browser data resets everything!

---

## 🎨 Features Breakdown

### 1. **Responsive Design**

**How it works:**
```tsx
// Tailwind responsive classes
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4">
  {/* 1 column on mobile, 2 on tablet, 4 on desktop */}
</div>
```

**Breakpoints:**
- Mobile: < 768px
- Tablet: 768px - 1023px
- Desktop: 1024px+

### 2. **Search & Filter**

**How it works:**
```typescript
// In ProductList.tsx
const filteredProducts = products.filter(product => 
  product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
  product.category.toLowerCase().includes(searchQuery.toLowerCase())
)
```

### 3. **Shopping Cart Calculations**

**How it works:**
```typescript
// In CartContext.tsx
const total = cartItems.reduce((sum, item) => 
  sum + (item.price * item.quantity), 0
)
```

### 4. **Order Tracking**

**Status Flow:**
```
Pending → Confirmed → Shipped → Delivered
   ↓         ↓          ↓          ↓
Yellow    Blue      Purple     Green
```

**Admin can update status, customer sees it in real-time**

### 5. **Role-Based Access**

**How it works:**
```typescript
// In App.tsx
{user?.role === 'admin' && (
  <Button onClick={() => setPage('admin')}>
    Admin Dashboard
  </Button>
)}
```

---

## 🔧 Common Commands

### Development
```bash
# Start dev server
npm run dev

# Stop server
Ctrl + C (in terminal)
```

### Building for Production
```bash
# Create optimized build
npm run build

# Preview production build
npm run preview
```

### Package Management
```bash
# Install new package
npm install package-name

# Update packages
npm update

# Check outdated packages
npm outdated
```

---

## 🌐 Accessing the Application

### Local Development
```
http://localhost:5173
```

### Network Access (from other devices on same WiFi)
```bash
# Start with network access
npm run dev -- --host

# Access from phone/tablet
http://192.168.x.x:5173
```

---

## 📊 Performance & Optimization

### What Vite Does:
1. **Hot Module Replacement (HMR)**
   - Changes appear instantly without page reload
   - Preserves application state

2. **Code Splitting**
   - Loads only what's needed
   - Faster initial load time

3. **Tree Shaking**
   - Removes unused code
   - Smaller bundle size

### What Tailwind Does:
1. **Purges Unused CSS**
   - Only includes classes you actually use
   - Tiny CSS file in production

2. **Optimized for Performance**
   - No runtime CSS generation
   - Cached efficiently

---

## 🔒 Security Considerations

### Current Implementation (Demo Only)
- ✅ Client-side only
- ✅ No real payment processing
- ✅ Mock authentication
- ✅ LocalStorage for data

### For Production (What You'd Need)
- ❌ Backend API with database
- ❌ Real authentication (JWT, OAuth)
- ❌ Encrypted passwords
- ❌ Payment gateway integration
- ❌ HTTPS/SSL certificate
- ❌ Rate limiting
- ❌ Input validation & sanitization

**⚠️ DO NOT use this for real customer data or payments!**

---

## 🎓 Learning Resources

### React
- Official Docs: https://react.dev
- Tutorial: https://react.dev/learn

### TypeScript
- Official Docs: https://www.typescriptlang.org/docs/
- Handbook: https://www.typescriptlang.org/docs/handbook/intro.html

### Tailwind CSS
- Official Docs: https://tailwindcss.com/docs
- Cheat Sheet: https://nerdcave.com/tailwind-cheat-sheet

### Vite
- Official Docs: https://vitejs.dev/guide/

---

## 💡 Next Steps After Setup

1. **Explore the Code**
   - Open files in VS Code
   - Read comments
   - Understand component structure

2. **Make Changes**
   - Modify colors in globals.css
   - Add new products in admin panel
   - Customize text and images

3. **Experiment**
   - Add new features
   - Create new components
   - Integrate with a backend

4. **Deploy**
   - Build for production: `npm run build`
   - Deploy to Vercel, Netlify, or GitHub Pages

---

## ❓ Troubleshooting

### Issue: "npm: command not found"
**Solution:** Node.js not installed correctly
```bash
# Reinstall Node.js from nodejs.org
# Restart terminal after installation
```

### Issue: Port 5173 already in use
**Solution:** Change port or kill existing process
```bash
# Kill process
# Windows: netstat -ano | findstr :5173
# Mac/Linux: lsof -ti:5173 | xargs kill -9
```

### Issue: Module not found errors
**Solution:** Reinstall dependencies
```bash
rm -rf node_modules package-lock.json
npm install
```

### Issue: Blank page after build
**Solution:** Check browser console for errors
```bash
# Usually a routing or path issue
# Check vite.config.ts base path
```

---

**🎉 Congratulations! You now understand how ShopHub works from top to bottom!**

For questions or issues, refer to README.md or review the code comments in each file.
