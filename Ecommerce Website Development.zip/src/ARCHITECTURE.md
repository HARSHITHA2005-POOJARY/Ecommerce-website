# 🏗️ ShopHub Architecture Guide

## 📐 Application Architecture Overview

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        BROWSER                               │
│  ┌───────────────────────────────────────────────────────┐  │
│  │              index.html (Entry Point)                  │  │
│  └────────────────────┬──────────────────────────────────┘  │
│                       │                                      │
│  ┌────────────────────▼──────────────────────────────────┐  │
│  │              main.tsx (React Root)                     │  │
│  │  • Imports React & ReactDOM                            │  │
│  │  • Renders <App /> component                           │  │
│  │  • Mounts to DOM                                       │  │
│  └────────────────────┬──────────────────────────────────┘  │
│                       │                                      │
│  ┌────────────────────▼──────────────────────────────────┐  │
│  │           App.tsx (Main Controller)                    │  │
│  │  ┌──────────────────────────────────────────────────┐ │  │
│  │  │        Context Providers (State)                  │ │  │
│  │  │  • AuthProvider                                   │ │  │
│  │  │  • ProductProvider                                │ │  │
│  │  │  • OrderProvider                                  │ │  │
│  │  │  • CartProvider                                   │ │  │
│  │  └──────────────────────────────────────────────────┘ │  │
│  │  ┌──────────────────────────────────────────────────┐ │  │
│  │  │        Routing Logic                              │ │  │
│  │  │  • currentPage state                              │ │  │
│  │  │  • handlePageChange()                             │ │  │
│  │  └──────────────────────────────────────────────────┘ │  │
│  │  ┌──────────────────────────────────────────────────┐ │  │
│  │  │        Conditional Rendering                      │ │  │
│  │  │  • Header (if not login/admin)                    │ │  │
│  │  │  • Current Page Component                         │ │  │
│  │  │  • Footer (if not login/admin)                    │ │  │
│  │  └──────────────────────────────────────────────────┘ │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                              │
│  ┌───────────────────────────────────────────────────────┐  │
│  │              Components Layer                          │  │
│  │  • HomePage          • ProductList                     │  │
│  │  • ProductDetail     • CartPage                        │  │
│  │  • CheckoutPage      • OrderTrackingPage              │  │
│  │  • AdminDashboard    • AuthPages                       │  │
│  │  • Header            • Footer                          │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                              │
│  ┌───────────────────────────────────────────────────────┐  │
│  │           LocalStorage (Data Persistence)              │  │
│  │  • user              • cart                            │  │
│  │  • products          • orders                          │  │
│  └───────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔄 Data Flow Architecture

### Context API State Management

```
┌──────────────────────────────────────────────────────────┐
│                   Context Providers                       │
├──────────────────────────────────────────────────────────┤
│                                                           │
│  ┌────────────────────────────────────────────────────┐  │
│  │  AuthContext                                       │  │
│  │  ┌──────────────────────────────────────────────┐ │  │
│  │  │  State:                                       │ │  │
│  │  │  • user: User | null                          │ │  │
│  │  │  • isAuthenticated: boolean                   │ │  │
│  │  │                                               │ │  │
│  │  │  Actions:                                     │ │  │
│  │  │  • login(email, password)                     │ │  │
│  │  │  • signup(name, email, password)              │ │  │
│  │  │  • logout()                                   │ │  │
│  │  │                                               │ │  │
│  │  │  Storage: localStorage.user                   │ │  │
│  │  └──────────────────────────────────────────────┘ │  │
│  └────────────────────────────────────────────────────┘  │
│                                                           │
│  ┌────────────────────────────────────────────────────┐  │
│  │  ProductContext                                    │  │
│  │  ┌──────────────────────────────────────────────┐ │  │
│  │  │  State:                                       │ │  │
│  │  │  • products: Product[]                        │ │  │
│  │  │                                               │ │  │
│  │  │  Actions:                                     │ │  │
│  │  │  • addProduct(product)                        │ │  │
│  │  │  • updateProduct(id, updates)                 │ │  │
│  │  │  • deleteProduct(id)                          │ │  │
│  │  │                                               │ │  │
│  │  │  Storage: localStorage.products               │ │  │
│  │  └──────────────────────────────────────────────┘ │  │
│  └────────────────────────────────────────────────────┘  │
│                                                           │
│  ┌────────────────────────────────────────────────────┐  │
│  │  CartContext                                       │  │
│  │  ┌──────────────────────────────────────────────┐ │  │
│  │  │  State:                                       │ │  │
│  │  │  • cartItems: CartItem[]                      │ │  │
│  │  │                                               │ │  │
│  │  │  Actions:                                     │ │  │
│  │  │  • addToCart(product, quantity)               │ │  │
│  │  │  • removeFromCart(productId)                  │ │  │
│  │  │  • updateQuantity(productId, quantity)        │ │  │
│  │  │  • clearCart()                                │ │  │
│  │  │  • getCartTotal()                             │ │  │
│  │  │  • getCartCount()                             │ │  │
│  │  │                                               │ │  │
│  │  │  Storage: localStorage.cart                   │ │  │
│  │  └──────────────────────────────────────────────┘ │  │
│  └────────────────────────────────────────────────────┘  │
│                                                           │
│  ┌────────────────────────────────────────────────────┐  │
│  │  OrderContext                                      │  │
│  │  ┌──────────────────────────────────────────────┐ │  │
│  │  │  State:                                       │ │  │
│  │  │  • orders: Order[]                            │ │  │
│  │  │                                               │ │  │
│  │  │  Actions:                                     │ │  │
│  │  │  • createOrder(orderData)                     │ │  │
│  │  │  • updateOrderStatus(orderId, status)         │ │  │
│  │  │  • getUserOrders(userId)                      │ │  │
│  │  │                                               │ │  │
│  │  │  Storage: localStorage.orders                 │ │  │
│  │  └──────────────────────────────────────────────┘ │  │
│  └────────────────────────────────────────────────────┘  │
│                                                           │
└──────────────────────────────────────────────────────────┘
```

---

## 🛣️ User Journey Flow

### Customer Journey

```
START
  │
  ▼
┌─────────────┐
│  HomePage   │  User lands on site
└──────┬──────┘
       │ Click "Shop Now" or Category
       ▼
┌─────────────────┐
│  ProductList    │  Browse all products
│  • Search       │  • Filter by category
│  • Filter       │  • See product cards
└──────┬──────────┘
       │ Click on Product
       ▼
┌─────────────────┐
│ ProductDetail   │  View full details
│  • Images       │  • Add to cart
│  • Description  │  • See reviews
│  • Reviews      │
└──────┬──────────┘
       │ Click "Add to Cart"
       ▼
┌─────────────────┐
│  Toast Notif    │  "Added to cart!"
└──────┬──────────┘
       │ Click Cart Icon
       ▼
┌─────────────────┐
│   CartPage      │  Review cart items
│  • View Items   │  • Update quantity
│  • See Total    │  • Remove items
└──────┬──────────┘
       │ Click "Checkout"
       ▼
┌─────────────────┐
│ Not Logged In?  │──Yes──┐
└──────┬──────────┘       │
       │ No               ▼
       │           ┌──────────────┐
       │           │  AuthPages   │  Login/Signup
       │           │  • Login     │
       │           │  • Signup    │
       │           └──────┬───────┘
       │                  │
       ▼                  │
┌──────────────────┐      │
│  CheckoutPage    │◄─────┘
│  • Address Form  │
│  • Payment Info  │
│  • Order Summary │
└──────┬───────────┘
       │ Click "Place Order"
       ▼
┌──────────────────┐
│  Order Created   │  Order saved
│  • Clear Cart    │  • Generate Order ID
└──────┬───────────┘
       │
       ▼
┌──────────────────────┐
│  OrderTrackingPage   │  View order status
│  • Order Details     │  • Track progress
│  • Status: Pending   │  • Timeline view
└──────────────────────┘
       │
       ▼
END (Can continue shopping)
```

### Admin Journey

```
START
  │
  ▼
┌─────────────┐
│  HomePage   │  Admin visits site
└──────┬──────┘
       │ Click "Login"
       ▼
┌─────────────────┐
│   AuthPages     │  Enter admin credentials
│  Email:         │  admin@shophub.com
│  Password:      │  admin123
└──────┬──────────┘
       │ Login Success (role: admin)
       ▼
┌─────────────────┐
│  Header         │  "Admin" button appears
└──────┬──────────┘
       │ Click "Admin"
       ▼
┌──────────────────────────────────────┐
│        AdminDashboard                │
│  ┌────────────────────────────────┐ │
│  │  Analytics Overview            │ │
│  │  • Total Revenue: ₹X           │ │
│  │  • Total Orders: X             │ │
│  │  • Total Products: X           │ │
│  │  • Pending Orders: X           │ │
│  └────────────────────────────────┘ │
│                                      │
│  ┌────────────────────────────────┐ │
│  │  Tabs:                         │ │
│  │  ┌──────────────────────────┐ │ │
│  │  │  Products Tab            │ │ │
│  │  │  • View all products     │ │ │
│  │  │  • Add new product       │ │ │
│  │  │  • Edit product          │ │ │
│  │  │  • Delete product        │ │ │
│  │  └──────────────────────────┘ │ │
│  │  ┌──────────────────────────┐ │ │
│  │  │  Orders Tab              │ │ │
│  │  │  • View all orders       │ │ │
│  │  │  • Update status         │ │ │
│  │  │  • See customer details  │ │ │
│  │  └──────────────────────────┘ │ │
│  │  ┌──────────────────────────┐ │ │
│  │  │  Analytics Tab           │ │ │
│  │  │  • Revenue charts        │ │ │
│  │  │  • Order distribution    │ │ │
│  │  │  • Top categories        │ │ │
│  │  └──────────────────────────┘ │ │
│  └────────────────────────────────┘ │
└──────────────────────────────────────┘
       │
       ▼
END (Can logout or go back to store)
```

---

## 🗃️ Data Models (TypeScript Types)

### Type Definitions

```typescript
// User Type
interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  role: "customer" | "admin";
}

// Product Type
interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  discount?: number;
  category: string;
  image: string;
  rating: number;
  reviews: number;
  inStock: boolean;
  brand: string;
  tags: string[];
}

// Cart Item Type
interface CartItem {
  productId: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
}

// Order Type
interface Order {
  id: string;
  orderId: string; // Human-readable ID (e.g., "ORD-20241215-001")
  userId: string;
  userName: string;
  userEmail: string;
  items: CartItem[];
  total: number;
  status:
    | "pending"
    | "confirmed"
    | "shipped"
    | "delivered"
    | "cancelled";
  shippingAddress: Address;
  paymentMethod: string;
  createdAt: string;
  updatedAt: string;
}

// Address Type
interface Address {
  fullName: string;
  phone: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  state: string;
  pincode: string;
}
```

---

## 🔌 Component Communication

### Props Drilling vs Context

```
❌ Without Context (Props Drilling)
┌─────────────┐
│    App      │
└──────┬──────┘
       │ user={user}
       ▼
┌─────────────┐
│   Header    │
└──────┬──────┘
       │ user={user}
       ▼
┌─────────────┐
│  UserMenu   │  Finally uses user!
└─────────────┘

✅ With Context
┌─────────────────┐
│  AuthProvider   │  Wraps entire app
└─────────────────┘
       ↓
    useAuth()  ← Any component can access
       ↑
┌─────────────┐
│  UserMenu   │  Directly gets user
└─────────────┘
```

---

## 🎨 Styling Architecture

### Tailwind CSS Utility Classes

```
Component Structure:
┌─────────────────────────────────────────┐
│  <div className="container mx-auto">   │  ← Container
│    ┌───────────────────────────────┐   │
│    │  <div className="grid         │   │  ← Grid Layout
│    │         grid-cols-1          │   │
│    │         md:grid-cols-2       │   │  ← Responsive
│    │         lg:grid-cols-4       │   │
│    │         gap-6">              │   │  ← Spacing
│    │    ┌─────────────────────┐   │   │
│    │    │  <Card>             │   │   │  ← Component
│    │    │    Content          │   │   │
│    │    │  </Card>            │   │   │
│    │    └─────────────────────┘   │   │
│    │  </div>                      │   │
│    └───────────────────────────────┘   │
│  </div>                                │
└─────────────────────────────────────────┘

Breakpoints:
• Default (Mobile): 0px - 767px
• md (Tablet):      768px - 1023px
• lg (Desktop):     1024px+
```

---

## 🔄 Component Lifecycle

### React Component Flow

```
Component Creation:
1. Component function called
2. State initialized (useState, useContext)
3. JSX returned
4. Browser DOM updated
5. useEffect runs (if any)

Component Update:
1. State/Props change
2. Component re-renders
3. Virtual DOM diff
4. Real DOM updated (only changes)
5. useEffect cleanup + run (if dependencies changed)

Component Cleanup:
1. Component removed from screen
2. useEffect cleanup functions run
3. Memory freed
```

### Example: ProductList Component

```typescript
function ProductList() {
  // 1. Get data from contexts
  const { products } = useProducts();
  const { addToCart } = useCart();

  // 2. Local state
  const [filteredProducts, setFilteredProducts] = useState([]);

  // 3. Effects
  useEffect(() => {
    // Runs when products change
    setFilteredProducts(products);
  }, [products]);

  // 4. Event handlers
  const handleAddToCart = (product) => {
    addToCart(product, 1);
    toast.success('Added to cart!');
  };

  // 5. Render JSX
  return (
    <div>
      {filteredProducts.map(product => (
        <ProductCard
          key={product.id}
          product={product}
          onAddToCart={handleAddToCart}
        />
      ))}
    </div>
  );
}
```

---

## 📦 Build Process

### Development Build (npm run dev)

```
┌─────────────────────────────────────────────┐
│  Vite Development Server                    │
├─────────────────────────────────────────────┤
│                                             │
│  1. Read vite.config.ts                    │
│     ↓                                       │
│  2. Start dev server on :5173              │
│     ↓                                       │
│  3. Transform files on-demand:              │
│     • .tsx → JavaScript                    │
│     • .css → Styles                        │
│     • TypeScript → JavaScript              │
│     ↓                                       │
│  4. Inject Hot Module Replacement (HMR)    │
│     • Watch for file changes               │
│     • Update browser instantly             │
│     ↓                                       │
│  5. Serve to browser                       │
│                                             │
└─────────────────────────────────────────────┘
```

### Production Build (npm run build)

```
┌─────────────────────────────────────────────┐
│  Vite Production Build                      │
├─────────────────────────────────────────────┤
│                                             │
│  1. TypeScript Compilation                 │
│     • Check types                          │
│     • Convert .tsx to .js                  │
│     ↓                                       │
│  2. Bundle JavaScript                      │
│     • Tree shaking (remove unused code)    │
│     • Code splitting                       │
│     • Minification                         │
│     ↓                                       │
│  3. Process CSS                            │
│     • Tailwind: purge unused classes       │
│     • Minify CSS                          │
│     ↓                                       │
│  4. Optimize Assets                        │
│     • Compress images                      │
│     • Generate hashed filenames            │
│     ↓                                       │
│  5. Output to /dist folder                 │
│     • index.html                           │
│     • assets/index-[hash].js               │
│     • assets/index-[hash].css              │
│                                             │
└─────────────────────────────────────────────┘
```

---

## 🌐 Browser Rendering

### Initial Page Load

```
1. Browser requests http://localhost:5173
   ↓
2. Server sends index.html
   ↓
3. Browser parses HTML
   ↓
4. Finds <script type="module" src="/src/main.tsx">
   ↓
5. Browser requests main.tsx
   ↓
6. Vite transforms TypeScript → JavaScript
   ↓
7. Browser executes JavaScript
   ↓
8. React renders virtual DOM
   ↓
9. React updates real DOM
   ↓
10. User sees the page!
```

---

## 🔐 Authentication Flow

```
┌──────────────────────────────────────────────────────┐
│  Login Process                                        │
├──────────────────────────────────────────────────────┤
│                                                       │
│  User enters credentials                             │
│    ↓                                                  │
│  AuthPages.tsx → handleLogin()                       │
│    ↓                                                  │
│  AuthContext.login(email, password)                  │
│    ↓                                                  │
│  Check credentials:                                  │
│    • If admin@shophub.com → role: 'admin'           │
│    • Else → role: 'customer'                        │
│    ↓                                                  │
│  Create User object                                  │
│    ↓                                                  │
│  setUser(mockUser)                                   │
│    ↓                                                  │
│  useEffect saves to localStorage                     │
│    ↓                                                  │
│  User is logged in!                                  │
│    ↓                                                  │
│  Redirect to HomePage                                │
│                                                       │
└──────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────┐
│  Logout Process                                       │
├──────────────────────────────────────────────────────┤
│                                                       │
│  User clicks "Logout"                                │
│    ↓                                                  │
│  AuthContext.logout()                                │
│    ↓                                                  │
│  setUser(null)                                       │
│    ↓                                                  │
│  useEffect removes from localStorage                 │
│    ↓                                                  │
│  User is logged out!                                 │
│    ↓                                                  │
│  Redirect to HomePage                                │
│                                                       │
└──────────────────────────────────────────────────────┘
```

---

This architecture document provides a comprehensive visual guide to understanding how ShopHub is structured and how all pieces work together!