# 🔍 Quick Guide: How to Check the Database

## 3 Easy Ways to Check Your Database

---

## ✅ Method 1: Admin Dashboard (Easiest)

### Step 1: Login as Admin
1. Go to ShopHub homepage
2. Click **"Login"** (top right)
3. Enter admin credentials
4. Click **"Admin Dashboard"**

### Step 2: View Audit Logs
1. Click the **"Audit Logs"** tab
2. You'll see all database actions tracked:
   - Who performed the action
   - What they did
   - When it happened
   - Success or failure status

### Step 3: Use Filters
- **Search**: Type to find specific actions
- **Filter by Action**: Select from dropdown (LOGIN, PRODUCT_ADD, etc.)
- **Filter by Entity**: Choose entity type (USER, PRODUCT, ORDER, etc.)
- **Filter by User**: See actions by specific user
- **Date Range**: Select start and end dates

### Step 4: View Details
- Click the **eye icon** on any log entry
- See complete information including IP address, user agent, and error messages

### Step 5: Export Data
- Click **"Export CSV"** to download all logs
- Open in Excel or Google Sheets for analysis

---

## ✅ Method 2: Supabase Dashboard (Direct Access)

### Step 1: Login to Supabase
1. Go to [https://app.supabase.com](https://app.supabase.com)
2. Login with your Supabase credentials
3. Select your ShopHub project

### Step 2: Open Table Editor
1. Click **"Table Editor"** in the left sidebar
2. Find the `kv_store_6d108759` table
3. Click to view all data

### Step 3: View Audit Logs
Look for keys starting with:
- `audit:2024-12-11T...:{id}` - Main audit logs
- `audit:user:{userId}:...` - User-specific logs
- `audit:entity:{entityType}:{entityId}:...` - Entity-specific logs

### Step 4: Run SQL Queries
1. Click **"SQL Editor"** in the sidebar
2. Write custom queries to analyze your data

#### Example Queries:
```sql
-- Get all audit logs
SELECT * FROM kv_store_6d108759 
WHERE key LIKE 'audit:%' 
ORDER BY key DESC 
LIMIT 100;

-- Get logs for a specific user
SELECT * FROM kv_store_6d108759 
WHERE key LIKE 'audit:user:USER_ID_HERE:%';

-- Count logs by action type
SELECT 
  value->>'action' as action,
  COUNT(*) as count
FROM kv_store_6d108759 
WHERE key LIKE 'audit:%'
GROUP BY value->>'action'
ORDER BY count DESC;

-- Get failed actions
SELECT * FROM kv_store_6d108759 
WHERE key LIKE 'audit:%' 
AND value->>'success' = 'false';

-- Get recent activity (last 24 hours)
SELECT * FROM kv_store_6d108759 
WHERE key LIKE 'audit:%'
AND (value->>'timestamp')::timestamp > NOW() - INTERVAL '24 hours'
ORDER BY value->>'timestamp' DESC;
```

---

## ✅ Method 3: API Endpoints (For Developers)

### Get All Logs
```bash
curl https://YOUR_PROJECT_ID.supabase.co/functions/v1/make-server-6d108759/audit/logs?limit=100 \
  -H "Authorization: Bearer YOUR_ANON_KEY"
```

### Get Logs for Specific User
```bash
curl https://YOUR_PROJECT_ID.supabase.co/functions/v1/make-server-6d108759/audit/logs/user/USER_ID \
  -H "Authorization: Bearer YOUR_ANON_KEY"
```

### Get Logs by Date Range
```bash
curl "https://YOUR_PROJECT_ID.supabase.co/functions/v1/make-server-6d108759/audit/logs/date-range?startDate=2024-12-01&endDate=2024-12-31&limit=500" \
  -H "Authorization: Bearer YOUR_ANON_KEY"
```

### Get Statistics
```bash
curl https://YOUR_PROJECT_ID.supabase.co/functions/v1/make-server-6d108759/audit/stats \
  -H "Authorization: Bearer YOUR_ANON_KEY"
```

---

## 📊 What You Can Track

### Every database action is logged with:
- ✅ **Timestamp** - Exact date and time
- ✅ **User Info** - Who did it (ID, email, role)
- ✅ **Action** - What they did (LOGIN, PRODUCT_ADD, etc.)
- ✅ **Entity** - What was affected (USER, PRODUCT, ORDER, etc.)
- ✅ **Details** - Additional context
- ✅ **IP Address** - Where it came from
- ✅ **Success/Failure** - Whether it worked
- ✅ **Error Messages** - If something went wrong

### Tracked Actions:
- 🔐 Login/Logout
- 📦 Product Add/Update/Delete
- 🛒 Cart Actions
- 📝 Order Creation/Updates
- 👥 Employee Management
- 📅 Attendance Tracking
- 🏪 Seller Management
- ⚙️ Settings Changes
- ...and more!

---

## 🎯 Common Tasks

### See who modified a product
1. Go to Admin Dashboard → Audit Logs
2. Filter by Entity Type: **PRODUCT**
3. Search for the product name

### Check failed login attempts
1. Go to Admin Dashboard → Audit Logs
2. Filter by Action: **LOGIN_FAILED**
3. Review the list

### View employee attendance history
1. Go to Admin Dashboard → Audit Logs
2. Filter by Action: **ATTENDANCE_MARK**
3. Filter by User: (employee email)

### Generate monthly report
1. Go to Admin Dashboard → Audit Logs
2. Set Date Range: First to last day of month
3. Click **"Export CSV"**
4. Open in Excel/Sheets for analysis

### Monitor system health
1. Go to Admin Dashboard → Audit Logs
2. View the statistics cards at the top
3. Check "Failed Actions" count
4. Review recent activity

---

## 🚨 What to Monitor

### Security Red Flags:
- ⚠️ Multiple failed login attempts from same IP
- ⚠️ Unauthorized access attempts
- ⚠️ Unusual deletion patterns
- ⚠️ After-hours activity
- ⚠️ High number of failed actions

### Performance Indicators:
- ✅ Successful vs. failed action ratio
- ✅ Most active users
- ✅ Most common actions
- ✅ Peak usage times
- ✅ Error patterns

---

## 💡 Pro Tips

1. **Check logs daily** - Stay on top of what's happening
2. **Export regularly** - Backup your audit trail
3. **Look for patterns** - Unusual activity may indicate issues
4. **Use date filters** - Focus on specific time periods
5. **Monitor failed actions** - They often reveal problems
6. **Track specific users** - Helpful for support and training
7. **Clean old logs** - Keep database size manageable

---

## 📞 Quick Reference

| What You Want | Where to Go | What to Do |
|---------------|-------------|------------|
| See all activity | Admin Dashboard | Audit Logs tab |
| Check specific user | Admin Dashboard | Audit Logs → Filter by User |
| View product changes | Admin Dashboard | Audit Logs → Filter by PRODUCT |
| Export data | Admin Dashboard | Audit Logs → Export CSV |
| Run custom queries | Supabase Dashboard | SQL Editor |
| Get raw data | Supabase Dashboard | Table Editor |
| Programmatic access | API | Use curl/fetch |

---

## 🎓 Need More Help?

- **Full Documentation**: See `/DATABASE_AUDIT_GUIDE.md`
- **Code Examples**: See `/supabase/functions/server/exampleWithAudit.tsx`
- **Admin Dashboard**: Login and explore the Audit Logs tab

---

**Remember**: The database automatically tracks EVERYTHING. You just need to look! 👀
