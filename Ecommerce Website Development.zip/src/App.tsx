import React, { useState, useEffect } from "react";
import { Toaster } from "./components/ui/sonner";
import { Header } from "./components/Header";
import { Footer } from "./components/Footer";
import { HomePage } from "./components/HomePage";
import { ProductList } from "./components/ProductList";
import { ProductDetail } from "./components/ProductDetail";
import { CartPage } from "./components/CartPage";
import { CheckoutPage } from "./components/CheckoutPage";
import { AuthPages } from "./components/AuthPages";
import { OrderTrackingPage } from "./components/OrderTrackingPage";
import { AdminDashboard } from "./components/AdminDashboard";
import { SellerDashboard } from "./components/SellerDashboard";
import { EmployeeDashboard } from "./components/EmployeeDashboard";
import { LocalStorageModeBanner } from "./components/LocalStorageModeBanner";
import { CartProvider } from "./context/CartContext";
import { AuthProvider } from "./context/AuthContext";
import { OrderProvider } from "./context/OrderContext";
import { ProductProvider } from "./context/ProductContext";
import { SellerProvider } from "./context/SellerContext";
import { EmployeeProvider } from "./context/EmployeeContext";

type Page =
  | "home"
  | "products"
  | "product"
  | "cart"
  | "checkout"
  | "login"
  | "orders"
  | "admin"
  | "seller"
  | "employee";

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>("home");
  const [selectedProductId, setSelectedProductId] =
    useState<string>("");
  const [searchQuery, setSearchQuery] = useState("");

  const handlePageChange = (
    page: string,
    productId?: string,
  ) => {
    setCurrentPage(page as Page);
    if (productId) {
      setSelectedProductId(productId);
    }
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  useEffect(() => {
    // Reset search when leaving products page
    if (currentPage !== "products") {
      setSearchQuery("");
    }
  }, [currentPage]);

  return (
    <AuthProvider>
      <SellerProvider>
        <EmployeeProvider>
          <ProductProvider>
            <OrderProvider>
              <CartProvider>
                <div className="min-h-screen flex flex-col">
                  <LocalStorageModeBanner />
                  {currentPage !== "login" &&
                    currentPage !== "admin" &&
                    currentPage !== "seller" &&
                    currentPage !== "employee" && (
                      <Header
                        onPageChange={handlePageChange}
                        onSearch={handleSearch}
                        currentPage={currentPage}
                      />
                    )}

              <main className="flex-1">
                {currentPage === "home" && (
                  <HomePage
                    onPageChange={handlePageChange}
                    onSearch={handleSearch}
                  />
                )}
                {currentPage === "products" && (
                  <ProductList
                    onPageChange={handlePageChange}
                    searchQuery={searchQuery}
                  />
                )}
                {currentPage === "product" && (
                  <ProductDetail
                    productId={selectedProductId}
                    onPageChange={handlePageChange}
                  />
                )}
                {currentPage === "cart" && (
                  <CartPage onPageChange={handlePageChange} />
                )}
                {currentPage === "checkout" && (
                  <CheckoutPage
                    onPageChange={handlePageChange}
                  />
                )}
                {currentPage === "login" && (
                  <AuthPages onPageChange={handlePageChange} />
                )}
                {currentPage === "orders" && (
                  <OrderTrackingPage
                    onPageChange={handlePageChange}
                  />
                )}
                {currentPage === "admin" && (
                  <AdminDashboard
                    onPageChange={handlePageChange}
                  />
                )}
                {currentPage === "seller" && (
                  <SellerDashboard onPageChange={handlePageChange} />
                )}
                {currentPage === "employee" && (
                  <EmployeeDashboard onPageChange={handlePageChange} />
                )}
              </main>

              {currentPage !== "login" &&
                currentPage !== "admin" &&
                currentPage !== "seller" &&
                currentPage !== "employee" && <Footer />}

              <Toaster position="top-center" />
            </div>
          </CartProvider>
        </OrderProvider>
      </ProductProvider>
    </EmployeeProvider>
  </SellerProvider>
</AuthProvider>
  );
}