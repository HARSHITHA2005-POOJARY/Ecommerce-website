# 🚀 ShopHub Backend API

Complete Node.js + Express + PostgreSQL backend for ShopHub E-commerce Platform.

## 📋 Table of Contents

- [Features](#features)
- [Tech Stack](#tech-stack)
- [Prerequisites](#prerequisites)
- [Installation](#installation)
- [Database Setup](#database-setup)
- [Running the Server](#running-the-server)
- [API Documentation](#api-documentation)
- [Environment Variables](#environment-variables)
- [Database Schema](#database-schema)

---

## ✨ Features

### Authentication & Authorization
- ✅ JWT-based authentication
- ✅ Role-based access control (Customer, Seller, Admin)
- ✅ Password hashing with bcrypt
- ✅ Secure token management

### Product Management
- ✅ CRUD operations for products
- ✅ Advanced filtering (category, price, rating, search)
- ✅ Pagination support
- ✅ Seller-product association
- ✅ Stock management

### Order Management
- ✅ Create and track orders
- ✅ Order status updates (Pending, Confirmed, Shipped, Delivered, Cancelled)
- ✅ Order history
- ✅ Automatic commission calculation
- ✅ Stock reduction on purchase

### Seller System
- ✅ Seller registration with approval workflow
- ✅ Commission management
- ✅ Sales tracking
- ✅ Seller dashboard analytics
- ✅ Seller-specific product management

### Employee & HR Management
- ✅ Employee CRUD operations
- ✅ Attendance tracking (Present, Absent, Half-Day, Leave)
- ✅ Automatic payroll calculation
- ✅ Monthly attendance reports
- ✅ Department-wise analytics

### Shopping Cart
- ✅ Persistent cart (database-backed)
- ✅ Add, update, remove items
- ✅ Maximum quantity limit (30 per product)
- ✅ Stock validation

---

## 🛠 Tech Stack

- **Runtime:** Node.js 18+
- **Framework:** Express.js
- **Language:** TypeScript
- **Database:** PostgreSQL
- **ORM:** Prisma
- **Authentication:** JWT
- **Validation:** Express Validator
- **Security:** bcryptjs, CORS

---

## 📦 Prerequisites

Before you begin, ensure you have installed:

- **Node.js** (v18 or higher) - [Download](https://nodejs.org/)
- **PostgreSQL** (v14 or higher) - [Download](https://www.postgresql.org/download/)
- **npm** or **yarn**

---

## 🚀 Installation

### 1. Clone the Repository

```bash
cd backend
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Set Up Environment Variables

Create a `.env` file in the backend directory:

```bash
cp .env.example .env
```

Edit `.env` with your configuration:

```env
# Database
DATABASE_URL="postgresql://username:password@localhost:5432/shophub?schema=public"

# JWT
JWT_SECRET="your-super-secret-jwt-key-change-this-in-production"
JWT_EXPIRES_IN="7d"

# Server
PORT=5000
NODE_ENV="development"

# CORS
FRONTEND_URL="http://localhost:3000"
```

---

## 💾 Database Setup

### 1. Create PostgreSQL Database

```bash
# Using psql
psql -U postgres

CREATE DATABASE shophub;
\q
```

Or using GUI tools like pgAdmin.

### 2. Run Prisma Migrations

```bash
npm run prisma:generate
npm run prisma:migrate
```

This creates all necessary tables in your database.

### 3. Seed Database (Optional)

```bash
npm run seed
```

This creates:
- ✅ Admin user (`admin@shophub.com` / `admin123`)
- ✅ Test seller (`test@seller.com` / `seller123`)
- ✅ Sample products (8 products across categories)

---

## ▶️ Running the Server

### Development Mode (with auto-reload)

```bash
npm run dev
```

Server starts on `http://localhost:5000`

### Production Mode

```bash
npm run build
npm start
```

---

## 📡 API Documentation

### Base URL
```
http://localhost:5000/api
```

### Authentication

All protected routes require JWT token in header:
```
Authorization: Bearer <your_jwt_token>
```

---

### 🔐 Auth Routes (`/api/auth`)

#### Register User
```http
POST /api/auth/register
Content-Type: application/json

{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "password123",
  "role": "CUSTOMER"  // Optional: CUSTOMER (default), SELLER, ADMIN
}
```

**Response:**
```json
{
  "success": true,
  "message": "User registered successfully",
  "data": {
    "user": {
      "id": "uuid",
      "name": "John Doe",
      "email": "john@example.com",
      "role": "CUSTOMER"
    },
    "token": "jwt_token_here"
  }
}
```

#### Login
```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "admin@shophub.com",
  "password": "admin123"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "user": { /* user object */ },
    "token": "jwt_token_here"
  }
}
```

#### Get Profile (Protected)
```http
GET /api/auth/me
Authorization: Bearer <token>
```

---

### 📦 Product Routes (`/api/products`)

#### Get All Products (Public)
```http
GET /api/products?category=Electronics&search=phone&minPrice=1000&maxPrice=50000&page=1&limit=20
```

**Query Parameters:**
- `category` - Filter by category
- `search` - Search in name, description, brand
- `minPrice` - Minimum price
- `maxPrice` - Maximum price
- `minRating` - Minimum rating
- `sortBy` - Sort field (createdAt, price, rating)
- `order` - Sort order (asc, desc)
- `page` - Page number
- `limit` - Items per page

#### Get Product by ID (Public)
```http
GET /api/products/:id
```

#### Create Product (Admin/Seller)
```http
POST /api/products
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "Product Name",
  "description": "Product description",
  "price": 9999,
  "originalPrice": 12999,
  "discount": 23,
  "category": "Electronics",
  "brand": "Brand Name",
  "image": "https://example.com/image.jpg",
  "stock": 100,
  "rating": 4.5,
  "tags": ["tag1", "tag2"]
}
```

#### Update Product (Admin/Seller - own products)
```http
PUT /api/products/:id
Authorization: Bearer <token>
Content-Type: application/json

{
  "price": 8999,
  "stock": 80
}
```

#### Delete Product (Admin/Seller - own products)
```http
DELETE /api/products/:id
Authorization: Bearer <token>
```

---

### 🛒 Cart Routes (`/api/cart`)

All cart routes require authentication.

#### Get Cart
```http
GET /api/cart
Authorization: Bearer <token>
```

#### Add to Cart
```http
POST /api/cart/add
Authorization: Bearer <token>
Content-Type: application/json

{
  "productId": "product_uuid",
  "quantity": 1
}
```

#### Update Quantity
```http
PUT /api/cart/update/:productId
Authorization: Bearer <token>
Content-Type: application/json

{
  "quantity": 5
}
```

**Note:** Maximum quantity is 30 per product.

#### Remove from Cart
```http
DELETE /api/cart/remove/:productId
Authorization: Bearer <token>
```

#### Clear Cart
```http
DELETE /api/cart/clear
Authorization: Bearer <token>
```

---

### 📦 Order Routes (`/api/orders`)

#### Create Order (Authenticated)
```http
POST /api/orders
Authorization: Bearer <token>
Content-Type: application/json

{
  "items": [
    {
      "productId": "uuid",
      "quantity": 2,
      "price": 9999
    }
  ],
  "subtotal": 19998,
  "shipping": 99,
  "tax": 1999.8,
  "total": 22096.8,
  "shippingAddress": {
    "fullName": "John Doe",
    "email": "john@example.com",
    "phone": "+91 9876543210",
    "address": "123 Main St",
    "city": "Mumbai",
    "state": "Maharashtra",
    "zipCode": "400001"
  },
  "paymentMethod": "COD"
}
```

#### Get User Orders (Authenticated)
```http
GET /api/orders
Authorization: Bearer <token>
```

#### Get Order by ID (Authenticated)
```http
GET /api/orders/:id
Authorization: Bearer <token>
```

#### Get All Orders (Admin)
```http
GET /api/orders/all/admin?status=PENDING&page=1&limit=50
Authorization: Bearer <admin_token>
```

#### Update Order Status (Admin)
```http
PUT /api/orders/:id/status
Authorization: Bearer <admin_token>
Content-Type: application/json

{
  "status": "SHIPPED"
}
```

**Valid Statuses:** PENDING, CONFIRMED, SHIPPED, DELIVERED, CANCELLED

---

### 🏪 Seller Routes (`/api/sellers`)

#### Register as Seller (Public)
```http
POST /api/sellers/register
Content-Type: application/json

{
  "name": "Seller Name",
  "email": "seller@example.com",
  "password": "password123",
  "businessName": "My Business",
  "phone": "+91 9876543210",
  "gst": "22AAAAA0000A1Z5",  // Optional
  "address": "Business Address"
}
```

#### Get All Sellers (Admin)
```http
GET /api/sellers?approved=true&page=1&limit=50
Authorization: Bearer <admin_token>
```

#### Approve Seller (Admin)
```http
PUT /api/sellers/:id/approve
Authorization: Bearer <admin_token>
Content-Type: application/json

{
  "approved": true
}
```

#### Update Commission (Admin)
```http
PUT /api/sellers/:id/commission
Authorization: Bearer <admin_token>
Content-Type: application/json

{
  "commission": 12.5
}
```

#### Get Seller Profile (Seller)
```http
GET /api/sellers/me
Authorization: Bearer <seller_token>
```

#### Get Seller Analytics (Seller)
```http
GET /api/sellers/me/analytics
Authorization: Bearer <seller_token>
```

#### Get Seller Products (Seller)
```http
GET /api/sellers/me/products
Authorization: Bearer <seller_token>
```

#### Get Seller Orders (Seller)
```http
GET /api/sellers/me/orders
Authorization: Bearer <seller_token>
```

---

### 👥 Employee Routes (`/api/employees`)

All employee routes require admin authentication.

#### Create Employee (Admin)
```http
POST /api/employees
Authorization: Bearer <admin_token>
Content-Type: application/json

{
  "name": "Employee Name",
  "email": "employee@example.com",
  "phone": "+91 9876543210",
  "designation": "Software Developer",
  "department": "IT",
  "joiningDate": "2024-01-01",
  "salary": 50000,
  "status": "ACTIVE",
  "address": "Employee Address",
  "emergencyName": "Emergency Contact",
  "emergencyPhone": "+91 9876543211",
  "emergencyRelation": "Spouse"
}
```

#### Get All Employees (Admin)
```http
GET /api/employees?status=ACTIVE&department=IT&page=1&limit=50
Authorization: Bearer <admin_token>
```

#### Get Employee by ID (Admin)
```http
GET /api/employees/:id
Authorization: Bearer <admin_token>
```

#### Update Employee (Admin)
```http
PUT /api/employees/:id
Authorization: Bearer <admin_token>
Content-Type: application/json

{
  "salary": 55000,
  "designation": "Senior Developer"
}
```

#### Delete Employee (Admin)
```http
DELETE /api/employees/:id
Authorization: Bearer <admin_token>
```

#### Get Employee Payroll (Admin)
```http
GET /api/employees/:id/payroll?month=1&year=2024
Authorization: Bearer <admin_token>
```

---

### 📅 Attendance Routes (`/api/attendance`)

All attendance routes require admin authentication.

#### Mark Attendance (Admin)
```http
POST /api/attendance
Authorization: Bearer <admin_token>
Content-Type: application/json

{
  "employeeId": "employee_uuid",
  "date": "2024-01-15",
  "status": "PRESENT",
  "checkIn": "09:00",
  "checkOut": "18:00",
  "remarks": "On time"
}
```

**Valid Statuses:** PRESENT, ABSENT, HALF_DAY, LEAVE

#### Get Employee Attendance (Admin)
```http
GET /api/attendance/employee/:employeeId?month=1&year=2024
Authorization: Bearer <admin_token>
```

#### Get Attendance Report (Admin)
```http
GET /api/attendance/report?month=1&year=2024&department=IT
Authorization: Bearer <admin_token>
```

This returns payroll calculation for all employees.

#### Update Attendance (Admin)
```http
PUT /api/attendance/:id
Authorization: Bearer <admin_token>
Content-Type: application/json

{
  "status": "HALF_DAY",
  "remarks": "Left early"
}
```

#### Delete Attendance (Admin)
```http
DELETE /api/attendance/:id
Authorization: Bearer <admin_token>
```

---

## 🗄 Database Schema

### Tables

1. **users** - User accounts (Customer, Seller, Admin)
2. **products** - Product catalog
3. **sellers** - Seller business information
4. **orders** - Customer orders
5. **order_items** - Items in each order
6. **cart_items** - Shopping cart (persistent)
7. **employees** - Employee records
8. **attendance** - Daily attendance tracking

### Relationships

- User → Seller (One-to-One)
- User → Orders (One-to-Many)
- User → CartItems (One-to-Many)
- Seller → Products (One-to-Many)
- Order → OrderItems (One-to-Many)
- Product → OrderItems (One-to-Many)
- Product → CartItems (One-to-Many)
- Employee → Attendance (One-to-Many)

---

## 🔒 Security Features

- ✅ Password hashing with bcrypt (10 rounds)
- ✅ JWT token authentication
- ✅ Role-based access control
- ✅ CORS protection
- ✅ Input validation
- ✅ SQL injection prevention (Prisma ORM)
- ✅ Error handling middleware

---

## 📊 Payroll Calculation

The system automatically calculates employee salaries based on attendance:

```
Daily Rate = Monthly Salary ÷ Days in Month
Working Days = Present Days + (Half-Day × 0.5)
Payable Salary = Daily Rate × Working Days
```

**Example:**
```
Employee: John Doe
Base Salary: ₹50,000
Month: January (31 days)

Attendance:
- Present: 22 days
- Half-Day: 2 days (= 1 working day)
- Absent: 7 days

Calculation:
Daily Rate: ₹50,000 ÷ 31 = ₹1,612.90
Working Days: 22 + 1 = 23
Payable Salary: ₹1,612.90 × 23 = ₹37,096.77
```

---

## 🧪 Testing the API

### Using cURL

```bash
# Register
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Test User","email":"test@test.com","password":"test123"}'

# Login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@shophub.com","password":"admin123"}'

# Get Products
curl http://localhost:5000/api/products
```

### Using Postman

1. Import the endpoints from this documentation
2. Set base URL: `http://localhost:5000/api`
3. For protected routes, add header:
   - Key: `Authorization`
   - Value: `Bearer <your_jwt_token>`

---

## 📁 Project Structure

```
backend/
├── prisma/
│   └── schema.prisma          # Database schema
├── src/
│   ├── controllers/           # Request handlers
│   │   ├── auth.controller.ts
│   │   ├── product.controller.ts
│   │   ├── order.controller.ts
│   │   ├── seller.controller.ts
│   │   ├── employee.controller.ts
│   │   ├── cart.controller.ts
│   │   └── attendance.controller.ts
│   ├── routes/                # API routes
│   │   ├── auth.routes.ts
│   │   ├── product.routes.ts
│   │   ├── order.routes.ts
│   │   ├── seller.routes.ts
│   │   ├── employee.routes.ts
│   │   ├── cart.routes.ts
│   │   └── attendance.routes.ts
│   ├── middleware/            # Middleware functions
│   │   ├── auth.ts            # Authentication
│   │   └── errorHandler.ts   # Error handling
│   ├── utils/                 # Utility functions
│   │   └── seed.ts           # Database seeding
│   └── server.ts             # Server entry point
├── .env.example              # Environment template
├── package.json
├── tsconfig.json
└── README.md                 # This file
```

---

## 🐛 Troubleshooting

### Database Connection Issues

```bash
# Check if PostgreSQL is running
sudo service postgresql status

# Restart PostgreSQL
sudo service postgresql restart

# Verify DATABASE_URL in .env matches your PostgreSQL credentials
```

### Port Already in Use

```bash
# Find process using port 5000
lsof -i :5000

# Kill the process
kill -9 <PID>

# Or change PORT in .env
PORT=5001
```

### Prisma Issues

```bash
# Reset database (WARNING: Deletes all data)
npx prisma migrate reset

# Regenerate Prisma Client
npx prisma generate

# View database in browser
npx prisma studio
```

---

## 🚀 Deployment

### Production Checklist

- [ ] Change `JWT_SECRET` to a strong random string
- [ ] Set `NODE_ENV=production`
- [ ] Use environment-specific DATABASE_URL
- [ ] Enable SSL for PostgreSQL
- [ ] Set up proper CORS origins
- [ ] Enable rate limiting
- [ ] Set up logging (Winston, Morgan)
- [ ] Configure reverse proxy (Nginx)
- [ ] Enable HTTPS
- [ ] Set up monitoring (PM2, New Relic)

### Deploy to Heroku

```bash
# Install Heroku CLI
# Login to Heroku
heroku login

# Create app
heroku create shophub-api

# Add PostgreSQL
heroku addons:create heroku-postgresql:mini

# Set environment variables
heroku config:set JWT_SECRET=your-secret
heroku config:set NODE_ENV=production

# Deploy
git push heroku main

# Run migrations
heroku run npm run prisma:migrate
```

---

## 📚 Additional Resources

- [Express.js Documentation](https://expressjs.com/)
- [Prisma Documentation](https://www.prisma.io/docs/)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)
- [JWT Best Practices](https://jwt.io/introduction)

---

## 📄 License

MIT License - see LICENSE file for details

---

## 👨‍💻 Support

For issues or questions:
- Check the troubleshooting section
- Review API documentation
- Check Prisma logs: `npx prisma studio`

---

**🎉 Your ShopHub Backend API is ready!**
