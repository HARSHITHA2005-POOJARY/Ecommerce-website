# Database Migration Guide

This guide will help you update your database schema to fix the employee attendance system.

## Changes Made

### 1. Prisma Schema Changes
- Changed `scheduleWorkingDays` from `String?` (JSON string) to `Int[]` (array of integers)
- This allows PostgreSQL to properly store and query working days as an array

### 2. Data Transformation
- Updated the frontend-backend transformation to handle arrays directly instead of JSON strings
- Fixed attendance fetching to properly load data on employee login
- Fixed attendance marking to update existing records instead of failing

## Migration Steps

### Step 1: Update Prisma Schema
The schema has already been updated in `/backend/prisma/schema.prisma`. The change is:

```prisma
// Old
scheduleWorkingDays  String?  // JSON string of working days array

// New
scheduleWorkingDays  Int[]   @default([])  // Array of day numbers (0-6, 0=Sunday)
```

### Step 2: Generate Migration
Run the following command in the `/backend` directory:

```bash
npx prisma migrate dev --name fix-schedule-working-days-array
```

This will:
- Create a new migration file
- Update your database schema
- Convert existing data (if any)

### Step 3: Update Database
If you already have employee data with schedules, you may need to manually update the data format.

**Before migration (if you have existing data):**

If you have employees with `scheduleWorkingDays` stored as JSON strings like `"[1,2,3,4,5]"`, the migration will handle the conversion automatically.

### Step 4: Regenerate Prisma Client
After the migration, regenerate the Prisma client:

```bash
npx prisma generate
```

### Step 5: Restart Backend Server
Restart your backend server to use the new schema:

```bash
npm run dev
```

## What This Fixes

1. **Database Schema**: Working days are now stored as a proper PostgreSQL integer array
2. **Data Transformation**: Automatic conversion between frontend and backend formats
3. **Attendance Loading**: Attendance data is now properly loaded when employee logs in
4. **Attendance Updates**: Check-in/check-out now updates existing records instead of creating duplicates
5. **Employee Schedule Access**: The `getEmployee` function now properly checks both current employee and employees list

## Testing

After migration, test the following:

1. **Add New Employee** with schedule
   - Login as admin
   - Go to Employee Management
   - Add a new employee with schedule (check-in time, check-out time, working days)

2. **Employee Login**
   - Login as an employee
   - Verify the schedule displays correctly

3. **Mark Attendance**
   - Check in (present)
   - Check out
   - Verify attendance is recorded

4. **View Attendance History**
   - Go to Attendance History tab
   - Select different months
   - Verify attendance records are displayed

5. **Calculate Salary**
   - Verify monthly salary calculation based on attendance

## Rollback (if needed)

If you need to rollback the migration:

```bash
npx prisma migrate resolve --rolled-back <migration-name>
```

Then restore the previous schema version and run:

```bash
npx prisma migrate dev
```

## Support

If you encounter any issues during migration:

1. Check the console for error messages
2. Verify your PostgreSQL connection
3. Ensure all dependencies are installed
4. Check that the backend server has proper database permissions
