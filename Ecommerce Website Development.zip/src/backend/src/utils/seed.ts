import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Starting database seed...');

  // Create Admin User
  const adminPassword = await bcrypt.hash('admin123', 10);
  const admin = await prisma.user.upsert({
    where: { email: 'admin@shophub.com' },
    update: {},
    create: {
      email: 'admin@shophub.com',
      password: adminPassword,
      name: 'Admin User',
      role: 'ADMIN'
    }
  });
  console.log('✅ Admin user created');

  // Create Test Seller User
  const sellerPassword = await bcrypt.hash('seller123', 10);
  const sellerUser = await prisma.user.upsert({
    where: { email: 'test@seller.com' },
    update: {},
    create: {
      email: 'test@seller.com',
      password: sellerPassword,
      name: 'Test Seller',
      role: 'SELLER',
      seller: {
        create: {
          businessName: 'Test Shop',
          phone: '+91 9876543210',
          gst: '22AAAAA0000A1Z5',
          commission: 15.0,
          address: '123 Business Street, Mumbai, Maharashtra 400001',
          approved: true
        }
      }
    }
  });
  console.log('✅ Test seller created');

  // Create Sample Products
  const products = [
    {
      name: 'Sony WH-1000XM5 Wireless Headphones',
      description: 'Industry-leading noise canceling with Dual Noise Sensor technology',
      price: 29999,
      originalPrice: 34999,
      discount: 14,
      category: 'Electronics',
      brand: 'Sony',
      image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800',
      stock: 50,
      rating: 4.8,
      tags: ['headphones', 'wireless', 'noise-canceling']
    },
    {
      name: 'Apple iPhone 15 Pro',
      description: 'Titanium design, A17 Pro chip, and ProMotion display',
      price: 134900,
      originalPrice: 139900,
      discount: 4,
      category: 'Electronics',
      brand: 'Apple',
      image: 'https://images.unsplash.com/photo-1678685888221-cda15ad7364c?w=800',
      stock: 30,
      rating: 4.9,
      tags: ['smartphone', 'iphone', 'premium']
    },
    {
      name: 'Nike Air Max 270',
      description: 'Men\'s running shoes with Max Air cushioning',
      price: 12995,
      originalPrice: 14995,
      discount: 13,
      category: 'Fashion',
      brand: 'Nike',
      image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800',
      stock: 100,
      rating: 4.6,
      tags: ['shoes', 'running', 'sports']
    },
    {
      name: 'Levi\'s 501 Original Jeans',
      description: 'Classic straight fit jeans, original since 1873',
      price: 3999,
      originalPrice: 4999,
      discount: 20,
      category: 'Fashion',
      brand: 'Levi\'s',
      image: 'https://images.unsplash.com/photo-1542272454315-7bb2e-9f3b?w=800',
      stock: 150,
      rating: 4.5,
      tags: ['jeans', 'denim', 'casual']
    },
    {
      name: 'Instant Pot Duo 7-in-1',
      description: 'Multi-functional pressure cooker for the modern kitchen',
      price: 8499,
      originalPrice: 9999,
      discount: 15,
      category: 'Home',
      brand: 'Instant Pot',
      image: 'https://images.unsplash.com/photo-1585515320310-259814833e62?w=800',
      stock: 75,
      rating: 4.7,
      tags: ['kitchen', 'cooking', 'appliance']
    },
    {
      name: 'Wilson Tennis Racket Pro Staff',
      description: 'Professional-grade tennis racket for serious players',
      price: 15999,
      originalPrice: 18999,
      discount: 16,
      category: 'Sports',
      brand: 'Wilson',
      image: 'https://images.unsplash.com/photo-1622163642998-1ea32b0bbc67?w=800',
      stock: 40,
      rating: 4.6,
      tags: ['tennis', 'racket', 'sports-equipment']
    },
    {
      name: 'Maybelline Fit Me Foundation',
      description: 'Natural coverage foundation for all skin types',
      price: 599,
      originalPrice: 699,
      discount: 14,
      category: 'Beauty',
      brand: 'Maybelline',
      image: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=800',
      stock: 200,
      rating: 4.4,
      tags: ['makeup', 'foundation', 'cosmetics']
    },
    {
      name: 'Atomic Habits by James Clear',
      description: 'An easy & proven way to build good habits & break bad ones',
      price: 599,
      originalPrice: 699,
      discount: 14,
      category: 'Books',
      brand: 'Penguin Random House',
      image: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=800',
      stock: 120,
      rating: 4.9,
      tags: ['self-help', 'bestseller', 'productivity']
    }
  ];

  for (const product of products) {
    await prisma.product.create({
      data: product
    });
  }
  console.log('✅ Sample products created');

  console.log('🎉 Database seeding completed!');
}

main()
  .catch((e) => {
    console.error('❌ Error seeding database:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
