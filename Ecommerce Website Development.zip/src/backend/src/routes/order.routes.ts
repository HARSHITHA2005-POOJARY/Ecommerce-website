import { Router } from 'express';
import { OrderController } from '../controllers/order.controller';
import { authenticate, authorize } from '../middleware/auth';

const router = Router();
const orderController = new OrderController();

// Protected routes (require authentication)
router.post('/', authenticate, orderController.createOrder);
router.get('/', authenticate, orderController.getUserOrders);
router.get('/:id', authenticate, orderController.getOrderById);

// Admin routes
router.get('/all/admin', authenticate, authorize('ADMIN'), orderController.getAllOrders);
router.put('/:id/status', authenticate, authorize('ADMIN'), orderController.updateOrderStatus);

export default router;
