import { Router } from 'express';
import { EmployeeAuthController } from '../controllers/employeeAuth.controller';
import { authenticate } from '../middleware/auth';

const router = Router();
const employeeAuthController = new EmployeeAuthController();

// Public routes
router.post('/login', employeeAuthController.login);

// Protected routes (employee must be logged in)
router.get('/me', authenticate, employeeAuthController.getProfile);
router.post('/change-password', authenticate, employeeAuthController.changePassword);

export default router;
