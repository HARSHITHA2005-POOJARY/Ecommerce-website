import { Router } from 'express';
import { ProductController } from '../controllers/product.controller';
import { authenticate, authorize } from '../middleware/auth';

const router = Router();
const productController = new ProductController();

// Public routes
router.get('/', productController.getAllProducts);
router.get('/categories', productController.getCategories);
router.get('/:id', productController.getProductById);

// Protected routes (Admin & Seller)
router.post('/', authenticate, authorize('ADMIN', 'SELLER'), productController.createProduct);
router.put('/:id', authenticate, authorize('ADMIN', 'SELLER'), productController.updateProduct);
router.delete('/:id', authenticate, authorize('ADMIN', 'SELLER'), productController.deleteProduct);

export default router;
