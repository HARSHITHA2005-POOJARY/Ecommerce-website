import { Router } from 'express';
import { EmployeeController } from '../controllers/employee.controller';
import { authenticate, authorize } from '../middleware/auth';

const router = Router();
const employeeController = new EmployeeController();

// All routes require admin authentication
router.use(authenticate, authorize('ADMIN'));

router.get('/', employeeController.getAllEmployees);
router.get('/:id', employeeController.getEmployeeById);
router.post('/', employeeController.createEmployee);
router.put('/:id', employeeController.updateEmployee);
router.delete('/:id', employeeController.deleteEmployee);
router.get('/:id/payroll', employeeController.getEmployeePayroll);

export default router;
