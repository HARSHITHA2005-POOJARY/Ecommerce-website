import { Router } from 'express';
import { SellerController } from '../controllers/seller.controller';
import { authenticate, authorize } from '../middleware/auth';

const router = Router();
const sellerController = new SellerController();

// Public routes
router.post('/register', sellerController.registerSeller);

// Admin routes
router.get('/', authenticate, authorize('ADMIN'), sellerController.getAllSellers);
router.put('/:id/approve', authenticate, authorize('ADMIN'), sellerController.approveSeller);
router.put('/:id/commission', authenticate, authorize('ADMIN'), sellerController.updateCommission);
router.delete('/:id', authenticate, authorize('ADMIN'), sellerController.deleteSeller);

// Seller routes
router.get('/me', authenticate, authorize('SELLER'), sellerController.getSellerProfile);
router.get('/me/analytics', authenticate, authorize('SELLER'), sellerController.getSellerAnalytics);
router.get('/me/products', authenticate, authorize('SELLER'), sellerController.getSellerProducts);
router.get('/me/orders', authenticate, authorize('SELLER'), sellerController.getSellerOrders);

export default router;
