import { Router } from 'express';
import { AttendanceController } from '../controllers/attendance.controller';
import { authenticate, authorize } from '../middleware/auth';

const router = Router();
const attendanceController = new AttendanceController();

// All routes require admin authentication
router.use(authenticate, authorize('ADMIN'));

router.post('/', attendanceController.markAttendance);
router.get('/employee/:employeeId', attendanceController.getEmployeeAttendance);
router.get('/report', attendanceController.getAttendanceReport);
router.put('/:id', attendanceController.updateAttendance);
router.delete('/:id', attendanceController.deleteAttendance);

export default router;
