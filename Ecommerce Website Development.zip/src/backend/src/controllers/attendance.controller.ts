import { Request, Response, NextFunction } from 'express';
import { PrismaClient } from '@prisma/client';
import { ValidationError, NotFoundError } from '../middleware/errorHandler';

const prisma = new PrismaClient();

export class AttendanceController {
  // Mark attendance
  async markAttendance(req: Request, res: Response, next: NextFunction) {
    try {
      const { employeeId, date, status, checkIn, checkOut, remarks } = req.body;

      if (!employeeId || !date || !status) {
        throw new ValidationError('Employee ID, date, and status are required');
      }

      // Validate status
      const validStatuses = ['PRESENT', 'ABSENT', 'HALF_DAY', 'LEAVE'];
      if (!validStatuses.includes(status)) {
        throw new ValidationError('Invalid attendance status');
      }

      // Check if employee exists
      const employee = await prisma.employee.findUnique({
        where: { id: employeeId }
      });

      if (!employee) {
        throw new NotFoundError('Employee not found');
      }

      const attendanceDate = new Date(date);
      attendanceDate.setHours(0, 0, 0, 0);

      // Check if attendance already marked for this date
      const existingAttendance = await prisma.attendance.findUnique({
        where: {
          employeeId_date: {
            employeeId,
            date: attendanceDate
          }
        }
      });

      let attendance;
      
      if (existingAttendance) {
        // Update existing attendance (for check-out or status change)
        attendance = await prisma.attendance.update({
          where: { id: existingAttendance.id },
          data: {
            status,
            checkIn: checkIn || existingAttendance.checkIn,
            checkOut: checkOut || existingAttendance.checkOut,
            remarks: remarks || existingAttendance.remarks
          },
          include: {
            employee: {
              select: {
                name: true,
                designation: true,
                department: true
              }
            }
          }
        });
      } else {
        // Create new attendance record
        attendance = await prisma.attendance.create({
          data: {
            employeeId,
            date: attendanceDate,
            status,
            checkIn,
            checkOut,
            remarks
          },
          include: {
            employee: {
              select: {
                name: true,
                designation: true,
                department: true
              }
            }
          }
        });
      }

      res.status(existingAttendance ? 200 : 201).json({
        success: true,
        message: existingAttendance ? 'Attendance updated successfully' : 'Attendance marked successfully',
        data: attendance
      });
    } catch (error) {
      next(error);
    }
  }

  // Get employee attendance
  async getEmployeeAttendance(req: Request, res: Response, next: NextFunction) {
    try {
      const { employeeId } = req.params;
      const { startDate, endDate, month, year } = req.query;

      let dateFilter: any = {};

      if (startDate && endDate) {
        dateFilter = {
          gte: new Date(startDate as string),
          lte: new Date(endDate as string)
        };
      } else if (month && year) {
        const start = new Date(parseInt(year as string), parseInt(month as string) - 1, 1);
        const end = new Date(parseInt(year as string), parseInt(month as string), 0);
        dateFilter = {
          gte: start,
          lte: end
        };
      }

      const attendance = await prisma.attendance.findMany({
        where: {
          employeeId,
          ...(Object.keys(dateFilter).length > 0 && { date: dateFilter })
        },
        orderBy: { date: 'desc' },
        include: {
          employee: {
            select: {
              name: true,
              designation: true,
              department: true
            }
          }
        }
      });

      // Calculate statistics
      const stats = {
        total: attendance.length,
        present: attendance.filter(a => a.status === 'PRESENT').length,
        absent: attendance.filter(a => a.status === 'ABSENT').length,
        halfDay: attendance.filter(a => a.status === 'HALF_DAY').length,
        leave: attendance.filter(a => a.status === 'LEAVE').length
      };

      res.json({
        success: true,
        data: {
          attendance,
          statistics: stats
        }
      });
    } catch (error) {
      next(error);
    }
  }

  // Get attendance report
  async getAttendanceReport(req: Request, res: Response, next: NextFunction) {
    try {
      const { month, year, department } = req.query;

      if (!month || !year) {
        throw new ValidationError('Month and year are required');
      }

      const startDate = new Date(parseInt(year as string), parseInt(month as string) - 1, 1);
      const endDate = new Date(parseInt(year as string), parseInt(month as string), 0);

      // Get all employees
      const employeeWhere: any = {};
      if (department) {
        employeeWhere.department = department;
      }

      const employees = await prisma.employee.findMany({
        where: employeeWhere,
        include: {
          attendance: {
            where: {
              date: {
                gte: startDate,
                lte: endDate
              }
            }
          }
        }
      });

      // Calculate payroll for each employee
      const report = employees.map(employee => {
        const attendance = employee.attendance;
        
        let presentDays = 0;
        let absentDays = 0;
        let halfDays = 0;
        let leaveDays = 0;

        attendance.forEach(record => {
          switch (record.status) {
            case 'PRESENT':
              presentDays++;
              break;
            case 'ABSENT':
              absentDays++;
              break;
            case 'HALF_DAY':
              halfDays++;
              break;
            case 'LEAVE':
              leaveDays++;
              break;
          }
        });

        const daysInMonth = endDate.getDate();
        const dailyRate = employee.salary / daysInMonth;
        const workingDays = presentDays + (halfDays * 0.5);
        const payableSalary = dailyRate * workingDays;

        return {
          employee: {
            id: employee.id,
            name: employee.name,
            designation: employee.designation,
            department: employee.department,
            baseSalary: employee.salary
          },
          attendance: {
            present: presentDays,
            absent: absentDays,
            halfDay: halfDays,
            leave: leaveDays,
            total: attendance.length
          },
          payroll: {
            dailyRate: Math.round(dailyRate * 100) / 100,
            workingDays,
            payableSalary: Math.round(payableSalary * 100) / 100
          }
        };
      });

      res.json({
        success: true,
        data: {
          month: parseInt(month as string),
          year: parseInt(year as string),
          daysInMonth: endDate.getDate(),
          report
        }
      });
    } catch (error) {
      next(error);
    }
  }

  // Update attendance
  async updateAttendance(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const { status, checkIn, checkOut, remarks } = req.body;

      const attendance = await prisma.attendance.update({
        where: { id },
        data: {
          status,
          checkIn,
          checkOut,
          remarks
        },
        include: {
          employee: {
            select: {
              name: true
            }
          }
        }
      });

      res.json({
        success: true,
        message: 'Attendance updated successfully',
        data: attendance
      });
    } catch (error) {
      next(error);
    }
  }

  // Delete attendance
  async deleteAttendance(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;

      await prisma.attendance.delete({
        where: { id }
      });

      res.json({
        success: true,
        message: 'Attendance deleted successfully'
      });
    } catch (error) {
      next(error);
    }
  }
}