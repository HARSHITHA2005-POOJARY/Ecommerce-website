import { Request, Response, NextFunction } from 'express';
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { ValidationError, UnauthorizedError } from '../middleware/errorHandler';

const prisma = new PrismaClient();

export class EmployeeAuthController {
  // Employee Login
  async login(req: Request, res: Response, next: NextFunction) {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        throw new ValidationError('Email and password are required');
      }

      // Find employee by email
      const employee = await prisma.employee.findUnique({
        where: { email }
      });

      if (!employee) {
        throw new UnauthorizedError('Invalid email or password');
      }

      // Check if employee is approved
      if (!employee.approved) {
        throw new UnauthorizedError('Your account is pending approval. Please contact admin.');
      }

      // Check if employee is active
      if (employee.status !== 'ACTIVE') {
        throw new UnauthorizedError('Your account is inactive. Please contact admin.');
      }

      // Verify password
      const isValidPassword = await bcrypt.compare(password, employee.password);
      if (!isValidPassword) {
        throw new UnauthorizedError('Invalid email or password');
      }

      // Generate JWT token
      const token = jwt.sign(
        { 
          id: employee.id, 
          email: employee.email,
          role: 'EMPLOYEE',
          name: employee.name
        },
        process.env.JWT_SECRET || 'your-secret-key',
        { expiresIn: '7d' }
      );

      // Parse schedule from JSON strings
      const schedule = employee.scheduleWorkingDays ? {
        checkInTime: employee.scheduleCheckInTime || '09:00',
        checkOutTime: employee.scheduleCheckOutTime || '18:00',
        workingDays: JSON.parse(employee.scheduleWorkingDays)
      } : undefined;

      // Remove password from response
      const { password: _, ...employeeData } = employee;

      res.json({
        success: true,
        message: 'Login successful',
        data: {
          employee: {
            ...employeeData,
            schedule
          },
          token
        }
      });
    } catch (error) {
      next(error);
    }
  }

  // Get current employee profile
  async getProfile(req: Request, res: Response, next: NextFunction) {
    try {
      const employeeId = (req as any).user.id;

      const employee = await prisma.employee.findUnique({
        where: { id: employeeId },
        include: {
          attendance: {
            orderBy: { date: 'desc' },
            take: 30
          }
        }
      });

      if (!employee) {
        throw new UnauthorizedError('Employee not found');
      }

      // Parse schedule from JSON strings
      const schedule = employee.scheduleWorkingDays ? {
        checkInTime: employee.scheduleCheckInTime || '09:00',
        checkOutTime: employee.scheduleCheckOutTime || '18:00',
        workingDays: JSON.parse(employee.scheduleWorkingDays)
      } : undefined;

      // Remove password from response
      const { password: _, ...employeeData } = employee;

      res.json({
        success: true,
        data: {
          ...employeeData,
          schedule
        }
      });
    } catch (error) {
      next(error);
    }
  }

  // Change password
  async changePassword(req: Request, res: Response, next: NextFunction) {
    try {
      const employeeId = (req as any).user.id;
      const { currentPassword, newPassword } = req.body;

      if (!currentPassword || !newPassword) {
        throw new ValidationError('Current password and new password are required');
      }

      if (newPassword.length < 6) {
        throw new ValidationError('Password must be at least 6 characters');
      }

      const employee = await prisma.employee.findUnique({
        where: { id: employeeId }
      });

      if (!employee) {
        throw new UnauthorizedError('Employee not found');
      }

      // Verify current password
      const isValidPassword = await bcrypt.compare(currentPassword, employee.password);
      if (!isValidPassword) {
        throw new UnauthorizedError('Current password is incorrect');
      }

      // Hash new password
      const hashedPassword = await bcrypt.hash(newPassword, 10);

      // Update password
      await prisma.employee.update({
        where: { id: employeeId },
        data: { password: hashedPassword }
      });

      res.json({
        success: true,
        message: 'Password changed successfully'
      });
    } catch (error) {
      next(error);
    }
  }
}
