import { Request, Response, NextFunction } from 'express';
import { PrismaClient } from '@prisma/client';
import { AuthRequest } from '../middleware/auth';
import { ValidationError, NotFoundError } from '../middleware/errorHandler';

const prisma = new PrismaClient();

export class OrderController {
  // Create new order
  async createOrder(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const {
        items,
        subtotal,
        shipping,
        tax,
        total,
        shippingAddress,
        paymentMethod
      } = req.body;

      if (!items || items.length === 0) {
        throw new ValidationError('Order must contain at least one item');
      }

      if (!shippingAddress) {
        throw new ValidationError('Shipping address is required');
      }

      // Generate order number
      const orderNumber = `ORD-${new Date().getFullYear()}${String(new Date().getMonth() + 1).padStart(2, '0')}${String(new Date().getDate()).padStart(2, '0')}-${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`;

      // Create order with items
      const order = await prisma.order.create({
        data: {
          orderNumber,
          userId: req.user!.id,
          subtotal: parseFloat(subtotal),
          shipping: parseFloat(shipping),
          tax: parseFloat(tax),
          total: parseFloat(total),
          shippingName: shippingAddress.fullName,
          shippingEmail: shippingAddress.email,
          shippingPhone: shippingAddress.phone,
          shippingAddress: shippingAddress.address,
          shippingCity: shippingAddress.city,
          shippingState: shippingAddress.state,
          shippingZip: shippingAddress.zipCode,
          paymentMethod,
          items: {
            create: items.map((item: any) => ({
              productId: item.productId,
              quantity: parseInt(item.quantity),
              price: parseFloat(item.price)
            }))
          }
        },
        include: {
          items: {
            include: {
              product: true
            }
          }
        }
      });

      // Update seller sales if products belong to sellers
      for (const item of items) {
        const product = await prisma.product.findUnique({
          where: { id: item.productId },
          include: { seller: true }
        });

        if (product && product.seller) {
          const itemTotal = parseFloat(item.price) * parseInt(item.quantity);
          const commission = (itemTotal * product.seller.commission) / 100;

          await prisma.seller.update({
            where: { id: product.seller.id },
            data: {
              totalSales: { increment: itemTotal },
              totalCommission: { increment: commission }
            }
          });
        }

        // Decrease stock
        await prisma.product.update({
          where: { id: item.productId },
          data: {
            stock: { decrement: parseInt(item.quantity) }
          }
        });
      }

      // Clear user's cart
      await prisma.cartItem.deleteMany({
        where: { userId: req.user!.id }
      });

      res.status(201).json({
        success: true,
        message: 'Order placed successfully',
        data: order
      });
    } catch (error) {
      next(error);
    }
  }

  // Get user's orders
  async getUserOrders(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const orders = await prisma.order.findMany({
        where: { userId: req.user!.id },
        include: {
          items: {
            include: {
              product: true
            }
          }
        },
        orderBy: { createdAt: 'desc' }
      });

      res.json({
        success: true,
        data: orders
      });
    } catch (error) {
      next(error);
    }
  }

  // Get order by ID
  async getOrderById(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;

      const order = await prisma.order.findUnique({
        where: { id },
        include: {
          items: {
            include: {
              product: {
                include: {
                  seller: {
                    select: {
                      businessName: true
                    }
                  }
                }
              }
            }
          },
          user: {
            select: {
              name: true,
              email: true
            }
          }
        }
      });

      if (!order) {
        throw new NotFoundError('Order not found');
      }

      // Check if user owns this order or is admin
      if (order.userId !== req.user!.id && req.user!.role !== 'ADMIN') {
        throw new ValidationError('You do not have permission to view this order');
      }

      res.json({
        success: true,
        data: order
      });
    } catch (error) {
      next(error);
    }
  }

  // Get all orders (Admin only)
  async getAllOrders(req: Request, res: Response, next: NextFunction) {
    try {
      const { status, page = '1', limit = '50' } = req.query;

      const where: any = {};
      if (status) {
        where.status = status;
      }

      const pageNum = parseInt(page as string);
      const limitNum = parseInt(limit as string);
      const skip = (pageNum - 1) * limitNum;

      const [orders, total] = await Promise.all([
        prisma.order.findMany({
          where,
          include: {
            items: {
              include: {
                product: true
              }
            },
            user: {
              select: {
                name: true,
                email: true
              }
            }
          },
          orderBy: { createdAt: 'desc' },
          skip,
          take: limitNum
        }),
        prisma.order.count({ where })
      ]);

      res.json({
        success: true,
        data: orders,
        pagination: {
          page: pageNum,
          limit: limitNum,
          total,
          pages: Math.ceil(total / limitNum)
        }
      });
    } catch (error) {
      next(error);
    }
  }

  // Update order status (Admin only)
  async updateOrderStatus(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const { status } = req.body;

      if (!status) {
        throw new ValidationError('Status is required');
      }

      const validStatuses = ['PENDING', 'CONFIRMED', 'SHIPPED', 'DELIVERED', 'CANCELLED'];
      if (!validStatuses.includes(status)) {
        throw new ValidationError('Invalid status');
      }

      const order = await prisma.order.update({
        where: { id },
        data: { status },
        include: {
          items: {
            include: {
              product: true
            }
          }
        }
      });

      res.json({
        success: true,
        message: 'Order status updated successfully',
        data: order
      });
    } catch (error) {
      next(error);
    }
  }
}
