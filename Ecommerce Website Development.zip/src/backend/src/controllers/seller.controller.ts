import { Request, Response, NextFunction } from 'express';
import bcrypt from 'bcryptjs';
import { PrismaClient } from '@prisma/client';
import { AuthRequest } from '../middleware/auth';
import { ValidationError, NotFoundError } from '../middleware/errorHandler';

const prisma = new PrismaClient();

export class SellerController {
  // Register as seller
  async registerSeller(req: Request, res: Response, next: NextFunction) {
    try {
      const {
        name,
        email,
        password,
        businessName,
        phone,
        gst,
        address
      } = req.body;

      // Validate required fields
      if (!name || !email || !password || !businessName || !phone || !address) {
        throw new ValidationError('All required fields must be provided');
      }

      // Check if email exists
      const existingUser = await prisma.user.findUnique({
        where: { email }
      });

      if (existingUser) {
        throw new ValidationError('Email already registered');
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);

      // Create user and seller
      const user = await prisma.user.create({
        data: {
          name,
          email,
          password: hashedPassword,
          role: 'SELLER',
          seller: {
            create: {
              businessName,
              phone,
              gst,
              address,
              commission: 15.0, // Default commission
              approved: false // Needs admin approval
            }
          }
        },
        include: {
          seller: true
        }
      });

      res.status(201).json({
        success: true,
        message: 'Seller registration submitted. Please wait for admin approval.',
        data: {
          user: {
            id: user.id,
            name: user.name,
            email: user.email,
            role: user.role
          },
          seller: user.seller
        }
      });
    } catch (error) {
      next(error);
    }
  }

  // Get all sellers (Admin)
  async getAllSellers(req: Request, res: Response, next: NextFunction) {
    try {
      const { approved, page = '1', limit = '50' } = req.query;

      const where: any = {};
      if (approved !== undefined) {
        where.approved = approved === 'true';
      }

      const pageNum = parseInt(page as string);
      const limitNum = parseInt(limit as string);
      const skip = (pageNum - 1) * limitNum;

      const [sellers, total] = await Promise.all([
        prisma.seller.findMany({
          where,
          include: {
            user: {
              select: {
                id: true,
                name: true,
                email: true,
                createdAt: true
              }
            },
            _count: {
              select: {
                products: true
              }
            }
          },
          orderBy: { createdAt: 'desc' },
          skip,
          take: limitNum
        }),
        prisma.seller.count({ where })
      ]);

      res.json({
        success: true,
        data: sellers,
        pagination: {
          page: pageNum,
          limit: limitNum,
          total,
          pages: Math.ceil(total / limitNum)
        }
      });
    } catch (error) {
      next(error);
    }
  }

  // Approve seller (Admin)
  async approveSeller(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const { approved } = req.body;

      const seller = await prisma.seller.update({
        where: { id },
        data: { approved },
        include: {
          user: {
            select: {
              name: true,
              email: true
            }
          }
        }
      });

      res.json({
        success: true,
        message: `Seller ${approved ? 'approved' : 'rejected'} successfully`,
        data: seller
      });
    } catch (error) {
      next(error);
    }
  }

  // Update commission (Admin)
  async updateCommission(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const { commission } = req.body;

      if (!commission || commission < 0 || commission > 100) {
        throw new ValidationError('Commission must be between 0 and 100');
      }

      const seller = await prisma.seller.update({
        where: { id },
        data: { commission: parseFloat(commission) }
      });

      res.json({
        success: true,
        message: 'Commission updated successfully',
        data: seller
      });
    } catch (error) {
      next(error);
    }
  }

  // Delete seller (Admin)
  async deleteSeller(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;

      await prisma.seller.delete({
        where: { id }
      });

      res.json({
        success: true,
        message: 'Seller deleted successfully'
      });
    } catch (error) {
      next(error);
    }
  }

  // Get seller profile
  async getSellerProfile(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const seller = await prisma.seller.findUnique({
        where: { userId: req.user!.id },
        include: {
          user: {
            select: {
              id: true,
              name: true,
              email: true
            }
          },
          _count: {
            select: {
              products: true
            }
          }
        }
      });

      if (!seller) {
        throw new NotFoundError('Seller profile not found');
      }

      res.json({
        success: true,
        data: seller
      });
    } catch (error) {
      next(error);
    }
  }

  // Get seller analytics
  async getSellerAnalytics(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const seller = await prisma.seller.findUnique({
        where: { userId: req.user!.id }
      });

      if (!seller) {
        throw new NotFoundError('Seller profile not found');
      }

      // Count products
      const productCount = await prisma.product.count({
        where: { sellerId: seller.id }
      });

      // Calculate earnings
      const earnings = seller.totalSales - seller.totalCommission;

      // Get recent orders
      const recentOrders = await prisma.order.findMany({
        where: {
          items: {
            some: {
              product: {
                sellerId: seller.id
              }
            }
          }
        },
        take: 5,
        orderBy: { createdAt: 'desc' },
        include: {
          items: {
            where: {
              product: {
                sellerId: seller.id
              }
            },
            include: {
              product: true
            }
          }
        }
      });

      res.json({
        success: true,
        data: {
          totalProducts: productCount,
          totalSales: seller.totalSales,
          totalCommission: seller.totalCommission,
          earnings,
          commission: seller.commission,
          recentOrders
        }
      });
    } catch (error) {
      next(error);
    }
  }

  // Get seller products
  async getSellerProducts(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const seller = await prisma.seller.findUnique({
        where: { userId: req.user!.id }
      });

      if (!seller) {
        throw new NotFoundError('Seller profile not found');
      }

      const products = await prisma.product.findMany({
        where: { sellerId: seller.id },
        orderBy: { createdAt: 'desc' }
      });

      res.json({
        success: true,
        data: products
      });
    } catch (error) {
      next(error);
    }
  }

  // Get seller orders
  async getSellerOrders(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const seller = await prisma.seller.findUnique({
        where: { userId: req.user!.id }
      });

      if (!seller) {
        throw new NotFoundError('Seller profile not found');
      }

      const orders = await prisma.order.findMany({
        where: {
          items: {
            some: {
              product: {
                sellerId: seller.id
              }
            }
          }
        },
        include: {
          items: {
            where: {
              product: {
                sellerId: seller.id
              }
            },
            include: {
              product: true
            }
          },
          user: {
            select: {
              name: true,
              email: true
            }
          }
        },
        orderBy: { createdAt: 'desc' }
      });

      res.json({
        success: true,
        data: orders
      });
    } catch (error) {
      next(error);
    }
  }
}
