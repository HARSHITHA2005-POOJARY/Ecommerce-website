import { Request, Response, NextFunction } from 'express';
import { PrismaClient } from '@prisma/client';
import { ValidationError, NotFoundError } from '../middleware/errorHandler';

const prisma = new PrismaClient();

export class EmployeeController {
  // Get all employees
  async getAllEmployees(req: Request, res: Response, next: NextFunction) {
    try {
      const { status, department, page = '1', limit = '50' } = req.query;

      const where: any = {};
      if (status) {
        where.status = status;
      }
      if (department) {
        where.department = department;
      }

      const pageNum = parseInt(page as string);
      const limitNum = parseInt(limit as string);
      const skip = (pageNum - 1) * limitNum;

      const [employees, total] = await Promise.all([
        prisma.employee.findMany({
          where,
          orderBy: { createdAt: 'desc' },
          skip,
          take: limitNum
        }),
        prisma.employee.count({ where })
      ]);

      // Remove passwords from all employees
      const employeesWithoutPasswords = employees.map(emp => {
        const { password: _, ...empData } = emp;
        return empData;
      });

      res.json({
        success: true,
        data: employeesWithoutPasswords,
        pagination: {
          page: pageNum,
          limit: limitNum,
          total,
          pages: Math.ceil(total / limitNum)
        }
      });
    } catch (error) {
      next(error);
    }
  }

  // Get employee by ID
  async getEmployeeById(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;

      const employee = await prisma.employee.findUnique({
        where: { id },
        include: {
          attendance: {
            orderBy: { date: 'desc' },
            take: 30
          }
        }
      });

      if (!employee) {
        throw new NotFoundError('Employee not found');
      }

      res.json({
        success: true,
        data: employee
      });
    } catch (error) {
      next(error);
    }
  }

  // Create employee
  async createEmployee(req: Request, res: Response, next: NextFunction) {
    try {
      const {
        name,
        email,
        password,
        phone,
        designation,
        department,
        joiningDate,
        salary,
        status = 'ACTIVE',
        approved = false,
        address,
        emergencyName,
        emergencyPhone,
        emergencyRelation,
        scheduleCheckInTime,
        scheduleCheckOutTime,
        scheduleWorkingDays
      } = req.body;

      // Validate required fields
      if (!name || !email || !password || !phone || !designation || !department || !joiningDate || !salary || !address) {
        throw new ValidationError('All required fields must be provided');
      }

      // Check if email exists
      const existingEmployee = await prisma.employee.findUnique({
        where: { email }
      });

      if (existingEmployee) {
        throw new ValidationError('Email already registered');
      }

      // Hash password
      const bcrypt = require('bcryptjs');
      const hashedPassword = await bcrypt.hash(password, 10);

      const employee = await prisma.employee.create({
        data: {
          name,
          email,
          password: hashedPassword,
          phone,
          designation,
          department,
          joiningDate: new Date(joiningDate),
          salary: parseFloat(salary),
          status: status.toUpperCase(),
          approved,
          address,
          emergencyName: emergencyName || '',
          emergencyPhone: emergencyPhone || '',
          emergencyRelation: emergencyRelation || '',
          scheduleCheckInTime,
          scheduleCheckOutTime,
          scheduleWorkingDays: scheduleWorkingDays ? JSON.stringify(scheduleWorkingDays) : null
        }
      });

      // Remove password from response
      const { password: _, ...employeeData } = employee;

      res.status(201).json({
        success: true,
        message: 'Employee created successfully',
        data: employeeData
      });
    } catch (error) {
      next(error);
    }
  }

  // Update employee
  async updateEmployee(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const updateData = req.body;

      // Convert joiningDate to Date if provided
      if (updateData.joiningDate) {
        updateData.joiningDate = new Date(updateData.joiningDate);
      }

      // Convert salary to number if provided
      if (updateData.salary) {
        updateData.salary = parseFloat(updateData.salary);
      }

      const employee = await prisma.employee.update({
        where: { id },
        data: updateData
      });

      res.json({
        success: true,
        message: 'Employee updated successfully',
        data: employee
      });
    } catch (error) {
      next(error);
    }
  }

  // Delete employee
  async deleteEmployee(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;

      await prisma.employee.delete({
        where: { id }
      });

      res.json({
        success: true,
        message: 'Employee deleted successfully'
      });
    } catch (error) {
      next(error);
    }
  }

  // Get employee payroll
  async getEmployeePayroll(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const { month, year } = req.query;

      if (!month || !year) {
        throw new ValidationError('Month and year are required');
      }

      const employee = await prisma.employee.findUnique({
        where: { id }
      });

      if (!employee) {
        throw new NotFoundError('Employee not found');
      }

      // Get attendance for the month
      const startDate = new Date(parseInt(year as string), parseInt(month as string) - 1, 1);
      const endDate = new Date(parseInt(year as string), parseInt(month as string), 0);

      const attendance = await prisma.attendance.findMany({
        where: {
          employeeId: id,
          date: {
            gte: startDate,
            lte: endDate
          }
        }
      });

      // Calculate working days
      let presentDays = 0;
      let absentDays = 0;
      let halfDays = 0;
      let leaveDays = 0;

      attendance.forEach(record => {
        switch (record.status) {
          case 'PRESENT':
            presentDays++;
            break;
          case 'ABSENT':
            absentDays++;
            break;
          case 'HALF_DAY':
            halfDays++;
            break;
          case 'LEAVE':
            leaveDays++;
            break;
        }
      });

      // Calculate salary
      const daysInMonth = endDate.getDate();
      const dailyRate = employee.salary / daysInMonth;
      const workingDays = presentDays + (halfDays * 0.5);
      const payableSalary = dailyRate * workingDays;

      res.json({
        success: true,
        data: {
          employee: {
            id: employee.id,
            name: employee.name,
            designation: employee.designation,
            department: employee.department,
            baseSalary: employee.salary
          },
          month: parseInt(month as string),
          year: parseInt(year as string),
          daysInMonth,
          attendance: {
            present: presentDays,
            absent: absentDays,
            halfDay: halfDays,
            leave: leaveDays,
            total: attendance.length
          },
          calculation: {
            dailyRate,
            workingDays,
            payableSalary: Math.round(payableSalary * 100) / 100
          }
        }
      });
    } catch (error) {
      next(error);
    }
  }
}