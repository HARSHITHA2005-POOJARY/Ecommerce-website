import { Request, Response, NextFunction } from 'express';
import { PrismaClient } from '@prisma/client';
import { AuthRequest } from '../middleware/auth';
import { ValidationError, NotFoundError, ForbiddenError } from '../middleware/errorHandler';

const prisma = new PrismaClient();

export class ProductController {
  // Get all products with filters
  async getAllProducts(req: Request, res: Response, next: NextFunction) {
    try {
      const {
        category,
        search,
        minPrice,
        maxPrice,
        minRating,
        sortBy = 'createdAt',
        order = 'desc',
        page = '1',
        limit = '50'
      } = req.query;

      const where: any = {};

      if (category) {
        where.category = category;
      }

      if (search) {
        where.OR = [
          { name: { contains: search as string, mode: 'insensitive' } },
          { description: { contains: search as string, mode: 'insensitive' } },
          { brand: { contains: search as string, mode: 'insensitive' } },
          { category: { contains: search as string, mode: 'insensitive' } }
        ];
      }

      if (minPrice || maxPrice) {
        where.price = {};
        if (minPrice) where.price.gte = parseFloat(minPrice as string);
        if (maxPrice) where.price.lte = parseFloat(maxPrice as string);
      }

      if (minRating) {
        where.rating = { gte: parseFloat(minRating as string) };
      }

      const pageNum = parseInt(page as string);
      const limitNum = parseInt(limit as string);
      const skip = (pageNum - 1) * limitNum;

      const [products, total] = await Promise.all([
        prisma.product.findMany({
          where,
          include: {
            seller: {
              select: {
                id: true,
                businessName: true,
                user: {
                  select: {
                    name: true
                  }
                }
              }
            }
          },
          orderBy: { [sortBy as string]: order },
          skip,
          take: limitNum
        }),
        prisma.product.count({ where })
      ]);

      res.json({
        success: true,
        data: products,
        pagination: {
          page: pageNum,
          limit: limitNum,
          total,
          pages: Math.ceil(total / limitNum)
        }
      });
    } catch (error) {
      next(error);
    }
  }

  // Get product by ID
  async getProductById(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;

      const product = await prisma.product.findUnique({
        where: { id },
        include: {
          seller: {
            select: {
              id: true,
              businessName: true,
              user: {
                select: {
                  name: true,
                  email: true
                }
              }
            }
          }
        }
      });

      if (!product) {
        throw new NotFoundError('Product not found');
      }

      res.json({
        success: true,
        data: product
      });
    } catch (error) {
      next(error);
    }
  }

  // Create product
  async createProduct(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const {
        name,
        description,
        price,
        originalPrice,
        discount,
        category,
        brand,
        image,
        stock = 0,
        rating = 4.5,
        tags = []
      } = req.body;

      // Validate required fields
      if (!name || !description || !price || !category || !brand || !image) {
        throw new ValidationError('Missing required fields');
      }

      // Get seller ID if user is seller
      let sellerId = null;
      if (req.user!.role === 'SELLER') {
        const seller = await prisma.seller.findUnique({
          where: { userId: req.user!.id }
        });

        if (!seller || !seller.approved) {
          throw new ForbiddenError('Seller account not approved');
        }

        sellerId = seller.id;
      }

      const product = await prisma.product.create({
        data: {
          name,
          description,
          price: parseFloat(price),
          originalPrice: originalPrice ? parseFloat(originalPrice) : null,
          discount: discount ? parseInt(discount) : null,
          category,
          brand,
          image,
          stock: parseInt(stock),
          rating: parseFloat(rating),
          tags,
          sellerId
        },
        include: {
          seller: {
            select: {
              businessName: true
            }
          }
        }
      });

      res.status(201).json({
        success: true,
        message: 'Product created successfully',
        data: product
      });
    } catch (error) {
      next(error);
    }
  }

  // Update product
  async updateProduct(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const updateData = req.body;

      // Check if product exists
      const existingProduct = await prisma.product.findUnique({
        where: { id },
        include: { seller: true }
      });

      if (!existingProduct) {
        throw new NotFoundError('Product not found');
      }

      // Check permissions
      if (req.user!.role === 'SELLER') {
        const seller = await prisma.seller.findUnique({
          where: { userId: req.user!.id }
        });

        if (!seller || existingProduct.sellerId !== seller.id) {
          throw new ForbiddenError('You can only update your own products');
        }
      }

      const product = await prisma.product.update({
        where: { id },
        data: updateData,
        include: {
          seller: {
            select: {
              businessName: true
            }
          }
        }
      });

      res.json({
        success: true,
        message: 'Product updated successfully',
        data: product
      });
    } catch (error) {
      next(error);
    }
  }

  // Delete product
  async deleteProduct(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;

      const existingProduct = await prisma.product.findUnique({
        where: { id },
        include: { seller: true }
      });

      if (!existingProduct) {
        throw new NotFoundError('Product not found');
      }

      // Check permissions
      if (req.user!.role === 'SELLER') {
        const seller = await prisma.seller.findUnique({
          where: { userId: req.user!.id }
        });

        if (!seller || existingProduct.sellerId !== seller.id) {
          throw new ForbiddenError('You can only delete your own products');
        }
      }

      await prisma.product.delete({
        where: { id }
      });

      res.json({
        success: true,
        message: 'Product deleted successfully'
      });
    } catch (error) {
      next(error);
    }
  }

  // Get all categories
  async getCategories(req: Request, res: Response, next: NextFunction) {
    try {
      const categories = await prisma.product.findMany({
        select: {
          category: true
        },
        distinct: ['category']
      });

      const categoryList = categories.map(c => c.category);

      res.json({
        success: true,
        data: categoryList
      });
    } catch (error) {
      next(error);
    }
  }
}
