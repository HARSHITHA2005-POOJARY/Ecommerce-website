import { Request, Response, NextFunction } from 'express';
import { PrismaClient } from '@prisma/client';
import { AuthRequest } from '../middleware/auth';
import { ValidationError, NotFoundError } from '../middleware/errorHandler';

const prisma = new PrismaClient();
const MAX_QUANTITY = 30;

export class CartController {
  // Get user's cart
  async getCart(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const cartItems = await prisma.cartItem.findMany({
        where: { userId: req.user!.id },
        include: {
          product: true
        }
      });

      res.json({
        success: true,
        data: cartItems
      });
    } catch (error) {
      next(error);
    }
  }

  // Add item to cart
  async addToCart(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { productId, quantity = 1 } = req.body;

      if (!productId) {
        throw new ValidationError('Product ID is required');
      }

      // Check if product exists
      const product = await prisma.product.findUnique({
        where: { id: productId }
      });

      if (!product) {
        throw new NotFoundError('Product not found');
      }

      // Check stock
      if (product.stock < quantity) {
        throw new ValidationError('Insufficient stock');
      }

      // Check if item already in cart
      const existingItem = await prisma.cartItem.findUnique({
        where: {
          userId_productId: {
            userId: req.user!.id,
            productId
          }
        }
      });

      if (existingItem) {
        // Update quantity (with max limit)
        const newQuantity = Math.min(existingItem.quantity + quantity, MAX_QUANTITY);
        
        if (existingItem.quantity >= MAX_QUANTITY) {
          throw new ValidationError(`Maximum quantity limit is ${MAX_QUANTITY}`);
        }

        const updatedItem = await prisma.cartItem.update({
          where: { id: existingItem.id },
          data: { quantity: newQuantity },
          include: { product: true }
        });

        return res.json({
          success: true,
          message: 'Cart updated successfully',
          data: updatedItem
        });
      }

      // Create new cart item
      const cartItem = await prisma.cartItem.create({
        data: {
          userId: req.user!.id,
          productId,
          quantity: Math.min(quantity, MAX_QUANTITY)
        },
        include: { product: true }
      });

      res.status(201).json({
        success: true,
        message: 'Item added to cart',
        data: cartItem
      });
    } catch (error) {
      next(error);
    }
  }

  // Update cart item quantity
  async updateQuantity(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { productId } = req.params;
      const { quantity } = req.body;

      if (!quantity || quantity < 1) {
        throw new ValidationError('Quantity must be at least 1');
      }

      if (quantity > MAX_QUANTITY) {
        throw new ValidationError(`Maximum quantity limit is ${MAX_QUANTITY}`);
      }

      const cartItem = await prisma.cartItem.findUnique({
        where: {
          userId_productId: {
            userId: req.user!.id,
            productId
          }
        },
        include: { product: true }
      });

      if (!cartItem) {
        throw new NotFoundError('Cart item not found');
      }

      // Check stock
      if (cartItem.product.stock < quantity) {
        throw new ValidationError('Insufficient stock');
      }

      const updatedItem = await prisma.cartItem.update({
        where: { id: cartItem.id },
        data: { quantity },
        include: { product: true }
      });

      res.json({
        success: true,
        message: 'Cart updated successfully',
        data: updatedItem
      });
    } catch (error) {
      next(error);
    }
  }

  // Remove item from cart
  async removeFromCart(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { productId } = req.params;

      await prisma.cartItem.delete({
        where: {
          userId_productId: {
            userId: req.user!.id,
            productId
          }
        }
      });

      res.json({
        success: true,
        message: 'Item removed from cart'
      });
    } catch (error) {
      next(error);
    }
  }

  // Clear cart
  async clearCart(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      await prisma.cartItem.deleteMany({
        where: { userId: req.user!.id }
      });

      res.json({
        success: true,
        message: 'Cart cleared successfully'
      });
    } catch (error) {
      next(error);
    }
  }
}
