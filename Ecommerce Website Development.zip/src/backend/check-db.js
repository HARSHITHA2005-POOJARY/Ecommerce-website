const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function checkDatabase() {
  try {
    console.log('🔍 Checking Database...\n');
    
    // Check Users
    const userCount = await prisma.user.count();
    const users = await prisma.user.findMany({ take: 5 });
    console.log(`✅ Users: ${userCount} total`);
    console.log('   Sample users:', users.map(u => `${u.email} (${u.role})`).join(', '));
    
    // Check Products
    const productCount = await prisma.product.count();
    const products = await prisma.product.findMany({ take: 3 });
    console.log(`\n✅ Products: ${productCount} total`);
    console.log('   Sample products:', products.map(p => p.name).join(', '));
    
    // Check Orders
    const orderCount = await prisma.order.count();
    console.log(`\n✅ Orders: ${orderCount} total`);
    
    // Check Cart Items
    const cartCount = await prisma.cartItem.count();
    console.log(`\n✅ Cart Items: ${cartCount} total`);
    
    // Check Sellers
    const sellerCount = await prisma.seller.count();
    console.log(`\n✅ Sellers: ${sellerCount} total`);
    
    // Check Employees
    const employeeCount = await prisma.employee.count();
    console.log(`\n✅ Employees: ${employeeCount} total`);
    
    console.log('\n✅ Database is working correctly!');
    
  } catch (error) {
    console.error('❌ Database Error:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

checkDatabase();
