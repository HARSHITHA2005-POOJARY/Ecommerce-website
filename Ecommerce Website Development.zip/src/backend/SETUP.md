# 🚀 Quick Setup Guide

## Step-by-Step Backend Setup

### 1. Install PostgreSQL

#### On macOS (using Homebrew)
```bash
brew install postgresql@14
brew services start postgresql@14
```

#### On Ubuntu/Debian
```bash
sudo apt update
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
```

#### On Windows
Download and install from [PostgreSQL Official Site](https://www.postgresql.org/download/windows/)

---

### 2. Create Database

```bash
# Access PostgreSQL
sudo -u postgres psql

# Or on Mac/Windows
psql -U postgres

# Create database
CREATE DATABASE shophub;

# Create user (optional)
CREATE USER shophub_user WITH PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE shophub TO shophub_user;

# Exit
\q
```

---

### 3. Install Node Dependencies

```bash
cd backend
npm install
```

---

### 4. Configure Environment

```bash
# Copy example env file
cp .env.example .env

# Edit .env file
nano .env
```

**Update these values:**
```env
DATABASE_URL="postgresql://postgres:your_password@localhost:5432/shophub?schema=public"
JWT_SECRET="generate-a-random-secret-key"
```

**Generate JWT Secret:**
```bash
# On Linux/Mac
openssl rand -base64 32

# Or use Node.js
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
```

---

### 5. Run Database Migrations

```bash
# Generate Prisma Client
npm run prisma:generate

# Run migrations (creates tables)
npm run prisma:migrate

# Seed database with initial data
npm run seed
```

---

### 6. Start the Server

```bash
# Development mode (auto-reload)
npm run dev
```

You should see:
```
🚀 Server running on port 5000
📡 Environment: development
🌐 Frontend URL: http://localhost:3000
```

---

### 7. Verify Installation

Open browser or use cURL:

```bash
# Health check
curl http://localhost:5000/api/health

# Expected response:
{
  "status": "OK",
  "message": "ShopHub API is running",
  "timestamp": "2024-01-31T..."
}
```

---

### 8. Test Authentication

```bash
# Login as admin
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@shophub.com","password":"admin123"}'

# You should get a JWT token in response
```

---

## 🎯 Default Accounts (After Seeding)

### Admin Account
```
Email: admin@shophub.com
Password: admin123
Role: ADMIN
```

### Seller Account
```
Email: test@seller.com
Password: seller123
Role: SELLER
Status: Approved
```

---

## 🔧 Common Issues

### Issue: "Can't connect to database"
**Solution:**
```bash
# Check if PostgreSQL is running
sudo service postgresql status

# Start PostgreSQL
sudo service postgresql start

# Check DATABASE_URL in .env
```

### Issue: "Port 5000 already in use"
**Solution:**
```bash
# Find process
lsof -i :5000

# Kill it
kill -9 <PID>

# Or change port in .env
PORT=5001
```

### Issue: "Prisma Client not found"
**Solution:**
```bash
npm run prisma:generate
```

### Issue: "Migration failed"
**Solution:**
```bash
# Reset database (WARNING: Deletes all data)
npx prisma migrate reset

# Then run migrations again
npm run prisma:migrate
npm run seed
```

---

## 🧪 Testing the API

### Using Prisma Studio (Database GUI)
```bash
npm run prisma:studio
```

Opens at `http://localhost:5555` - you can view and edit data directly!

### Using cURL

```bash
# Get all products
curl http://localhost:5000/api/products

# Login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@shophub.com","password":"admin123"}'

# Create product (replace YOUR_TOKEN)
curl -X POST http://localhost:5000/api/products \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "name": "Test Product",
    "description": "Test description",
    "price": 999,
    "category": "Electronics",
    "brand": "Test Brand",
    "image": "https://via.placeholder.com/400",
    "stock": 10
  }'
```

---

## 📊 Database Management

### View Database
```bash
npm run prisma:studio
```

### Reset Database
```bash
npx prisma migrate reset
npm run seed
```

### Create New Migration
```bash
# After editing schema.prisma
npx prisma migrate dev --name your_migration_name
```

### Backup Database
```bash
pg_dump shophub > backup.sql
```

### Restore Database
```bash
psql shophub < backup.sql
```

---

## 🚀 Next Steps

1. **Frontend Integration** - Update frontend API calls to use `http://localhost:5000/api`
2. **Test All Endpoints** - Use Postman or cURL
3. **Add More Products** - Via API or Prisma Studio
4. **Configure CORS** - Update `FRONTEND_URL` in .env
5. **Deploy** - Follow deployment guide in README.md

---

## ✅ Checklist

- [ ] PostgreSQL installed and running
- [ ] Database created
- [ ] Dependencies installed
- [ ] .env file configured
- [ ] Migrations run successfully
- [ ] Database seeded
- [ ] Server running on port 5000
- [ ] Health check passes
- [ ] Can login as admin
- [ ] Can fetch products

---

## 🆘 Need Help?

- Check the main README.md for detailed API documentation
- Review error messages carefully
- Ensure PostgreSQL is running
- Verify DATABASE_URL is correct
- Check Node.js version (18+)

---

**🎉 Setup Complete! Your backend is ready to use!**
