# 📊 Database Audit Logging & Inspection Guide

## Overview
ShopHub now includes comprehensive audit logging that tracks **every database action** with detailed information about who did what, when, and how. This guide explains how to use the audit system and check your database.

---

## 🔍 How to Check the Database

### Method 1: Using the Audit Log Viewer (Recommended)
The easiest way to view all database activities is through the **Admin Dashboard**:

1. **Login as Admin**
   - Go to the ShopHub homepage
   - Click "Login" in the top right
   - Enter admin credentials
   - Select "Admin Dashboard"

2. **Access Audit Logs**
   - Click on the "**Audit Logs**" tab
   - You'll see a comprehensive dashboard with:
     - **Total Actions**: Count of all logged activities
     - **Failed Actions**: Number of errors encountered
     - **Active Users**: Unique users tracked
     - **Action Types**: Different types of actions logged

3. **Filter and Search**
   - **Search bar**: Search by action, entity, or user
   - **Action Type filter**: Filter by specific actions (LOGIN, PRODUCT_ADD, etc.)
   - **Entity Type filter**: Filter by entity (PRODUCT, USER, ORDER, etc.)
   - **User filter**: Filter by specific user
   - **Date Range filter**: View logs between specific dates

4. **View Details**
   - Click the "eye" icon on any log entry
   - See complete details including:
     - Timestamp
     - User information
     - Action performed
     - Entity affected
     - IP address
     - User agent
     - Error messages (if failed)
     - Additional context

5. **Export Data**
   - Click "Export CSV" to download all logs
   - Great for external analysis or reporting

### Method 2: Using Supabase Dashboard (Direct Database Access)
Access your Supabase database directly:

1. **Go to Supabase Dashboard**
   - Visit [https://app.supabase.com](https://app.supabase.com)
   - Login with your Supabase credentials
   - Select your ShopHub project

2. **Access Table Editor**
   - Click "Table Editor" in the sidebar
   - You'll see the `kv_store_6d108759` table

3. **View Audit Logs**
   - Look for keys starting with `audit:`
   - Keys format:
     - `audit:2024-12-11T...:{id}` - Main audit logs
     - `audit:user:{userId}:...` - User-specific logs
     - `audit:entity:{entityType}:{entityId}:...` - Entity-specific logs

4. **Query Data**
   - Use the SQL Editor to run custom queries
   - Example queries provided below

### Method 3: Using API Endpoints
You can programmatically access audit logs via API:

```bash
# Get all audit logs
curl https://{projectId}.supabase.co/functions/v1/make-server-6d108759/audit/logs?limit=100 \
  -H "Authorization: Bearer {publicAnonKey}"

# Get logs for specific user
curl https://{projectId}.supabase.co/functions/v1/make-server-6d108759/audit/logs/user/{userId} \
  -H "Authorization: Bearer {publicAnonKey}"

# Get logs for specific entity
curl https://{projectId}.supabase.co/functions/v1/make-server-6d108759/audit/logs/entity/PRODUCT/{productId} \
  -H "Authorization: Bearer {publicAnonKey}"

# Get logs by action type
curl https://{projectId}.supabase.co/functions/v1/make-server-6d108759/audit/logs/action/PRODUCT_ADD \
  -H "Authorization: Bearer {publicAnonKey}"

# Get logs by date range
curl "https://{projectId}.supabase.co/functions/v1/make-server-6d108759/audit/logs/date-range?startDate=2024-12-01&endDate=2024-12-31" \
  -H "Authorization: Bearer {publicAnonKey}"

# Get audit statistics
curl https://{projectId}.supabase.co/functions/v1/make-server-6d108759/audit/stats \
  -H "Authorization: Bearer {publicAnonKey}"
```

---

## 📝 What Actions Are Tracked?

### Authentication Actions
- ✅ **LOGIN** - User login successful
- ✅ **LOGOUT** - User logout
- ✅ **SIGNUP** - New user registration
- ❌ **LOGIN_FAILED** - Failed login attempt

### Product Actions
- ✅ **PRODUCT_ADD** - New product created
- ✅ **PRODUCT_UPDATE** - Product details updated
- ✅ **PRODUCT_DELETE** - Product removed
- ✅ **PRODUCT_VIEW** - Product viewed (if implemented)

### Order Actions
- ✅ **ORDER_CREATE** - New order placed
- ✅ **ORDER_UPDATE** - Order details updated
- ✅ **ORDER_CANCEL** - Order cancelled
- ✅ **ORDER_STATUS_CHANGE** - Order status changed

### Cart Actions
- ✅ **CART_ADD** - Item added to cart
- ✅ **CART_UPDATE** - Cart item quantity updated
- ✅ **CART_REMOVE** - Item removed from cart
- ✅ **CART_CLEAR** - Cart cleared

### Employee Actions
- ✅ **EMPLOYEE_ADD** - New employee added
- ✅ **EMPLOYEE_UPDATE** - Employee details updated
- ✅ **EMPLOYEE_DELETE** - Employee removed
- ✅ **EMPLOYEE_APPROVE** - Employee approved
- ✅ **EMPLOYEE_REJECT** - Employee rejected

### Attendance Actions
- ✅ **ATTENDANCE_MARK** - Attendance marked (present/absent)
- ✅ **ATTENDANCE_UPDATE** - Attendance record updated

### Seller Actions
- ✅ **SELLER_REGISTER** - New seller registered
- ✅ **SELLER_APPROVE** - Seller approved
- ✅ **SELLER_UPDATE** - Seller details updated
- ✅ **SELLER_DELETE** - Seller removed

### Admin Actions
- ✅ **COMMISSION_UPDATE** - Seller commission updated
- ✅ **SETTINGS_UPDATE** - System settings changed
- ✅ **APPROVE** - General approval action
- ✅ **REJECT** - General rejection action

---

## 🔧 How to Implement Audit Logging in Your Code

### Step 1: Import the Audit Logger

```typescript
import { logAudit, AuditAction, EntityType } from './auditLogger.tsx';
```

### Step 2: Add Audit Logging to Your Routes

#### Example: Product Creation
```typescript
app.post('/make-server-6d108759/products', async (c) => {
  const request = c.req.raw;
  let userId = 'user-id-from-auth';
  let userEmail = 'user@example.com';
  let userRole = 'ADMIN';
  
  try {
    // Your product creation logic
    const product = {
      id: crypto.randomUUID(),
      name: 'Product Name',
      price: 99.99,
    };
    
    // Save product to database
    await kv.set(`product:${product.id}`, product);
    
    // ✅ LOG SUCCESS
    await logAudit({
      userId,
      userEmail,
      userRole,
      action: AuditAction.PRODUCT_ADD,
      entityType: EntityType.PRODUCT,
      entityId: product.id,
      entityName: product.name,
      details: { price: product.price },
      request,
      success: true,
    });
    
    return c.json({ success: true, data: product });
    
  } catch (error) {
    // ❌ LOG FAILURE
    await logAudit({
      userId,
      userEmail,
      userRole,
      action: AuditAction.PRODUCT_ADD,
      entityType: EntityType.PRODUCT,
      entityId: null,
      entityName: null,
      details: {},
      request,
      success: false,
      errorMessage: error.message,
    });
    
    return c.json({ success: false, error: error.message }, 500);
  }
});
```

#### Example: User Login
```typescript
app.post('/make-server-6d108759/auth/login', async (c) => {
  const request = c.req.raw;
  
  try {
    const { email, password } = await c.req.json();
    const user = await authenticateUser(email, password);
    
    if (!user) {
      // ❌ LOG FAILED LOGIN
      await logAudit({
        userId: null,
        userEmail: email,
        userRole: null,
        action: AuditAction.LOGIN_FAILED,
        entityType: EntityType.USER,
        entityId: null,
        entityName: email,
        details: { reason: 'Invalid credentials' },
        request,
        success: false,
        errorMessage: 'Invalid email or password',
      });
      
      return c.json({ success: false, error: 'Invalid credentials' }, 401);
    }
    
    // ✅ LOG SUCCESSFUL LOGIN
    await logAudit({
      userId: user.id,
      userEmail: user.email,
      userRole: user.role,
      action: AuditAction.LOGIN,
      entityType: EntityType.USER,
      entityId: user.id,
      entityName: user.email,
      details: { loginTime: new Date().toISOString() },
      request,
      success: true,
    });
    
    return c.json({ success: true, data: user });
    
  } catch (error) {
    // ❌ LOG ERROR
    await logAudit({
      userId: null,
      userEmail: null,
      userRole: null,
      action: AuditAction.LOGIN_FAILED,
      entityType: EntityType.USER,
      entityId: null,
      entityName: null,
      details: {},
      request,
      success: false,
      errorMessage: error.message,
    });
    
    return c.json({ success: false, error: error.message }, 500);
  }
});
```

### Step 3: Always Log Both Success and Failure
```typescript
try {
  // Your operation
  // ...
  
  // ✅ Log success
  await logAudit({ /* ... */ success: true });
  
} catch (error) {
  // ❌ Log failure
  await logAudit({ /* ... */ success: false, errorMessage: error.message });
}
```

---

## 📊 Audit Log Data Structure

Each audit log contains:

```typescript
{
  id: string;                    // Unique log ID
  timestamp: string;             // ISO 8601 timestamp
  userId: string | null;         // User who performed action
  userEmail: string | null;      // User's email
  userRole: string | null;       // User's role (ADMIN, SELLER, EMPLOYEE, CUSTOMER)
  action: AuditAction;           // Action performed
  entityType: EntityType;        // Type of entity affected
  entityId: string | null;       // ID of entity affected
  entityName: string | null;     // Name/description of entity
  details: Record<string, any>;  // Additional context data
  ipAddress: string | null;      // User's IP address
  userAgent: string | null;      // Browser/client info
  success: boolean;              // Whether action succeeded
  errorMessage?: string;         // Error message if failed
}
```

---

## 🔐 Security & Privacy

### Important Notes:
1. **Audit logs capture sensitive information** - Ensure proper access control
2. **Only admins should access audit logs** - Add authentication to audit routes
3. **IP addresses are logged** - For security tracking
4. **User agents are logged** - To identify client types
5. **Error messages may contain sensitive info** - Be careful with what you log

### Recommended: Add Authentication to Audit Routes
```typescript
app.get('/make-server-6d108759/audit/logs', async (c) => {
  // Check if user is admin
  const authHeader = c.req.header('Authorization');
  const user = await validateAdmin(authHeader);
  
  if (!user || user.role !== 'ADMIN') {
    return c.json({ success: false, error: 'Unauthorized' }, 401);
  }
  
  // Continue with audit log retrieval
  // ...
});
```

---

## 🧹 Maintenance

### Cleaning Old Logs
Audit logs can accumulate over time. Clean them periodically:

```bash
# Delete logs older than 90 days
curl -X DELETE "https://{projectId}.supabase.co/functions/v1/make-server-6d108759/audit/logs/cleanup?daysToKeep=90" \
  -H "Authorization: Bearer {publicAnonKey}"
```

Or use the utility function:
```typescript
import { clearOldAuditLogs } from './auditLogger.tsx';

// Delete logs older than 90 days
const deletedCount = await clearOldAuditLogs(90);
console.log(`Deleted ${deletedCount} old audit logs`);
```

---

## 📈 Common Use Cases

### 1. Track Who Modified a Product
```typescript
const logs = await getAuditLogsByEntity(EntityType.PRODUCT, productId);
console.log('Product modification history:', logs);
```

### 2. Monitor Failed Login Attempts
```typescript
const failedLogins = await getAuditLogsByAction(AuditAction.LOGIN_FAILED);
console.log('Failed login attempts:', failedLogins);
```

### 3. See All Actions by a User
```typescript
const userLogs = await getAuditLogsByUser(userId);
console.log('User activity history:', userLogs);
```

### 4. Generate Monthly Reports
```typescript
const logs = await getAuditLogsByDateRange(
  '2024-12-01',
  '2024-12-31'
);
console.log('December activity:', logs);
```

### 5. Monitor System Health
```typescript
const stats = await getAuditStats();
console.log('Failed actions:', stats.failedActions);
console.log('Most active users:', stats.logsByUser);
console.log('Most common actions:', stats.logsByAction);
```

---

## 🎯 Best Practices

1. **Always log both success and failure** - Helps with debugging
2. **Include relevant context in details** - Store before/after values
3. **Don't log sensitive data** - Avoid passwords, tokens, etc.
4. **Use descriptive entity names** - Makes logs more readable
5. **Clean old logs regularly** - Keep database size manageable
6. **Monitor failed actions** - May indicate security issues
7. **Use for compliance** - Track data access and modifications
8. **Export regularly** - Backup audit logs for long-term storage

---

## 🚀 Next Steps

1. **Integrate audit logging into all your existing routes** - Use the examples in `/supabase/functions/server/exampleWithAudit.tsx`
2. **Add authentication to audit endpoints** - Ensure only admins can view logs
3. **Set up automated log cleanup** - Schedule periodic cleanup jobs
4. **Create custom reports** - Build dashboards for your specific needs
5. **Monitor security events** - Set up alerts for suspicious activities

---

## 📚 API Reference

### Available Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/audit/logs` | Get all audit logs |
| GET | `/audit/logs/user/:userId` | Get logs for a user |
| GET | `/audit/logs/entity/:type/:id` | Get logs for an entity |
| GET | `/audit/logs/action/:action` | Get logs by action type |
| GET | `/audit/logs/date-range` | Get logs by date range |
| GET | `/audit/stats` | Get audit statistics |
| DELETE | `/audit/logs/cleanup` | Clean old logs |
| GET | `/audit/actions` | List all action types |
| GET | `/audit/entities` | List all entity types |

### Query Parameters

- `limit` - Number of results to return (default: 100)
- `startDate` - Start date for date range queries (ISO 8601)
- `endDate` - End date for date range queries (ISO 8601)
- `daysToKeep` - Days to keep logs when cleaning (default: 90)

---

## 🛠️ Troubleshooting

### Issue: Audit logs not appearing
**Solution**: Check that you're calling `logAudit()` in your routes and that the Supabase connection is working.

### Issue: Can't access audit logs in admin dashboard
**Solution**: Ensure you're logged in as an admin and that the Supabase Edge Function is deployed.

### Issue: Database growing too large
**Solution**: Run the cleanup function regularly to remove old logs.

### Issue: Missing user information in logs
**Solution**: Make sure you're passing `userId`, `userEmail`, and `userRole` to `logAudit()`.

---

## 📞 Support

For questions or issues:
1. Check this documentation
2. Review `/supabase/functions/server/exampleWithAudit.tsx` for implementation examples
3. View the Audit Log Viewer in the Admin Dashboard
4. Check browser console for errors

---

**Remember**: Audit logging is for tracking system activities and ensuring accountability. Use it responsibly and protect access to audit data!
