# Backend Setup Required

⚠️ **Important**: The backend server must be running for the application to work properly.

## Network Error Fix

The "Network Error" you're seeing means the backend server is not running or not accessible. Follow these steps to start it:

### Step 1: Navigate to Backend Directory

```bash
cd backend
```

### Step 2: Install Dependencies (if not already done)

```bash
npm install
```

### Step 3: Set Up Environment Variables

Create a `.env` file in the `/backend` directory with the following content:

```env
DATABASE_URL="postgresql://username:password@localhost:5432/shophub?schema=public"
JWT_SECRET="your-super-secret-jwt-key-change-this-in-production"
PORT=5000
```

Replace `username` and `password` with your PostgreSQL credentials.

### Step 4: Run Database Migrations

```bash
npx prisma migrate dev
```

This will:
- Create the database tables
- Apply the schema changes (including the fixed `scheduleWorkingDays` array)
- Generate the Prisma Client

### Step 5: (Optional) Seed the Database

```bash
npm run seed
```

This will create sample data including products, users, etc.

### Step 6: Start the Backend Server

```bash
npm run dev
```

You should see output like:
```
🚀 Server running on port 5000
✅ Database connected successfully
```

### Step 7: Verify Backend is Running

Open a browser and go to: `http://localhost:5000/api/products`

You should see a JSON response with products data.

## Common Issues

### Port Already in Use
If port 5000 is already in use, change the `PORT` in your `.env` file:
```env
PORT=5001
```

Then update the frontend API URL in `/utils/api.ts` or set the environment variable:
```bash
VITE_API_URL=http://localhost:5001/api
```

### Database Connection Error
Make sure PostgreSQL is running and the credentials in `DATABASE_URL` are correct.

Check PostgreSQL status:
```bash
# Mac (Homebrew)
brew services list

# Linux
sudo systemctl status postgresql

# Windows
# Check Services app for PostgreSQL service
```

### Prisma Client Error
If you get Prisma Client errors, regenerate it:
```bash
npx prisma generate
```

## What's Fixed

✅ **React forwardRef warnings** - Button and DialogOverlay components now use `React.forwardRef`
✅ **Missing DialogDescription** - Added accessibility description to employee dialog
✅ **Better error handling** - Network errors now show helpful messages
✅ **Async/await in handlers** - Employee add function properly handles errors
✅ **Database schema** - `scheduleWorkingDays` is now a proper integer array

## Next Steps

Once the backend is running:
1. Login as admin (email: `admin@shophub.com`, password: `admin123` - or create your own)
2. Add employees with schedules
3. Test employee login
4. Mark attendance
5. View payroll calculations

If you continue to have issues, check the browser console and backend terminal for specific error messages.
