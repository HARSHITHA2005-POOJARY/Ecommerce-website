# ShopHub - Full-Featured E-commerce Platform

A comprehensive e-commerce web application built with React, TypeScript, and Tailwind CSS, featuring a complete shopping experience with user authentication, product management, shopping cart, checkout, order tracking, and a full admin dashboard.

## 🌟 Features

### Customer Features
- **Product Browsing**: Browse products by categories (Electronics, Fashion, Home, Sports, Beauty, Books)
- **Search & Filter**: Advanced search functionality with category filtering
- **Product Details**: Detailed product pages with images, descriptions, ratings, and reviews
- **Shopping Cart**: Add/remove items, update quantities, view cart total
- **User Authentication**: Login/Signup with admin and customer roles
- **Checkout Process**: Complete checkout with shipping address and payment details
- **Order Tracking**: Track order status with real-time updates
- **Responsive Design**: Mobile-friendly interface that works on all devices

### Admin Features
- **Admin Dashboard**: Comprehensive analytics and overview
- **Product Management**: Add, edit, delete products with image URLs
- **Order Management**: View all orders, update order status
- **Analytics**: Revenue overview, order status distribution, top categories
- **Role-based Access**: Separate admin panel accessible only to admin users

### Technical Features
- **React 18** with TypeScript for type safety
- **Context API** for state management
- **LocalStorage** for data persistence
- **Tailwind CSS v4** for styling
- **Shadcn/UI** components for polished UI
- **Lucide Icons** for beautiful iconography
- **Toast Notifications** for user feedback
- **Currency in Indian Rupees (₹)**

## 📋 Prerequisites

Before running this application, ensure you have the following installed on your system:

### Required Software

1. **Node.js** (v18.0.0 or higher)
   - Download from: https://nodejs.org/
   - Verify installation: `node --version`

2. **npm** (v9.0.0 or higher) or **yarn** (v1.22.0 or higher)
   - npm comes with Node.js
   - Verify installation: `npm --version`
   - Or install yarn: `npm install -g yarn`

3. **Git** (Optional, for cloning)
   - Download from: https://git-scm.com/
   - Verify installation: `git --version`

### Supported Platforms

This application can run on:
- **Windows** (10 or later)
- **macOS** (10.14 Mojave or later)
- **Linux** (Ubuntu 18.04+, Debian 10+, Fedora 30+, etc.)

### Supported Browsers

- Google Chrome (v90+)
- Mozilla Firefox (v88+)
- Microsoft Edge (v90+)
- Safari (v14+)

## 🚀 Installation & Setup

### Step 1: Clone or Download the Project

```bash
# If using Git
git clone <repository-url>
cd shophub

# Or download and extract the ZIP file
```

### Step 2: Install Dependencies

```bash
# Using npm
npm install

# Or using yarn
yarn install
```

This will install all required packages listed in the dependencies section below.

### Step 3: Start the Development Server

```bash
# Using npm
npm run dev

# Or using yarn
yarn dev
```

The application will start on `http://localhost:5173` (default Vite port)

### Step 4: Access the Application

Open your browser and navigate to:
```
http://localhost:5173
```

## 👤 Demo Credentials

### Admin Account
- **Email**: `admin@shophub.com`
- **Password**: `admin123`

### Customer Account
You can create a new account via the signup page, or use the "Continue as Guest" option.

## 📦 Package Details

### Core Dependencies

```json
{
  "react": "^18.3.1",
  "react-dom": "^18.3.1",
  "typescript": "^5.0.0"
}
```

### UI & Styling

```json
{
  "tailwindcss": "^4.0.0",
  "lucide-react": "latest",
  "sonner": "^2.0.3"
}
```

### Development Dependencies

```json
{
  "vite": "^5.0.0",
  "@vitejs/plugin-react": "^4.0.0",
  "@types/react": "^18.3.0",
  "@types/react-dom": "^18.3.0",
  "typescript": "^5.0.0",
  "eslint": "^8.0.0"
}
```

### Shadcn/UI Components Used

The project uses the following Shadcn/UI components:
- Accordion
- Alert & Alert Dialog
- Aspect Ratio
- Avatar
- Badge
- Breadcrumb
- Button
- Calendar
- Card
- Carousel
- Checkbox
- Dialog
- Dropdown Menu
- Form
- Input
- Label
- Select
- Separator
- Sheet
- Skeleton
- Slider
- Switch
- Table
- Tabs
- Textarea
- Toast (Sonner)
- Tooltip

## 📁 Project Structure

```
shophub/
├── src/
│   ├── components/          # React components
│   │   ├── ui/             # Shadcn/UI components
│   │   ├── figma/          # Utility components
│   │   ├── AdminDashboard.tsx
│   │   ├── AuthPages.tsx
│   │   ├── CartPage.tsx
│   │   ├── CheckoutPage.tsx
│   │   ├── Footer.tsx
│   │   ├── Header.tsx
│   │   ├── HomePage.tsx
│   │   ├── OrderTrackingPage.tsx
│   │   ├── ProductDetail.tsx
│   │   └── ProductList.tsx
│   ├── context/            # React Context providers
│   │   ├── AuthContext.tsx
│   │   ├── CartContext.tsx
│   │   ├── OrderContext.tsx
│   │   └── ProductContext.tsx
│   ├── data/              # Static data
│   │   └── products.ts
│   ├── types/             # TypeScript type definitions
│   │   └── index.ts
│   ├── styles/            # Global styles
│   │   └── globals.css
│   ├── App.tsx            # Main app component
│   └── main.tsx           # Entry point
├── public/                # Static assets
├── index.html            # HTML template
├── package.json          # Dependencies and scripts
├── tsconfig.json         # TypeScript configuration
├── vite.config.ts        # Vite configuration
└── tailwind.config.js    # Tailwind CSS configuration
```

## 🛠️ Available Scripts

```bash
# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview

# Lint code
npm run lint

# Type check
npm run type-check
```

## 💾 Data Persistence

The application uses **localStorage** to persist:
- User authentication state
- Shopping cart items
- Product catalog (can be modified via admin panel)
- Order history

**Note**: All data is stored locally in your browser. Clearing browser data will reset the application.

## 🔐 Security Notes

- This is a **demo/prototype** application for educational purposes
- Not suitable for production use with real customer data
- Does not include real payment processing
- User passwords are not encrypted (mock authentication only)
- Should not be used to collect PII (Personally Identifiable Information)

## 🎨 Customization

### Adding New Products

1. **Via Admin Panel** (Recommended):
   - Login as admin
   - Go to Admin Dashboard
   - Click "Add Product"
   - Fill in product details
   - Save

2. **Via Code**:
   - Edit `/src/data/products.ts`
   - Add new product objects following the existing format

### Changing Theme Colors

Edit `/src/styles/globals.css` to modify the color scheme:

```css
:root {
  --color-primary: /* your primary color */;
  --color-secondary: /* your secondary color */;
}
```

### Modifying Currency

The application uses Indian Rupees (₹). To change:
1. Find all instances of `₹` in components
2. Replace with your desired currency symbol
3. Update pricing calculations if needed

## 📱 Responsive Design

The application is fully responsive and optimized for:
- **Desktop**: 1920px and above
- **Laptop**: 1024px - 1919px
- **Tablet**: 768px - 1023px
- **Mobile**: 320px - 767px

## 🐛 Troubleshooting

### Port Already in Use

If port 5173 is already in use:

```bash
# Find and kill the process
# On Windows
netstat -ano | findstr :5173
taskkill /PID <process_id> /F

# On macOS/Linux
lsof -ti:5173 | xargs kill -9
```

Or change the port in `vite.config.ts`:

```typescript
export default defineConfig({
  server: {
    port: 3000 // Your desired port
  }
})
```

### Dependencies Installation Fails

```bash
# Clear npm cache
npm cache clean --force

# Delete node_modules and package-lock.json
rm -rf node_modules package-lock.json

# Reinstall dependencies
npm install
```

### Build Fails

Ensure you have the correct Node.js version:

```bash
node --version  # Should be v18.0.0 or higher
```

## 📄 License

This project is created for educational purposes. Feel free to use and modify as needed.

## 🤝 Support

For issues or questions:
1. Check the troubleshooting section above
2. Review the code comments in the source files
3. Ensure all dependencies are correctly installed
4. Verify you're using compatible Node.js and browser versions

## 🚀 Deployment

### Build for Production

```bash
npm run build
```

This creates an optimized production build in the `dist/` folder.

### Deploy to Hosting Platforms

The built application can be deployed to:
- **Vercel**: `vercel --prod`
- **Netlify**: Drag and drop `dist/` folder
- **GitHub Pages**: Follow GitHub Pages deployment guide
- **Any static hosting**: Upload contents of `dist/` folder

### Environment Variables

For production deployment, you may want to add environment variables:

```bash
# .env file
VITE_API_URL=your_api_url
VITE_APP_NAME=ShopHub
```

Access in code:
```typescript
const apiUrl = import.meta.env.VITE_API_URL;
```

## 📊 Performance

The application is optimized for performance with:
- Code splitting
- Lazy loading of routes
- Optimized images
- Minimal bundle size
- Efficient re-renders with React Context

## 🔄 Updates & Maintenance

To update dependencies:

```bash
# Check for updates
npm outdated

# Update all dependencies
npm update

# Update specific package
npm install <package-name>@latest
```

## ✨ Features Roadmap

Potential future enhancements:
- [ ] Backend API integration
- [ ] Real payment gateway integration
- [ ] Product reviews and ratings system
- [ ] Wishlist functionality
- [ ] Email notifications
- [ ] Advanced filtering and sorting
- [ ] Product recommendations
- [ ] Multi-language support
- [ ] Dark mode

---

**Built with ❤️ using React, TypeScript, and Tailwind CSS**
