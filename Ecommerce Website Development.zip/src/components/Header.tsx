import React, { useState } from 'react';
import { Search, ShoppingCart, User, Heart, Menu, X, Package } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

interface HeaderProps {
  onPageChange: (page: string) => void;
  onSearch: (query: string) => void;
  currentPage: string;
}

export const Header: React.FC<HeaderProps> = ({ onPageChange, onSearch, currentPage }) => {
  const { getCartCount } = useCart();
  const { user, logout } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchQuery);
    onPageChange('products');
  };

  const categories = ['Electronics', 'Fashion', 'Home', 'Sports', 'Beauty', 'Books'];

  return (
    <header className="sticky top-0 z-50 bg-white border-b">
      {/* Top Bar */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-2">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <p className="text-sm">Free shipping on orders over ₹500!</p>
          <div className="flex gap-4 text-sm">
            <button className="hover:underline">Help</button>
            <button className="hover:underline">Track Order</button>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between gap-4">
          {/* Logo */}
          <button 
            onClick={() => onPageChange('home')}
            className="flex items-center gap-2 flex-shrink-0"
          >
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
              <ShoppingCart className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl text-blue-600">ShopHub</span>
          </button>

          {/* Search Bar */}
          <form onSubmit={handleSearch} className="flex-1 max-w-2xl hidden md:flex">
            <div className="relative w-full">
              <Input
                type="text"
                placeholder="Search for products, brands and more..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pr-10"
              />
              <button
                type="submit"
                className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500 hover:text-blue-600"
              >
                <Search className="w-5 h-5" />
              </button>
            </div>
          </form>

          {/* Actions */}
          <div className="flex items-center gap-2">
            {user ? (
              <div className="hidden md:flex items-center gap-2">
                {user.role === 'admin' && (
                  <Button
                    onClick={() => onPageChange('admin')}
                    variant="ghost"
                    size="sm"
                    className="flex items-center gap-2"
                  >
                    <Package className="w-4 h-4" />
                    Admin
                  </Button>
                )}
                {user.role === 'seller' && (
                  <Button
                    onClick={() => onPageChange('seller')}
                    variant="ghost"
                    size="sm"
                    className="flex items-center gap-2"
                  >
                    <Package className="w-4 h-4" />
                    Seller Dashboard
                  </Button>
                )}
                {user.role !== 'seller' && (
                  <Button
                    onClick={() => onPageChange('orders')}
                    variant="ghost"
                    size="sm"
                    className="flex items-center gap-2"
                  >
                    <Package className="w-4 h-4" />
                    Orders
                  </Button>
                )}
                <div className="flex items-center gap-2 px-3 py-2 hover:bg-gray-100 rounded-lg cursor-pointer">
                  <User className="w-5 h-5" />
                  <span className="text-sm">{user.name}</span>
                </div>
                <Button 
                  onClick={() => {
                    logout();
                    onPageChange('home');
                  }} 
                  variant="ghost" 
                  size="sm"
                >
                  Logout
                </Button>
              </div>
            ) : (
              <Button
                onClick={() => onPageChange('login')}
                variant="ghost"
                className="hidden md:flex items-center gap-2"
              >
                <User className="w-5 h-5" />
                <span>Login</span>
              </Button>
            )}

            <Button variant="ghost" className="relative hidden md:flex">
              <Heart className="w-5 h-5" />
            </Button>

            <Button
              onClick={() => onPageChange('cart')}
              variant="ghost"
              className="relative"
            >
              <ShoppingCart className="w-5 h-5" />
              {getCartCount() > 0 && (
                <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs">
                  {getCartCount()}
                </Badge>
              )}
            </Button>

            <Button
              variant="ghost"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Search */}
        <form onSubmit={handleSearch} className="mt-4 md:hidden">
          <div className="relative">
            <Input
              type="text"
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pr-10"
            />
            <button
              type="submit"
              className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500"
            >
              <Search className="w-5 h-5" />
            </button>
          </div>
        </form>
      </div>

      {/* Categories Navigation */}
      <div className="border-t hidden md:block">
        <div className="container mx-auto px-4">
          <nav className="flex items-center gap-6 py-3 overflow-x-auto">
            <button
              onClick={() => {
                onPageChange('products');
                onSearch('');
              }}
              className={`text-sm whitespace-nowrap hover:text-blue-600 ${
                currentPage === 'products' && !searchQuery ? 'text-blue-600' : ''
              }`}
            >
              All Products
            </button>
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => {
                  onSearch(category);
                  onPageChange('products');
                }}
                className="text-sm whitespace-nowrap hover:text-blue-600"
              >
                {category}
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t bg-white">
          <div className="container mx-auto px-4 py-4">
            <div className="flex flex-col gap-4">
              {user ? (
                <>
                  <div className="flex items-center gap-2 py-2">
                    <User className="w-5 h-5" />
                    <span>{user.name}</span>
                  </div>
                  {user.role === 'admin' && (
                    <Button
                      onClick={() => {
                        onPageChange('admin');
                        setMobileMenuOpen(false);
                      }}
                      variant="outline"
                      className="w-full"
                    >
                      <Package className="w-4 h-4 mr-2" />
                      Admin Dashboard
                    </Button>
                  )}
                  <Button
                    onClick={() => {
                      onPageChange('orders');
                      setMobileMenuOpen(false);
                    }}
                    variant="outline"
                    className="w-full"
                  >
                    <Package className="w-4 h-4 mr-2" />
                    My Orders
                  </Button>
                  <Button 
                    onClick={() => {
                      logout();
                      onPageChange('home');
                      setMobileMenuOpen(false);
                    }} 
                    variant="outline" 
                    className="w-full"
                  >
                    Logout
                  </Button>
                </>
              ) : (
                <Button
                  onClick={() => {
                    onPageChange('login');
                    setMobileMenuOpen(false);
                  }}
                  className="w-full"
                >
                  Login
                </Button>
              )}
              <div className="border-t pt-4">
                <p className="text-sm mb-2">Categories</p>
                <div className="flex flex-col gap-2">
                  {categories.map((category) => (
                    <button
                      key={category}
                      onClick={() => {
                        onSearch(category);
                        onPageChange('products');
                        setMobileMenuOpen(false);
                      }}
                      className="text-sm text-left py-2 hover:text-blue-600"
                    >
                      {category}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
