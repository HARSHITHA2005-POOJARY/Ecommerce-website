import React, { useState, useEffect } from 'react';
import { useEmployee } from '../context/EmployeeContext';
import { useProducts } from '../context/ProductContext';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Alert, AlertDescription } from './ui/alert';
import { toast } from 'sonner@2.0.3';
import { 
  LogOut, 
  Clock, 
  Calendar, 
  CheckCircle, 
  XCircle, 
  Package, 
  Plus,
  Trash2,
  User,
  IndianRupee,
  AlertCircle
} from 'lucide-react';

interface EmployeeDashboardProps {
  onPageChange: (page: string) => void;
}

export const EmployeeDashboard: React.FC<EmployeeDashboardProps> = ({ onPageChange }) => {
  const {
    currentEmployee,
    employeeLogout,
    markAttendance,
    getTodayAttendance,
    getEmployeeAttendance,
    isWorkingDay,
    isLateCheckIn,
    getMonthlyAttendanceStats,
    calculateMonthlySalary,
  } = useEmployee();

  const { products, addProduct, deleteProduct } = useProducts();

  const [currentTime, setCurrentTime] = useState(new Date());
  const [isAddProductOpen, setIsAddProductOpen] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [monthlyAttendance, setMonthlyAttendance] = useState<any[]>([]);

  const [productForm, setProductForm] = useState({
    name: '',
    description: '',
    price: '',
    originalPrice: '',
    category: '',
    brand: '',
    stock: '',
    image: '',
  });

  // Load attendance data on mount and when month/year changes
  useEffect(() => {
    if (currentEmployee) {
      loadAttendanceData();
    }
  }, [currentEmployee, selectedMonth, selectedYear]);

  const loadAttendanceData = async () => {
    if (currentEmployee) {
      const data = await getEmployeeAttendance(currentEmployee.id, selectedMonth, selectedYear);
      setMonthlyAttendance(data);
    }
  };

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  if (!currentEmployee) {
    onPageChange('login');
    return null;
  }

  const todayAttendance = getTodayAttendance(currentEmployee.id);
  const myProducts = products.filter(p => p.sellerId === currentEmployee.id);
  const stats = getMonthlyAttendanceStats(currentEmployee.id, selectedMonth, selectedYear);
  const monthlySalary = calculateMonthlySalary(currentEmployee.id, selectedMonth, selectedYear);
  const workingDay = isWorkingDay(currentEmployee.id);

  const handleCheckIn = () => {
    const time = currentTime.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' });
    const isLate = isLateCheckIn(currentEmployee.id, time);
    
    markAttendance(currentEmployee.id, 'present', time);
    
    if (isLate) {
      toast.warning(`Checked in at ${time} - You are late!`);
    } else {
      toast.success(`Checked in successfully at ${time}`);
    }
  };

  const handleCheckOut = () => {
    const time = currentTime.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' });
    
    if (todayAttendance) {
      markAttendance(currentEmployee.id, todayAttendance.status, todayAttendance.checkIn, time);
      toast.success(`Checked out at ${time}`);
    }
  };

  const handleMarkAbsent = () => {
    markAttendance(currentEmployee.id, 'absent');
    toast.info('Marked as absent');
  };

  const handleAddProduct = () => {
    if (!productForm.name || !productForm.price || !productForm.category) {
      toast.error('Please fill all required fields');
      return;
    }

    const price = parseFloat(productForm.price);
    const originalPrice = productForm.originalPrice ? parseFloat(productForm.originalPrice) : price;

    addProduct({
      name: productForm.name,
      description: productForm.description,
      price,
      originalPrice,
      discount: originalPrice > price ? Math.round(((originalPrice - price) / originalPrice) * 100) : 0,
      category: productForm.category,
      brand: productForm.brand || 'Generic',
      image: productForm.image || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500',
      rating: 4,
      reviews: 0,
      inStock: true,
      stock: productForm.stock ? parseInt(productForm.stock) : 100,
      sellerId: currentEmployee.id,
      sellerName: currentEmployee.name,
    });

    toast.success('Product added successfully!');
    setIsAddProductOpen(false);
    resetProductForm();
  };

  const handleDeleteProduct = (productId: string) => {
    if (confirm('Are you sure you want to delete this product?')) {
      deleteProduct(productId);
      toast.success('Product deleted successfully!');
    }
  };

  const handleLogout = () => {
    employeeLogout();
    toast.success('Logged out successfully');
    onPageChange('login');
  };

  const resetProductForm = () => {
    setProductForm({
      name: '',
      description: '',
      price: '',
      originalPrice: '',
      category: '',
      brand: '',
      stock: '',
      image: '',
    });
  };

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const weekDays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <User className="h-8 w-8 text-primary" />
              <div>
                <h1>Employee Dashboard</h1>
                <p className="text-sm text-muted-foreground">{currentEmployee.name} - {currentEmployee.designation}</p>
              </div>
            </div>
            <Button variant="outline" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Today's Status */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Current Time
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-mono">{currentTime.toLocaleTimeString()}</p>
              <p className="text-sm text-muted-foreground mt-2">
                {currentTime.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Work Schedule
              </CardTitle>
            </CardHeader>
            <CardContent>
              {currentEmployee.schedule ? (
                <div className="space-y-2">
                  <p><strong>Check-in:</strong> {currentEmployee.schedule.checkInTime}</p>
                  <p><strong>Check-out:</strong> {currentEmployee.schedule.checkOutTime}</p>
                  <p className="text-sm text-muted-foreground">
                    Working Days: {currentEmployee.schedule.workingDays.map(d => weekDays[d].substring(0, 3)).join(', ')}
                  </p>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No schedule set</p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <IndianRupee className="h-5 w-5" />
                Monthly Salary
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl">₹{currentEmployee.salary.toLocaleString('en-IN')}</p>
              <p className="text-sm text-muted-foreground mt-2">Base Salary</p>
            </CardContent>
          </Card>
        </div>

        {/* Attendance Section */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Today's Attendance</CardTitle>
            <CardDescription>
              {!workingDay && (
                <Alert className="mt-2">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>Today is not a working day according to your schedule</AlertDescription>
                </Alert>
              )}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {todayAttendance ? (
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <Badge variant="default" className="text-lg py-2 px-4">
                    {todayAttendance.status.toUpperCase()}
                  </Badge>
                  {todayAttendance.checkIn && (
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-5 w-5 text-green-600" />
                      <span>Check-in: {todayAttendance.checkIn}</span>
                    </div>
                  )}
                  {todayAttendance.checkOut && (
                    <div className="flex items-center gap-2">
                      <XCircle className="h-5 w-5 text-red-600" />
                      <span>Check-out: {todayAttendance.checkOut}</span>
                    </div>
                  )}
                </div>
                
                {todayAttendance.status === 'present' && !todayAttendance.checkOut && (
                  <Button onClick={handleCheckOut}>
                    <Clock className="h-4 w-4 mr-2" />
                    Check Out
                  </Button>
                )}
              </div>
            ) : (
              <div className="flex gap-4">
                <Button onClick={handleCheckIn}>
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Check In (Present)
                </Button>
                <Button variant="outline" onClick={handleMarkAbsent}>
                  <XCircle className="h-4 w-4 mr-2" />
                  Mark Absent
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Main Tabs */}
        <Tabs defaultValue="products" className="space-y-6">
          <TabsList>
            <TabsTrigger value="products">
              <Package className="h-4 w-4 mr-2" />
              Product Management
            </TabsTrigger>
            <TabsTrigger value="attendance">
              <Calendar className="h-4 w-4 mr-2" />
              Attendance History
            </TabsTrigger>
          </TabsList>

          {/* Products Tab */}
          <TabsContent value="products" className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h2>My Products</h2>
                <p className="text-muted-foreground">Manage your product listings</p>
              </div>
              <Dialog open={isAddProductOpen} onOpenChange={setIsAddProductOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Product
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Add New Product</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="productName">Product Name *</Label>
                        <Input
                          id="productName"
                          value={productForm.name}
                          onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
                          placeholder="e.g., Wireless Headphones"
                        />
                      </div>
                      <div>
                        <Label htmlFor="brand">Brand</Label>
                        <Input
                          id="brand"
                          value={productForm.brand}
                          onChange={(e) => setProductForm({ ...productForm, brand: e.target.value })}
                          placeholder="e.g., Sony"
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        value={productForm.description}
                        onChange={(e) => setProductForm({ ...productForm, description: e.target.value })}
                        placeholder="Product description..."
                        rows={3}
                      />
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <Label htmlFor="price">Price (₹) *</Label>
                        <Input
                          id="price"
                          type="number"
                          value={productForm.price}
                          onChange={(e) => setProductForm({ ...productForm, price: e.target.value })}
                          placeholder="999"
                        />
                      </div>
                      <div>
                        <Label htmlFor="originalPrice">Original Price (₹)</Label>
                        <Input
                          id="originalPrice"
                          type="number"
                          value={productForm.originalPrice}
                          onChange={(e) => setProductForm({ ...productForm, originalPrice: e.target.value })}
                          placeholder="1499"
                        />
                      </div>
                      <div>
                        <Label htmlFor="stock">Stock Quantity</Label>
                        <Input
                          id="stock"
                          type="number"
                          value={productForm.stock}
                          onChange={(e) => setProductForm({ ...productForm, stock: e.target.value })}
                          placeholder="100"
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="category">Category *</Label>
                      <Select
                        value={productForm.category}
                        onValueChange={(value) => setProductForm({ ...productForm, category: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Electronics">Electronics</SelectItem>
                          <SelectItem value="Fashion">Fashion</SelectItem>
                          <SelectItem value="Home & Kitchen">Home & Kitchen</SelectItem>
                          <SelectItem value="Books">Books</SelectItem>
                          <SelectItem value="Sports">Sports</SelectItem>
                          <SelectItem value="Beauty">Beauty</SelectItem>
                          <SelectItem value="Toys">Toys</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="image">Image URL</Label>
                      <Input
                        id="image"
                        value={productForm.image}
                        onChange={(e) => setProductForm({ ...productForm, image: e.target.value })}
                        placeholder="https://example.com/image.jpg"
                      />
                    </div>

                    <Button onClick={handleAddProduct} className="w-full">
                      Add Product
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Product</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead>Stock</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {myProducts.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8">
                          No products found. Add your first product!
                        </TableCell>
                      </TableRow>
                    ) : (
                      myProducts.map((product) => (
                        <TableRow key={product.id}>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <img
                                src={product.image}
                                alt={product.name}
                                className="w-12 h-12 object-cover rounded"
                              />
                              <div>
                                <p>{product.name}</p>
                                <p className="text-sm text-muted-foreground">{product.brand}</p>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>{product.category}</TableCell>
                          <TableCell>₹{product.price.toLocaleString('en-IN')}</TableCell>
                          <TableCell>{product.stock || 0}</TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteProduct(product.id)}
                            >
                              <Trash2 className="h-4 w-4 text-red-600" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Attendance History Tab */}
          <TabsContent value="attendance" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Attendance History</CardTitle>
                <div className="flex gap-4 mt-4">
                  <Select
                    value={selectedMonth.toString()}
                    onValueChange={(value) => setSelectedMonth(parseInt(value))}
                  >
                    <SelectTrigger className="w-[180px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {monthNames.map((month, index) => (
                        <SelectItem key={index} value={index.toString()}>
                          {month}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select
                    value={selectedYear.toString()}
                    onValueChange={(value) => setSelectedYear(parseInt(value))}
                  >
                    <SelectTrigger className="w-[180px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[2024, 2025, 2026].map((year) => (
                        <SelectItem key={year} value={year.toString()}>
                          {year}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>
              <CardContent>
                {/* Stats */}
                <div className="grid grid-cols-4 gap-4 mb-6">
                  <Card>
                    <CardContent className="pt-6">
                      <p className="text-sm text-muted-foreground">Present</p>
                      <p className="text-2xl">{stats.present}</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <p className="text-sm text-muted-foreground">Absent</p>
                      <p className="text-2xl">{stats.absent}</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <p className="text-sm text-muted-foreground">Half-Day</p>
                      <p className="text-2xl">{stats.halfDay}</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <p className="text-sm text-muted-foreground">Leave</p>
                      <p className="text-2xl">{stats.leave}</p>
                    </CardContent>
                  </Card>
                </div>

                {/* Salary Calculation */}
                <Card className="mb-6 bg-primary/5">
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-sm text-muted-foreground">Calculated Salary for {monthNames[selectedMonth]} {selectedYear}</p>
                        <p className="text-3xl mt-2">₹{monthlySalary.toLocaleString('en-IN')}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-muted-foreground">Working Days</p>
                        <p className="text-2xl mt-2">{stats.present + stats.halfDay * 0.5}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Attendance Table */}
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Check-in</TableHead>
                      <TableHead>Check-out</TableHead>
                      <TableHead>Remarks</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {monthlyAttendance.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8">
                          No attendance records for this month
                        </TableCell>
                      </TableRow>
                    ) : (
                      monthlyAttendance.map((att) => (
                        <TableRow key={att.id}>
                          <TableCell>{new Date(att.date).toLocaleDateString()}</TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                att.status === 'present'
                                  ? 'default'
                                  : att.status === 'absent'
                                  ? 'destructive'
                                  : 'secondary'
                              }
                            >
                              {att.status}
                            </Badge>
                          </TableCell>
                          <TableCell>{att.checkIn || '-'}</TableCell>
                          <TableCell>{att.checkOut || '-'}</TableCell>
                          <TableCell>{att.remarks || '-'}</TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};