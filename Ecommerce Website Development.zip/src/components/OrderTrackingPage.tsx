import React, { useState } from 'react';
import { Package, Truck, CheckCircle2, XCircle, Clock, ArrowLeft, Search } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { useOrders } from '../context/OrderContext';
import { useAuth } from '../context/AuthContext';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface OrderTrackingPageProps {
  onPageChange: (page: string) => void;
}

export const OrderTrackingPage: React.FC<OrderTrackingPageProps> = ({ onPageChange }) => {
  const { orders, getOrderById, getUserOrders } = useOrders();
  const { user } = useAuth();
  const [trackingId, setTrackingId] = useState('');
  const [searchedOrder, setSearchedOrder] = useState<any>(null);

  const userOrders = user ? getUserOrders(user.id) : [];

  const handleTrackOrder = () => {
    const order = getOrderById(trackingId);
    setSearchedOrder(order || null);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-6 h-6 text-yellow-600" />;
      case 'confirmed':
        return <Package className="w-6 h-6 text-blue-600" />;
      case 'shipped':
        return <Truck className="w-6 h-6 text-purple-600" />;
      case 'delivered':
        return <CheckCircle2 className="w-6 h-6 text-green-600" />;
      case 'cancelled':
        return <XCircle className="w-6 h-6 text-red-600" />;
      default:
        return <Package className="w-6 h-6 text-gray-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-500';
      case 'confirmed': return 'bg-blue-500';
      case 'shipped': return 'bg-purple-500';
      case 'delivered': return 'bg-green-500';
      case 'cancelled': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const renderOrderTimeline = (order: any) => {
    const statuses = ['pending', 'confirmed', 'shipped', 'delivered'];
    const currentIndex = statuses.indexOf(order.status);

    return (
      <div className="relative">
        {statuses.map((status, index) => {
          const isCompleted = index <= currentIndex;
          const isCurrent = index === currentIndex;

          return (
            <div key={status} className="flex items-start mb-8 last:mb-0">
              <div className="flex flex-col items-center mr-4">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    isCompleted
                      ? getStatusColor(status)
                      : 'bg-gray-200'
                  } text-white`}
                >
                  {getStatusIcon(status)}
                </div>
                {index < statuses.length - 1 && (
                  <div
                    className={`w-1 h-16 ${
                      isCompleted ? getStatusColor(status) : 'bg-gray-200'
                    }`}
                  />
                )}
              </div>
              <div className="flex-1 pb-8">
                <h3 className={`capitalize mb-1 ${isCurrent ? '' : 'text-gray-600'}`}>
                  {status}
                </h3>
                <p className="text-sm text-gray-600">
                  {isCompleted
                    ? index === 0
                      ? new Date(order.createdAt).toLocaleString()
                      : 'Processing...'
                    : 'Pending...'}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <Button
            variant="ghost"
            onClick={() => onPageChange('home')}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Button>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl mb-8">Track Your Order</h1>

        {/* Search Section */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <h2 className="text-xl mb-4">Track by Order ID</h2>
            <div className="flex gap-2">
              <Input
                placeholder="Enter Order ID (e.g., ORD123456)"
                value={trackingId}
                onChange={(e) => setTrackingId(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleTrackOrder()}
              />
              <Button onClick={handleTrackOrder}>
                <Search className="w-4 h-4 mr-2" />
                Track
              </Button>
            </div>

            {searchedOrder === null && trackingId && (
              <div className="mt-4 p-4 bg-red-50 text-red-700 rounded-lg">
                Order not found. Please check your Order ID and try again.
              </div>
            )}
          </CardContent>
        </Card>

        {/* Searched Order Result */}
        {searchedOrder && (
          <Card className="mb-8">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Order #{searchedOrder.orderId}</CardTitle>
                <Badge className={getStatusColor(searchedOrder.status)}>
                  {searchedOrder.status.toUpperCase()}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <h3 className="mb-4">Order Timeline</h3>
                  {renderOrderTimeline(searchedOrder)}
                </div>

                <div className="space-y-6">
                  <div>
                    <h3 className="mb-2">Order Details</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Order Date:</span>
                        <span>{new Date(searchedOrder.createdAt).toLocaleDateString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Total Amount:</span>
                        <span>₹{searchedOrder.total.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Payment Method:</span>
                        <span className="capitalize">{searchedOrder.paymentMethod || 'N/A'}</span>
                      </div>
                      {searchedOrder.trackingNumber && (
                        <div className="flex justify-between">
                          <span className="text-gray-600">Tracking Number:</span>
                          <span className="font-mono">{searchedOrder.trackingNumber}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <Separator />

                  <div>
                    <h3 className="mb-2">Shipping Address</h3>
                    <div className="text-sm">
                      <p>{searchedOrder.address.name}</p>
                      <p>{searchedOrder.address.addressLine1}</p>
                      {searchedOrder.address.addressLine2 && (
                        <p>{searchedOrder.address.addressLine2}</p>
                      )}
                      <p>
                        {searchedOrder.address.city}, {searchedOrder.address.state}{' '}
                        {searchedOrder.address.pincode}
                      </p>
                      <p>{searchedOrder.address.phone}</p>
                    </div>
                  </div>

                  <Separator />

                  <div>
                    <h3 className="mb-2">Items ({searchedOrder.items.length})</h3>
                    <div className="space-y-2">
                      {searchedOrder.items.map((item: any, idx: number) => (
                        <div key={idx} className="flex gap-3 p-2 bg-gray-50 rounded">
                          <ImageWithFallback
                            src={item.product.image}
                            alt={item.product.name}
                            className="w-12 h-12 object-cover rounded"
                          />
                          <div className="flex-1 text-sm">
                            <p>{item.product.name}</p>
                            <p className="text-gray-600">Qty: {item.quantity}</p>
                          </div>
                          <p className="text-sm">₹{(item.product.price * item.quantity).toFixed(2)}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* User's Orders */}
        {user && userOrders.length > 0 && (
          <div>
            <h2 className="text-2xl mb-4">Your Orders</h2>
            <div className="space-y-4">
              {userOrders.map((order) => (
                <Card key={order.id}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="mb-1">Order #{order.orderId}</h3>
                        <p className="text-sm text-gray-600">
                          Placed on {new Date(order.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                      <Badge className={getStatusColor(order.status)}>
                        {order.status.toUpperCase()}
                      </Badge>
                    </div>

                    <Separator className="my-4" />

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="text-sm mb-2">Items</h4>
                        <div className="space-y-2">
                          {order.items.slice(0, 2).map((item, idx) => (
                            <div key={idx} className="flex gap-2 items-center">
                              <ImageWithFallback
                                src={item.product.image}
                                alt={item.product.name}
                                className="w-10 h-10 object-cover rounded"
                              />
                              <div className="text-sm flex-1">
                                <p className="line-clamp-1">{item.product.name}</p>
                                <p className="text-gray-600">Qty: {item.quantity}</p>
                              </div>
                            </div>
                          ))}
                          {order.items.length > 2 && (
                            <p className="text-sm text-gray-600">
                              +{order.items.length - 2} more items
                            </p>
                          )}
                        </div>
                      </div>

                      <div className="flex flex-col justify-between">
                        <div>
                          <h4 className="text-sm mb-1">Total Amount</h4>
                          <p className="text-xl">₹{order.total.toFixed(2)}</p>
                        </div>
                        <Button
                          onClick={() => {
                            setTrackingId(order.orderId);
                            setSearchedOrder(order);
                            window.scrollTo({ top: 0, behavior: 'smooth' });
                          }}
                          variant="outline"
                          className="mt-4"
                        >
                          View Details
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {user && userOrders.length === 0 && !searchedOrder && (
          <Card>
            <CardContent className="p-12 text-center">
              <Package className="w-16 h-16 mx-auto text-gray-400 mb-4" />
              <h3 className="text-xl mb-2">No Orders Yet</h3>
              <p className="text-gray-600 mb-6">You haven't placed any orders yet.</p>
              <Button onClick={() => onPageChange('products')}>
                Start Shopping
              </Button>
            </CardContent>
          </Card>
        )}

        {!user && (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-600 mb-4">
                Login to view your order history
              </p>
              <Button onClick={() => onPageChange('login')}>
                Login
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};
