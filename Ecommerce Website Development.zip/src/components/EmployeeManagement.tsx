import React, { useState } from 'react';
import { useEmployee } from '../context/EmployeeContext';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Calendar } from './ui/calendar';
import { toast } from 'sonner';
import { UserPlus, Edit, Trash2, Check, X, Users, IndianRupee, Calendar as CalendarIcon } from 'lucide-react';

export const EmployeeManagement: React.FC = () => {
  const {
    employees,
    attendance,
    addEmployee,
    updateEmployee,
    deleteEmployee,
    markAttendance,
    getEmployeeAttendance,
    getMonthlyAttendanceStats,
    calculateMonthlySalary,
  } = useEmployee();

  const [isAddEmployeeOpen, setIsAddEmployeeOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<string | null>(null);
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());

  const [employeeForm, setEmployeeForm] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',
    designation: '',
    department: '',
    joiningDate: new Date().toISOString().split('T')[0],
    salary: '',
    status: 'active' as 'active' | 'inactive',
    approved: true,
    address: '',
    emergencyContactName: '',
    emergencyContactPhone: '',
    emergencyContactRelation: '',
    checkInTime: '09:00',
    checkOutTime: '18:00',
    workingDays: [1, 2, 3, 4, 5] as number[], // Monday to Friday
  });

  const handleAddEmployee = async () => {
    if (!employeeForm.name || !employeeForm.email || !employeeForm.phone || !employeeForm.designation || !employeeForm.salary || !employeeForm.password) {
      toast.error('Please fill all required fields');
      return;
    }

    try {
      await addEmployee({
        name: employeeForm.name,
        email: employeeForm.email,
        password: employeeForm.password,
        phone: employeeForm.phone,
        designation: employeeForm.designation,
        department: employeeForm.department,
        joiningDate: new Date(employeeForm.joiningDate),
        salary: parseFloat(employeeForm.salary),
        status: employeeForm.status,
        approved: employeeForm.approved,
        address: employeeForm.address,
        emergencyContact: {
          name: employeeForm.emergencyContactName,
          phone: employeeForm.emergencyContactPhone,
          relation: employeeForm.emergencyContactRelation,
        },
        schedule: {
          checkInTime: employeeForm.checkInTime,
          checkOutTime: employeeForm.checkOutTime,
          workingDays: employeeForm.workingDays,
        },
      });

      toast.success('Employee added successfully!');
      setIsAddEmployeeOpen(false);
      resetForm();
    } catch (error: any) {
      toast.error(error.message || 'Failed to add employee');
    }
  };

  const handleMarkAttendance = (employeeId: string, status: 'present' | 'absent' | 'half-day' | 'leave') => {
    const now = new Date();
    const checkIn = status === 'present' || status === 'half-day' ? now.toLocaleTimeString() : undefined;

    markAttendance(employeeId, status, checkIn);
    toast.success(`Attendance marked as ${status}`);
  };

  const handleDeleteEmployee = (id: string) => {
    if (confirm('Are you sure you want to delete this employee?')) {
      deleteEmployee(id);
      toast.success('Employee deleted successfully!');
    }
  };

  const resetForm = () => {
    setEmployeeForm({
      name: '',
      email: '',
      password: '',
      phone: '',
      designation: '',
      department: '',
      joiningDate: new Date().toISOString().split('T')[0],
      salary: '',
      status: 'active',
      approved: true,
      address: '',
      emergencyContactName: '',
      emergencyContactPhone: '',
      emergencyContactRelation: '',
      checkInTime: '09:00',
      checkOutTime: '18:00',
      workingDays: [1, 2, 3, 4, 5] as number[], // Monday to Friday
    });
  };

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2>Employee Management</h2>
          <p className="text-muted-foreground">Manage employees, attendance, and payroll</p>
        </div>
        <Dialog open={isAddEmployeeOpen} onOpenChange={setIsAddEmployeeOpen}>
          <DialogTrigger asChild>
            <Button>
              <UserPlus className="h-4 w-4 mr-2" />
              Add Employee
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Employee</DialogTitle>
              <DialogDescription>Enter the employee details below</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Full Name *</Label>
                  <Input
                    id="name"
                    value={employeeForm.name}
                    onChange={(e) => setEmployeeForm({ ...employeeForm, name: e.target.value })}
                    placeholder="John Doe"
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={employeeForm.email}
                    onChange={(e) => setEmployeeForm({ ...employeeForm, email: e.target.value })}
                    placeholder="john@example.com"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="phone">Phone *</Label>
                  <Input
                    id="phone"
                    value={employeeForm.phone}
                    onChange={(e) => setEmployeeForm({ ...employeeForm, phone: e.target.value })}
                    placeholder="+91 9876543210"
                  />
                </div>
                <div>
                  <Label htmlFor="password">Password *</Label>
                  <Input
                    id="password"
                    type="password"
                    value={employeeForm.password}
                    onChange={(e) => setEmployeeForm({ ...employeeForm, password: e.target.value })}
                    placeholder="••••••••"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="designation">Designation *</Label>
                  <Input
                    id="designation"
                    value={employeeForm.designation}
                    onChange={(e) => setEmployeeForm({ ...employeeForm, designation: e.target.value })}
                    placeholder="Software Engineer"
                  />
                </div>
                <div>
                  <Label htmlFor="approved">Approval Status</Label>
                  <Select
                    value={employeeForm.approved ? 'approved' : 'pending'}
                    onValueChange={(value) => setEmployeeForm({ ...employeeForm, approved: value === 'approved' })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="approved">Approved (Can Login)</SelectItem>
                      <SelectItem value="pending">Pending (Cannot Login)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="department">Department</Label>
                  <Select
                    value={employeeForm.department}
                    onValueChange={(value) => setEmployeeForm({ ...employeeForm, department: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select department" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="IT">IT</SelectItem>
                      <SelectItem value="Sales">Sales</SelectItem>
                      <SelectItem value="Marketing">Marketing</SelectItem>
                      <SelectItem value="HR">HR</SelectItem>
                      <SelectItem value="Finance">Finance</SelectItem>
                      <SelectItem value="Operations">Operations</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="joiningDate">Joining Date</Label>
                  <Input
                    id="joiningDate"
                    type="date"
                    value={employeeForm.joiningDate}
                    onChange={(e) => setEmployeeForm({ ...employeeForm, joiningDate: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="salary">Monthly Salary (₹) *</Label>
                  <Input
                    id="salary"
                    type="number"
                    value={employeeForm.salary}
                    onChange={(e) => setEmployeeForm({ ...employeeForm, salary: e.target.value })}
                    placeholder="50000"
                  />
                </div>
                <div>
                  <Label htmlFor="status">Status</Label>
                  <Select
                    value={employeeForm.status}
                    onValueChange={(value: 'active' | 'inactive') => setEmployeeForm({ ...employeeForm, status: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="inactive">Inactive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="address">Address</Label>
                <Input
                  id="address"
                  value={employeeForm.address}
                  onChange={(e) => setEmployeeForm({ ...employeeForm, address: e.target.value })}
                  placeholder="Street, City, State, PIN"
                />
              </div>

              <div className="border-t pt-4">
                <h3 className="mb-4">Emergency Contact</h3>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="emergencyContactName">Name</Label>
                    <Input
                      id="emergencyContactName"
                      value={employeeForm.emergencyContactName}
                      onChange={(e) => setEmployeeForm({ ...employeeForm, emergencyContactName: e.target.value })}
                      placeholder="Jane Doe"
                    />
                  </div>
                  <div>
                    <Label htmlFor="emergencyContactPhone">Phone</Label>
                    <Input
                      id="emergencyContactPhone"
                      value={employeeForm.emergencyContactPhone}
                      onChange={(e) => setEmployeeForm({ ...employeeForm, emergencyContactPhone: e.target.value })}
                      placeholder="+91 9876543210"
                    />
                  </div>
                  <div>
                    <Label htmlFor="emergencyContactRelation">Relation</Label>
                    <Input
                      id="emergencyContactRelation"
                      value={employeeForm.emergencyContactRelation}
                      onChange={(e) => setEmployeeForm({ ...employeeForm, emergencyContactRelation: e.target.value })}
                      placeholder="Spouse"
                    />
                  </div>
                </div>
              </div>

              <div className="border-t pt-4">
                <h3 className="mb-4">Schedule</h3>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="checkInTime">Check-In Time</Label>
                    <Input
                      id="checkInTime"
                      value={employeeForm.checkInTime}
                      onChange={(e) => setEmployeeForm({ ...employeeForm, checkInTime: e.target.value })}
                      placeholder="09:00"
                    />
                  </div>
                  <div>
                    <Label htmlFor="checkOutTime">Check-Out Time</Label>
                    <Input
                      id="checkOutTime"
                      value={employeeForm.checkOutTime}
                      onChange={(e) => setEmployeeForm({ ...employeeForm, checkOutTime: e.target.value })}
                      placeholder="18:00"
                    />
                  </div>
                  <div>
                    <Label htmlFor="workingDays">Working Days</Label>
                    <Select
                      value={employeeForm.workingDays.map(day => day.toString()).join(',')}
                      onValueChange={(value) => setEmployeeForm({ ...employeeForm, workingDays: value.split(',').map(Number) })}
                      multiple
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select working days" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">Monday</SelectItem>
                        <SelectItem value="2">Tuesday</SelectItem>
                        <SelectItem value="3">Wednesday</SelectItem>
                        <SelectItem value="4">Thursday</SelectItem>
                        <SelectItem value="5">Friday</SelectItem>
                        <SelectItem value="6">Saturday</SelectItem>
                        <SelectItem value="0">Sunday</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <Button onClick={handleAddEmployee} className="w-full">
                Add Employee
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="employees" className="space-y-6">
        <TabsList>
          <TabsTrigger value="employees">
            <Users className="h-4 w-4 mr-2" />
            Employees
          </TabsTrigger>
          <TabsTrigger value="attendance">
            <CalendarIcon className="h-4 w-4 mr-2" />
            Attendance
          </TabsTrigger>
          <TabsTrigger value="payroll">
            <IndianRupee className="h-4 w-4 mr-2" />
            Payroll
          </TabsTrigger>
        </TabsList>

        <TabsContent value="employees" className="space-y-4">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Designation</TableHead>
                    <TableHead>Department</TableHead>
                    <TableHead>Phone</TableHead>
                    <TableHead>Salary</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {employees.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-8">
                        No employees found. Add your first employee!
                      </TableCell>
                    </TableRow>
                  ) : (
                    employees.map((employee) => (
                      <TableRow key={employee.id}>
                        <TableCell>{employee.name}</TableCell>
                        <TableCell>{employee.designation}</TableCell>
                        <TableCell>{employee.department}</TableCell>
                        <TableCell>{employee.phone}</TableCell>
                        <TableCell>₹{employee.salary.toLocaleString('en-IN')}</TableCell>
                        <TableCell>
                          <Badge variant={employee.status === 'active' ? 'default' : 'secondary'}>
                            {employee.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteEmployee(employee.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="attendance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Mark Today's Attendance</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Employee</TableHead>
                    <TableHead>Designation</TableHead>
                    <TableHead>Mark Attendance</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {employees.filter(emp => emp.status === 'active').map((employee) => {
                    const todayAttendance = attendance.find(
                      (att) =>
                        att.employeeId === employee.id &&
                        new Date(att.date).toDateString() === new Date().toDateString()
                    );

                    return (
                      <TableRow key={employee.id}>
                        <TableCell>{employee.name}</TableCell>
                        <TableCell>{employee.designation}</TableCell>
                        <TableCell>
                          {todayAttendance ? (
                            <Badge variant="default">{todayAttendance.status}</Badge>
                          ) : (
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleMarkAttendance(employee.id, 'present')}
                              >
                                <Check className="h-4 w-4 mr-1" />
                                Present
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleMarkAttendance(employee.id, 'absent')}
                              >
                                <X className="h-4 w-4 mr-1" />
                                Absent
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleMarkAttendance(employee.id, 'half-day')}
                              >
                                Half-Day
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleMarkAttendance(employee.id, 'leave')}
                              >
                                Leave
                              </Button>
                            </div>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payroll" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Monthly Payroll</CardTitle>
              <div className="flex gap-4 mt-4">
                <Select
                  value={selectedMonth.toString()}
                  onValueChange={(value) => setSelectedMonth(parseInt(value))}
                >
                  <SelectTrigger className="w-[180px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {monthNames.map((month, index) => (
                      <SelectItem key={index} value={index.toString()}>
                        {month}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select
                  value={selectedYear.toString()}
                  onValueChange={(value) => setSelectedYear(parseInt(value))}
                >
                  <SelectTrigger className="w-[180px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {[2024, 2025, 2026].map((year) => (
                      <SelectItem key={year} value={year.toString()}>
                        {year}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Employee</TableHead>
                    <TableHead>Designation</TableHead>
                    <TableHead>Present Days</TableHead>
                    <TableHead>Absent Days</TableHead>
                    <TableHead>Base Salary</TableHead>
                    <TableHead>Payable Amount</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {employees.filter(emp => emp.status === 'active').map((employee) => {
                    const stats = getMonthlyAttendanceStats(employee.id, selectedMonth, selectedYear);
                    const payableSalary = calculateMonthlySalary(employee.id, selectedMonth, selectedYear);

                    return (
                      <TableRow key={employee.id}>
                        <TableCell>{employee.name}</TableCell>
                        <TableCell>{employee.designation}</TableCell>
                        <TableCell>{stats.present + stats.halfDay * 0.5}</TableCell>
                        <TableCell>{stats.absent}</TableCell>
                        <TableCell>₹{employee.salary.toLocaleString('en-IN')}</TableCell>
                        <TableCell className="font-semibold">
                          ₹{payableSalary.toLocaleString('en-IN')}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};