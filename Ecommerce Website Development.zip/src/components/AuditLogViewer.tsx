/**
 * Audit Log Viewer Component
 * Displays comprehensive audit logs of all system actions
 */

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { ScrollArea } from './ui/scroll-area';
import { 
  Search, 
  Filter, 
  Download, 
  RefreshCw, 
  Calendar,
  User,
  Activity,
  AlertCircle,
  CheckCircle,
  XCircle,
  Eye,
  TrendingUp,
} from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';
import { toast } from 'sonner@2.0.3';

interface AuditLog {
  id: string;
  timestamp: string;
  userId: string | null;
  userEmail: string | null;
  userRole: string | null;
  action: string;
  entityType: string;
  entityId: string | null;
  entityName: string | null;
  details: Record<string, any>;
  ipAddress: string | null;
  userAgent: string | null;
  success: boolean;
  errorMessage?: string;
}

interface AuditStats {
  totalLogs: number;
  logsByAction: Record<string, number>;
  logsByEntity: Record<string, number>;
  logsByUser: Record<string, number>;
  failedActions: number;
  recentActivity: AuditLog[];
}

export function AuditLogViewer() {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [stats, setStats] = useState<AuditStats | null>(null);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterAction, setFilterAction] = useState('all');
  const [filterEntity, setFilterEntity] = useState('all');
  const [filterUser, setFilterUser] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedLog, setSelectedLog] = useState<AuditLog | null>(null);
  const [activeTab, setActiveTab] = useState('all');

  const API_URL = `https://${projectId}.supabase.co/functions/v1/make-server-6d108759`;

  useEffect(() => {
    loadAuditLogs();
    loadAuditStats();
  }, []);

  const loadAuditLogs = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${API_URL}/audit/logs?limit=500`, {
        headers: {
          Authorization: `Bearer ${publicAnonKey}`,
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch audit logs');
      }

      const data = await response.json();
      if (data.success) {
        setLogs(data.data);
      }
    } catch (error) {
      console.error('Error loading audit logs:', error);
      toast.error('Failed to load audit logs');
    } finally {
      setLoading(false);
    }
  };

  const loadAuditStats = async () => {
    try {
      const response = await fetch(`${API_URL}/audit/stats`, {
        headers: {
          Authorization: `Bearer ${publicAnonKey}`,
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch audit stats');
      }

      const data = await response.json();
      if (data.success) {
        setStats(data.data);
      }
    } catch (error) {
      console.error('Error loading audit stats:', error);
    }
  };

  const loadLogsByDateRange = async () => {
    if (!startDate || !endDate) {
      toast.error('Please select both start and end dates');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(
        `${API_URL}/audit/logs/date-range?startDate=${startDate}&endDate=${endDate}&limit=500`,
        {
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch audit logs');
      }

      const data = await response.json();
      if (data.success) {
        setLogs(data.data);
        toast.success(`Found ${data.count} logs in date range`);
      }
    } catch (error) {
      console.error('Error loading logs by date range:', error);
      toast.error('Failed to load logs by date range');
    } finally {
      setLoading(false);
    }
  };

  const loadLogsByUser = async (userId: string) => {
    setLoading(true);
    try {
      const response = await fetch(`${API_URL}/audit/logs/user/${userId}?limit=200`, {
        headers: {
          Authorization: `Bearer ${publicAnonKey}`,
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch user audit logs');
      }

      const data = await response.json();
      if (data.success) {
        setLogs(data.data);
        toast.success(`Found ${data.count} logs for user`);
      }
    } catch (error) {
      console.error('Error loading user logs:', error);
      toast.error('Failed to load user logs');
    } finally {
      setLoading(false);
    }
  };

  const exportLogs = () => {
    const filteredLogs = getFilteredLogs();
    const csv = convertToCSV(filteredLogs);
    downloadCSV(csv, `audit-logs-${new Date().toISOString()}.csv`);
    toast.success('Audit logs exported successfully');
  };

  const convertToCSV = (data: AuditLog[]): string => {
    const headers = [
      'Timestamp',
      'Action',
      'Entity Type',
      'Entity Name',
      'User Email',
      'User Role',
      'Success',
      'IP Address',
      'Details',
    ];

    const rows = data.map(log => [
      log.timestamp,
      log.action,
      log.entityType,
      log.entityName || '',
      log.userEmail || '',
      log.userRole || '',
      log.success ? 'Yes' : 'No',
      log.ipAddress || '',
      JSON.stringify(log.details),
    ]);

    return [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(',')),
    ].join('\n');
  };

  const downloadCSV = (csv: string, filename: string) => {
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  const getFilteredLogs = () => {
    return logs.filter(log => {
      // Search term filter
      if (searchTerm) {
        const searchLower = searchTerm.toLowerCase();
        const matchesSearch =
          log.action.toLowerCase().includes(searchLower) ||
          log.entityType.toLowerCase().includes(searchLower) ||
          (log.entityName && log.entityName.toLowerCase().includes(searchLower)) ||
          (log.userEmail && log.userEmail.toLowerCase().includes(searchLower));
        
        if (!matchesSearch) return false;
      }

      // Action filter
      if (filterAction !== 'all' && log.action !== filterAction) {
        return false;
      }

      // Entity filter
      if (filterEntity !== 'all' && log.entityType !== filterEntity) {
        return false;
      }

      // User filter
      if (filterUser && log.userEmail !== filterUser) {
        return false;
      }

      // Tab filter
      if (activeTab === 'failed' && log.success) {
        return false;
      }

      return true;
    });
  };

  const getActionBadgeColor = (action: string) => {
    if (action.includes('CREATE') || action.includes('ADD')) return 'bg-green-500';
    if (action.includes('UPDATE')) return 'bg-blue-500';
    if (action.includes('DELETE') || action.includes('REMOVE')) return 'bg-red-500';
    if (action.includes('LOGIN')) return 'bg-purple-500';
    if (action.includes('APPROVE')) return 'bg-emerald-500';
    if (action.includes('REJECT')) return 'bg-orange-500';
    return 'bg-gray-500';
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    }).format(date);
  };

  const filteredLogs = getFilteredLogs();
  const uniqueActions = Array.from(new Set(logs.map(log => log.action)));
  const uniqueEntities = Array.from(new Set(logs.map(log => log.entityType)));
  const uniqueUsers = Array.from(new Set(logs.map(log => log.userEmail).filter(Boolean)));

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl">Audit Logs</h2>
          <p className="text-muted-foreground">
            Complete activity history and system audit trail
          </p>
        </div>
        <div className="flex gap-2">
          <Button onClick={loadAuditLogs} variant="outline" disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Button onClick={exportLogs} variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export CSV
          </Button>
        </div>
      </div>

      {/* Statistics Cards */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Total Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl">{stats.totalLogs}</div>
              <p className="text-xs text-muted-foreground">All logged activities</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Failed Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl text-red-500">{stats.failedActions}</div>
              <p className="text-xs text-muted-foreground">Errors encountered</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Active Users</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl">{Object.keys(stats.logsByUser).length}</div>
              <p className="text-xs text-muted-foreground">Unique users tracked</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Action Types</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl">{Object.keys(stats.logsByAction).length}</div>
              <p className="text-xs text-muted-foreground">Different actions logged</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filters
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label>Search</Label>
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search logs..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Action Type</Label>
              <Select value={filterAction} onValueChange={setFilterAction}>
                <SelectTrigger>
                  <SelectValue placeholder="All actions" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Actions</SelectItem>
                  {uniqueActions.map(action => (
                    <SelectItem key={action} value={action}>
                      {action}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Entity Type</Label>
              <Select value={filterEntity} onValueChange={setFilterEntity}>
                <SelectTrigger>
                  <SelectValue placeholder="All entities" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Entities</SelectItem>
                  {uniqueEntities.map(entity => (
                    <SelectItem key={entity} value={entity}>
                      {entity}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>User</Label>
              <Select value={filterUser} onValueChange={setFilterUser}>
                <SelectTrigger>
                  <SelectValue placeholder="All users" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Users</SelectItem>
                  {uniqueUsers.map(user => (
                    <SelectItem key={user} value={user || ''}>
                      {user}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Date Range Filter */}
          <div className="flex gap-4 items-end">
            <div className="space-y-2 flex-1">
              <Label>Start Date</Label>
              <Input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </div>
            <div className="space-y-2 flex-1">
              <Label>End Date</Label>
              <Input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>
            <Button onClick={loadLogsByDateRange} disabled={loading}>
              <Calendar className="h-4 w-4 mr-2" />
              Filter by Date
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Logs Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              Activity Logs
            </span>
            <Badge variant="secondary">{filteredLogs.length} logs</Badge>
          </CardTitle>
          <CardDescription>
            Showing {filteredLogs.length} of {logs.length} total logs
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList>
              <TabsTrigger value="all">All Logs</TabsTrigger>
              <TabsTrigger value="failed">Failed Actions</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="mt-4">
              <ScrollArea className="h-[600px]">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Timestamp</TableHead>
                      <TableHead>Action</TableHead>
                      <TableHead>Entity</TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Details</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredLogs.map((log) => (
                      <TableRow key={log.id}>
                        <TableCell className="whitespace-nowrap">
                          {formatTimestamp(log.timestamp)}
                        </TableCell>
                        <TableCell>
                          <Badge className={getActionBadgeColor(log.action)}>
                            {log.action}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div>
                            <div>{log.entityType}</div>
                            {log.entityName && (
                              <div className="text-xs text-muted-foreground">
                                {log.entityName}
                              </div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div>
                            <div>{log.userEmail || 'N/A'}</div>
                            {log.userRole && (
                              <Badge variant="outline" className="text-xs mt-1">
                                {log.userRole}
                              </Badge>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          {log.success ? (
                            <CheckCircle className="h-5 w-5 text-green-500" />
                          ) : (
                            <XCircle className="h-5 w-5 text-red-500" />
                          )}
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setSelectedLog(log)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="failed" className="mt-4">
              <ScrollArea className="h-[600px]">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Timestamp</TableHead>
                      <TableHead>Action</TableHead>
                      <TableHead>Entity</TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Error</TableHead>
                      <TableHead>Details</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredLogs.filter(log => !log.success).map((log) => (
                      <TableRow key={log.id}>
                        <TableCell className="whitespace-nowrap">
                          {formatTimestamp(log.timestamp)}
                        </TableCell>
                        <TableCell>
                          <Badge className="bg-red-500">{log.action}</Badge>
                        </TableCell>
                        <TableCell>
                          <div>
                            <div>{log.entityType}</div>
                            {log.entityName && (
                              <div className="text-xs text-muted-foreground">
                                {log.entityName}
                              </div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div>
                            <div>{log.userEmail || 'N/A'}</div>
                            {log.userRole && (
                              <Badge variant="outline" className="text-xs mt-1">
                                {log.userRole}
                              </Badge>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className="text-red-500 text-sm">
                            {log.errorMessage || 'Unknown error'}
                          </span>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setSelectedLog(log)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </ScrollArea>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Log Details Dialog */}
      {selectedLog && (
        <div
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          onClick={() => setSelectedLog(null)}
        >
          <Card
            className="max-w-2xl w-full max-h-[80vh] overflow-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Audit Log Details</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedLog(null)}
                >
                  ✕
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Timestamp</Label>
                  <div className="mt-1">{formatTimestamp(selectedLog.timestamp)}</div>
                </div>
                <div>
                  <Label>Status</Label>
                  <div className="mt-1">
                    {selectedLog.success ? (
                      <Badge className="bg-green-500">Success</Badge>
                    ) : (
                      <Badge className="bg-red-500">Failed</Badge>
                    )}
                  </div>
                </div>
                <div>
                  <Label>Action</Label>
                  <div className="mt-1">
                    <Badge className={getActionBadgeColor(selectedLog.action)}>
                      {selectedLog.action}
                    </Badge>
                  </div>
                </div>
                <div>
                  <Label>Entity Type</Label>
                  <div className="mt-1">{selectedLog.entityType}</div>
                </div>
                {selectedLog.entityName && (
                  <div>
                    <Label>Entity Name</Label>
                    <div className="mt-1">{selectedLog.entityName}</div>
                  </div>
                )}
                {selectedLog.entityId && (
                  <div>
                    <Label>Entity ID</Label>
                    <div className="mt-1 text-xs font-mono">{selectedLog.entityId}</div>
                  </div>
                )}
                <div>
                  <Label>User Email</Label>
                  <div className="mt-1">{selectedLog.userEmail || 'N/A'}</div>
                </div>
                {selectedLog.userRole && (
                  <div>
                    <Label>User Role</Label>
                    <div className="mt-1">
                      <Badge variant="outline">{selectedLog.userRole}</Badge>
                    </div>
                  </div>
                )}
                {selectedLog.ipAddress && (
                  <div>
                    <Label>IP Address</Label>
                    <div className="mt-1 font-mono text-sm">{selectedLog.ipAddress}</div>
                  </div>
                )}
              </div>

              {selectedLog.errorMessage && (
                <div>
                  <Label>Error Message</Label>
                  <div className="mt-1 p-3 bg-red-50 border border-red-200 rounded text-red-700">
                    {selectedLog.errorMessage}
                  </div>
                </div>
              )}

              <div>
                <Label>Additional Details</Label>
                <pre className="mt-1 p-3 bg-gray-50 border rounded text-xs overflow-auto max-h-48">
                  {JSON.stringify(selectedLog.details, null, 2)}
                </pre>
              </div>

              {selectedLog.userAgent && (
                <div>
                  <Label>User Agent</Label>
                  <div className="mt-1 text-xs text-muted-foreground break-all">
                    {selectedLog.userAgent}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
