import React, { useState } from 'react';
import { ShoppingCart } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { useAuth } from '../context/AuthContext';
import { useSeller } from '../context/SellerContext';
import { useEmployee } from '../context/EmployeeContext';
import { toast } from 'sonner@2.0.3';

interface AuthPagesProps {
  onPageChange: (page: string) => void;
}

export const AuthPages: React.FC<AuthPagesProps> = ({ onPageChange }) => {
  const { login, signup } = useAuth();
  const { addSeller } = useSeller();
  const { employeeLogin } = useEmployee();
  const [isLoading, setIsLoading] = useState(false);

  const [loginForm, setLoginForm] = useState({
    email: '',
    password: '',
  });

  const [signupForm, setSignupForm] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
  });

  const [sellerForm, setSellerForm] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    businessName: '',
    phone: '',
    gst: '',
    address: '',
  });

  const [employeeLoginForm, setEmployeeLoginForm] = useState({
    email: '',
    password: '',
  });

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      await login(loginForm.email, loginForm.password);
      toast.success('Logged in successfully!');
      onPageChange('home');
    } catch (error) {
      toast.error('Login failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (signupForm.password !== signupForm.confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }
    setIsLoading(true);
    try {
      await signup(signupForm.name, signupForm.email, signupForm.password);
      toast.success('Account created successfully!');
      onPageChange('home');
    } catch (error) {
      toast.error('Signup failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSellerSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (sellerForm.password !== sellerForm.confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }
    if (!sellerForm.businessName || !sellerForm.phone || !sellerForm.address) {
      toast.error('Please fill all required fields');
      return;
    }
    setIsLoading(true);
    try {
      // Register seller
      addSeller({
        name: sellerForm.name,
        email: sellerForm.email,
        businessName: sellerForm.businessName,
        phone: sellerForm.phone,
        gst: sellerForm.gst,
        commission: 15, // Default 15% commission
        address: sellerForm.address,
        approved: false, // Needs admin approval
      });
      
      toast.success('Seller registration submitted! Please wait for admin approval.');
      onPageChange('home');
    } catch (error) {
      toast.error('Seller registration failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleEmployeeLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const success = await employeeLogin(employeeLoginForm.email, employeeLoginForm.password);
      if (success) {
        toast.success('Logged in successfully!');
        onPageChange('employee');
      } else {
        toast.error('Login failed. Please check your credentials and approval status.');
      }
    } catch (error) {
      toast.error('Login failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
              <ShoppingCart className="w-10 h-10 text-white" />
            </div>
          </div>
          <CardTitle className="text-2xl">Welcome to ShopHub</CardTitle>
          <CardDescription>Login or create an account to continue</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="login">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="login">Login</TabsTrigger>
              <TabsTrigger value="signup">Sign Up</TabsTrigger>
              <TabsTrigger value="seller">Seller</TabsTrigger>
              <TabsTrigger value="employee">Employee</TabsTrigger>
            </TabsList>

            <TabsContent value="login">
              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <Label htmlFor="login-email">Email</Label>
                  <Input
                    id="login-email"
                    type="email"
                    placeholder="your@email.com"
                    required
                    value={loginForm.email}
                    onChange={(e) =>
                      setLoginForm({ ...loginForm, email: e.target.value })
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="login-password">Password</Label>
                  <Input
                    id="login-password"
                    type="password"
                    placeholder="••••••••"
                    required
                    value={loginForm.password}
                    onChange={(e) =>
                      setLoginForm({ ...loginForm, password: e.target.value })
                    }
                  />
                </div>
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? 'Logging in...' : 'Login'}
                </Button>
                <div className="text-xs text-center text-gray-600 p-3 bg-blue-50 rounded-lg">
                  <p className="mb-1">Demo Credentials:</p>
                  <p>Admin: admin@shophub.com / admin123</p>
                  <p>Seller: test@seller.com / seller123</p>
                </div>
                <Button
                  type="button"
                  variant="ghost"
                  className="w-full"
                  onClick={() => onPageChange('home')}
                >
                  Continue as Guest
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="signup">
              <form onSubmit={handleSignup} className="space-y-4">
                <div>
                  <Label htmlFor="signup-name">Full Name</Label>
                  <Input
                    id="signup-name"
                    placeholder="John Doe"
                    required
                    value={signupForm.name}
                    onChange={(e) =>
                      setSignupForm({ ...signupForm, name: e.target.value })
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="signup-email">Email</Label>
                  <Input
                    id="signup-email"
                    type="email"
                    placeholder="your@email.com"
                    required
                    value={signupForm.email}
                    onChange={(e) =>
                      setSignupForm({ ...signupForm, email: e.target.value })
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="signup-password">Password</Label>
                  <Input
                    id="signup-password"
                    type="password"
                    placeholder="••••••••"
                    required
                    value={signupForm.password}
                    onChange={(e) =>
                      setSignupForm({ ...signupForm, password: e.target.value })
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="signup-confirm">Confirm Password</Label>
                  <Input
                    id="signup-confirm"
                    type="password"
                    placeholder="••••••••"
                    required
                    value={signupForm.confirmPassword}
                    onChange={(e) =>
                      setSignupForm({ ...signupForm, confirmPassword: e.target.value })
                    }
                  />
                </div>
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? 'Creating account...' : 'Create Account'}
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="seller">
              <form onSubmit={handleSellerSignup} className="space-y-4 max-h-[60vh] overflow-y-auto pr-2">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="seller-name">Contact Person *</Label>
                    <Input
                      id="seller-name"
                      placeholder="John Doe"
                      required
                      value={sellerForm.name}
                      onChange={(e) =>
                        setSellerForm({ ...sellerForm, name: e.target.value })
                      }
                    />
                  </div>
                  <div>
                    <Label htmlFor="seller-business">Business Name *</Label>
                    <Input
                      id="seller-business"
                      placeholder="My Shop"
                      required
                      value={sellerForm.businessName}
                      onChange={(e) =>
                        setSellerForm({ ...sellerForm, businessName: e.target.value })
                      }
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="seller-email">Email *</Label>
                  <Input
                    id="seller-email"
                    type="email"
                    placeholder="seller@example.com"
                    required
                    value={sellerForm.email}
                    onChange={(e) =>
                      setSellerForm({ ...sellerForm, email: e.target.value })
                    }
                  />
                </div>

                <div>
                  <Label htmlFor="seller-phone">Phone Number *</Label>
                  <Input
                    id="seller-phone"
                    type="tel"
                    placeholder="+91 9876543210"
                    required
                    value={sellerForm.phone}
                    onChange={(e) =>
                      setSellerForm({ ...sellerForm, phone: e.target.value })
                    }
                  />
                </div>

                <div>
                  <Label htmlFor="seller-gst">GST Number (Optional)</Label>
                  <Input
                    id="seller-gst"
                    placeholder="22AAAAA0000A1Z5"
                    value={sellerForm.gst}
                    onChange={(e) =>
                      setSellerForm({ ...sellerForm, gst: e.target.value })
                    }
                  />
                </div>

                <div>
                  <Label htmlFor="seller-address">Business Address *</Label>
                  <Textarea
                    id="seller-address"
                    placeholder="Street, City, State, PIN"
                    required
                    rows={3}
                    value={sellerForm.address}
                    onChange={(e) =>
                      setSellerForm({ ...sellerForm, address: e.target.value })
                    }
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="seller-password">Password *</Label>
                    <Input
                      id="seller-password"
                      type="password"
                      placeholder="••••••••"
                      required
                      value={sellerForm.password}
                      onChange={(e) =>
                        setSellerForm({ ...sellerForm, password: e.target.value })
                      }
                    />
                  </div>
                  <div>
                    <Label htmlFor="seller-confirm">Confirm Password *</Label>
                    <Input
                      id="seller-confirm"
                      type="password"
                      placeholder="••••••••"
                      required
                      value={sellerForm.confirmPassword}
                      onChange={(e) =>
                        setSellerForm({ ...sellerForm, confirmPassword: e.target.value })
                      }
                    />
                  </div>
                </div>

                <div className="text-xs text-gray-600 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                  <p>⚠️ Your seller account will be reviewed by our admin team. You'll receive an email notification once approved.</p>
                </div>

                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? 'Submitting...' : 'Register as Seller'}
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="employee">
              <form onSubmit={handleEmployeeLogin} className="space-y-4">
                <div>
                  <Label htmlFor="employee-email">Employee Email</Label>
                  <Input
                    id="employee-email"
                    type="email"
                    placeholder="employee@shophub.com"
                    required
                    value={employeeLoginForm.email}
                    onChange={(e) =>
                      setEmployeeLoginForm({ ...employeeLoginForm, email: e.target.value })
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="employee-password">Password</Label>
                  <Input
                    id="employee-password"
                    type="password"
                    placeholder="••••••••"
                    required
                    value={employeeLoginForm.password}
                    onChange={(e) =>
                      setEmployeeLoginForm({ ...employeeLoginForm, password: e.target.value })
                    }
                  />
                </div>
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? 'Logging in...' : 'Login as Employee'}
                </Button>
                <div className="text-xs text-gray-600 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                  <p>⚠️ Note: You must be added and approved by an administrator to login. Contact your admin if you don't have credentials.</p>
                </div>
              </form>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};