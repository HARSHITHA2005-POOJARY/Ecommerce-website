import React, { useState } from 'react';
import { Star, Heart, Share2, Truck, Shield, RotateCcw, ChevronLeft } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card, CardContent } from './ui/card';
import { Separator } from './ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { useCart } from '../context/CartContext';
import { useProducts } from '../context/ProductContext';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface ProductDetailProps {
  productId: string;
  onPageChange: (page: string) => void;
}

export const ProductDetail: React.FC<ProductDetailProps> = ({ productId, onPageChange }) => {
  const { addToCart } = useCart();
  const { products } = useProducts();
  const product = products.find((p) => p.id === productId);
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-xl mb-4">Product not found</p>
          <Button onClick={() => onPageChange('products')}>Back to Products</Button>
        </div>
      </div>
    );
  }

  const relatedProducts = products
    .filter((p) => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addToCart(product);
    }
  };

  const images = [product.image, product.image, product.image];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-3">
          <button
            onClick={() => onPageChange('products')}
            className="flex items-center gap-2 text-sm text-gray-600 hover:text-blue-600"
          >
            <ChevronLeft className="w-4 h-4" />
            Back to Products
          </button>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {/* Images */}
          <div className="space-y-4">
            <div className="aspect-square rounded-lg overflow-hidden bg-white border">
              <ImageWithFallback
                src={images[selectedImage]}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="grid grid-cols-3 gap-4">
              {images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImage(idx)}
                  className={`aspect-square rounded-lg overflow-hidden border-2 ${
                    selectedImage === idx ? 'border-blue-600' : 'border-gray-200'
                  }`}
                >
                  <ImageWithFallback
                    src={img}
                    alt={`${product.name} ${idx + 1}`}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Details */}
          <div>
            <Badge className="mb-2">{product.category}</Badge>
            <h1 className="text-3xl mb-2">{product.name}</h1>
            <p className="text-gray-600 mb-4">by {product.brand}</p>

            <div className="flex items-center gap-4 mb-4">
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      className={`w-5 h-5 ${
                        i < Math.floor(product.rating)
                          ? 'fill-yellow-400 text-yellow-400'
                          : 'text-gray-300'
                      }`}
                    />
                  ))}
                </div>
                <span>{product.rating}</span>
              </div>
              <Separator orientation="vertical" className="h-6" />
              <span className="text-gray-600">{product.reviews} reviews</span>
            </div>

            <div className="mb-6">
              <div className="flex items-baseline gap-3 mb-2">
                <span className="text-3xl">₹{product.price}</span>
                {product.originalPrice && (
                  <>
                    <span className="text-xl text-gray-500 line-through">
                      ₹{product.originalPrice}
                    </span>
                    <Badge className="bg-red-500">{product.discount}% OFF</Badge>
                  </>
                )}
              </div>
              <p className="text-green-600">You save ₹{((product.originalPrice || product.price) - product.price).toFixed(2)}</p>
            </div>

            <Separator className="my-6" />

            <p className="text-gray-700 mb-6">{product.description}</p>

            {/* Quantity and Add to Cart */}
            <div className="flex items-center gap-4 mb-6">
              <div className="flex items-center border rounded-lg">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                >
                  -
                </Button>
                <span className="px-4">{quantity}</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setQuantity(quantity + 1)}
                >
                  +
                </Button>
              </div>
              <Button onClick={handleAddToCart} size="lg" className="flex-1">
                Add to Cart
              </Button>
            </div>

            <div className="flex gap-2 mb-6">
              <Button variant="outline" className="flex-1">
                <Heart className="w-4 h-4 mr-2" />
                Wishlist
              </Button>
              <Button variant="outline">
                <Share2 className="w-4 h-4" />
              </Button>
            </div>

            {/* Features */}
            <Card>
              <CardContent className="p-4">
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <Truck className="w-5 h-5 text-blue-600" />
                    <div>
                      <p className="text-sm">Free Delivery</p>
                      <p className="text-xs text-gray-600">On orders over ₹500</p>
                    </div>
                  </div>
                  <Separator />
                  <div className="flex items-center gap-3">
                    <RotateCcw className="w-5 h-5 text-blue-600" />
                    <div>
                      <p className="text-sm">30 Days Return</p>
                      <p className="text-xs text-gray-600">Easy return policy</p>
                    </div>
                  </div>
                  <Separator />
                  <div className="flex items-center gap-3">
                    <Shield className="w-5 h-5 text-blue-600" />
                    <div>
                      <p className="text-sm">Secure Payment</p>
                      <p className="text-xs text-gray-600">100% secure transactions</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Tabs */}
        <Card className="mb-12">
          <CardContent className="p-6">
            <Tabs defaultValue="description">
              <TabsList>
                <TabsTrigger value="description">Description</TabsTrigger>
                <TabsTrigger value="specifications">Specifications</TabsTrigger>
                <TabsTrigger value="reviews">Reviews</TabsTrigger>
              </TabsList>
              <TabsContent value="description" className="mt-6">
                <h3 className="text-lg mb-4">Product Description</h3>
                <p className="text-gray-700">{product.description}</p>
                <p className="text-gray-700 mt-4">
                  This premium {product.name.toLowerCase()} from {product.brand} is designed to
                  meet the highest standards of quality and performance. Perfect for everyday use,
                  it combines style with functionality.
                </p>
              </TabsContent>
              <TabsContent value="specifications" className="mt-6">
                <h3 className="text-lg mb-4">Specifications</h3>
                <div className="space-y-2">
                  <div className="flex py-2 border-b">
                    <span className="w-48 text-gray-600">Brand</span>
                    <span>{product.brand}</span>
                  </div>
                  <div className="flex py-2 border-b">
                    <span className="w-48 text-gray-600">Category</span>
                    <span>{product.category}</span>
                  </div>
                  <div className="flex py-2 border-b">
                    <span className="w-48 text-gray-600">Availability</span>
                    <span className="text-green-600">In Stock</span>
                  </div>
                  <div className="flex py-2 border-b">
                    <span className="w-48 text-gray-600">SKU</span>
                    <span>{product.id.toUpperCase()}-{Math.random().toString(36).substring(7).toUpperCase()}</span>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="reviews" className="mt-6">
                <h3 className="text-lg mb-4">Customer Reviews</h3>
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="border-b pb-4">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="flex">
                          {Array.from({ length: 5 }).map((_, idx) => (
                            <Star
                              key={idx}
                              className="w-4 h-4 fill-yellow-400 text-yellow-400"
                            />
                          ))}
                        </div>
                        <span>by Customer {i}</span>
                      </div>
                      <p className="text-gray-700">
                        Great product! Exceeded my expectations. Highly recommended for anyone
                        looking for quality and value.
                      </p>
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div>
            <h2 className="text-2xl mb-6">Related Products</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {relatedProducts.map((relatedProduct) => (
                <Card
                  key={relatedProduct.id}
                  className="group cursor-pointer hover:shadow-lg transition-shadow"
                  onClick={() => onPageChange('product', relatedProduct.id)}
                >
                  <CardContent className="p-0">
                    <div className="relative aspect-square overflow-hidden">
                      <ImageWithFallback
                        src={relatedProduct.image}
                        alt={relatedProduct.name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform"
                      />
                    </div>
                    <div className="p-4">
                      <h3 className="text-sm mb-2 line-clamp-2">{relatedProduct.name}</h3>
                      <p className="text-lg">₹{relatedProduct.price}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
