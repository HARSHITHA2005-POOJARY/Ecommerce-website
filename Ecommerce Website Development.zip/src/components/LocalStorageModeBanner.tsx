import React, { useState, useEffect } from 'react';
import { AlertCircle, X } from 'lucide-react';
import { Button } from './ui/button';

export const LocalStorageModeBanner: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [isDismissed, setIsDismissed] = useState(() => {
    return localStorage.getItem('localStorageModeBannerDismissed') === 'true';
  });

  useEffect(() => {
    // Check if backend is available by looking for localStorage usage
    const checkBackendStatus = () => {
      const employees = localStorage.getItem('employees');
      const hasData = employees && employees !== '[]';
      
      // Only show if there's data in localStorage and user hasn't dismissed
      if (hasData && !isDismissed) {
        setIsVisible(true);
      }
    };

    // Check after a short delay to allow data to load
    const timer = setTimeout(checkBackendStatus, 1000);
    
    return () => clearTimeout(timer);
  }, [isDismissed]);

  const handleDismiss = () => {
    setIsDismissed(true);
    setIsVisible(false);
    localStorage.setItem('localStorageModeBannerDismissed', 'true');
  };

  if (!isVisible) return null;

  return (
    <div className="bg-blue-50 border-b border-blue-200 px-4 py-3">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <AlertCircle className="h-5 w-5 text-blue-600 flex-shrink-0" />
          <div className="flex-1">
            <p className="text-sm text-blue-900">
              <strong>LocalStorage Mode Active:</strong> You're using the app without a backend. 
              Data is saved in your browser and will work offline. Employee login uses email only (no password validation in this mode).
              {' '}
              <a 
                href="/SETUP_MODES.md" 
                target="_blank" 
                className="underline hover:text-blue-700"
              >
                Learn more
              </a>
            </p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={handleDismiss}
          className="flex-shrink-0 h-8 w-8 p-0"
        >
          <X className="h-4 w-4" />
          <span className="sr-only">Dismiss</span>
        </Button>
      </div>
    </div>
  );
};
