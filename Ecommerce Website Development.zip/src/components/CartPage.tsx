import React from 'react';
import { Trash2, Plus, Minus, ShoppingBag, ChevronLeft } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Separator } from './ui/separator';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { toast } from 'sonner';

interface CartPageProps {
  onPageChange: (page: string) => void;
}

export const CartPage: React.FC<CartPageProps> = ({ onPageChange }) => {
  const { cart, removeFromCart, updateQuantity, getCartTotal } = useCart();
  const { isAuthenticated } = useAuth();

  if (cart.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <ShoppingBag className="w-24 h-24 mx-auto text-gray-400 mb-4" />
          <h2 className="text-2xl mb-2">Your cart is empty</h2>
          <p className="text-gray-600 mb-6">Add some products to get started</p>
          <Button onClick={() => onPageChange('products')}>
            Continue Shopping
          </Button>
        </div>
      </div>
    );
  }

  const subtotal = getCartTotal();
  const shipping = subtotal > 500 ? 0 : 99;
  const tax = subtotal * 0.1;
  const total = subtotal + shipping + tax;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-3">
          <button
            onClick={() => onPageChange('products')}
            className="flex items-center gap-2 text-sm text-gray-600 hover:text-blue-600"
          >
            <ChevronLeft className="w-4 h-4" />
            Continue Shopping
          </button>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl mb-8">Shopping Cart ({cart.length} items)</h1>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {cart.map((item) => (
              <Card key={item.product.id}>
                <CardContent className="p-4">
                  <div className="flex gap-4">
                    <div
                      className="w-24 h-24 flex-shrink-0 rounded-lg overflow-hidden bg-gray-100 cursor-pointer"
                      onClick={() => onPageChange('product', item.product.id)}
                    >
                      <ImageWithFallback
                        src={item.product.image}
                        alt={item.product.name}
                        className="w-full h-full object-cover"
                      />
                    </div>

                    <div className="flex-1">
                      <h3
                        className="mb-1 cursor-pointer hover:text-blue-600"
                        onClick={() => onPageChange('product', item.product.id)}
                      >
                        {item.product.name}
                      </h3>
                      <p className="text-sm text-gray-600 mb-2">{item.product.brand}</p>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                          >
                            <Minus className="w-4 h-4" />
                          </Button>
                          <span className="w-8 text-center">{item.quantity}</span>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              if (item.quantity >= 30) {
                                toast.error('Maximum quantity limit is 30 per product');
                                return;
                              }
                              updateQuantity(item.product.id, item.quantity + 1);
                            }}
                            disabled={item.quantity >= 30}
                          >
                            <Plus className="w-4 h-4" />
                          </Button>
                          {item.quantity >= 30 && (
                            <span className="text-xs text-red-500 ml-2">Max limit reached</span>
                          )}
                        </div>

                        <div className="flex items-center gap-4">
                          <div className="text-right">
                            <p className="text-lg">₹{(item.product.price * item.quantity).toFixed(2)}</p>
                            <p className="text-sm text-gray-600">₹{item.product.price} each</p>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeFromCart(item.product.id)}
                            className="text-red-500 hover:text-red-700 hover:bg-red-50"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Order Summary */}
          <div>
            <Card className="sticky top-4">
              <CardContent className="p-6">
                <h2 className="text-xl mb-4">Order Summary</h2>

                <div className="space-y-3 mb-4">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Subtotal</span>
                    <span>₹{subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Shipping</span>
                    <span>{shipping === 0 ? 'FREE' : `₹${shipping.toFixed(2)}`}</span>
                  </div>
                  {subtotal < 500 && (
                    <p className="text-sm text-blue-600">
                      Add ₹{(500 - subtotal).toFixed(2)} more for free shipping!
                    </p>
                  )}
                  <div className="flex justify-between">
                    <span className="text-gray-600">Tax (10%)</span>
                    <span>₹{tax.toFixed(2)}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between text-lg">
                    <span>Total</span>
                    <span>₹{total.toFixed(2)}</span>
                  </div>
                </div>

                {isAuthenticated ? (
                  <Button
                    onClick={() => onPageChange('checkout')}
                    className="w-full"
                    size="lg"
                  >
                    Proceed to Checkout
                  </Button>
                ) : (
                  <>
                    <Button
                      onClick={() => onPageChange('checkout')}
                      className="w-full mb-2"
                      size="lg"
                    >
                      Checkout as Guest
                    </Button>
                    <Button
                      onClick={() => onPageChange('login')}
                      variant="outline"
                      className="w-full"
                    >
                      Login to Continue
                    </Button>
                  </>
                )}

                <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                  <h3 className="text-sm mb-2">We Accept</h3>
                  <div className="flex gap-2">
                    <div className="px-3 py-1 bg-white rounded border text-xs">VISA</div>
                    <div className="px-3 py-1 bg-white rounded border text-xs">MC</div>
                    <div className="px-3 py-1 bg-white rounded border text-xs">AMEX</div>
                    <div className="px-3 py-1 bg-white rounded border text-xs">PayPal</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};
