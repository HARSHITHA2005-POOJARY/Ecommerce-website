import React, { useState } from 'react';
import { 
  Package, ShoppingBag, Users, TrendingUp, Plus, Edit, Trash2, 
  Search, Filter, ArrowLeft, DollarSign, Eye, LogOut, Store, Briefcase 
} from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { useProducts } from '../context/ProductContext';
import { useOrders } from '../context/OrderContext';
import { useAuth } from '../context/AuthContext';
import { useSeller } from '../context/SellerContext';
import { Product } from '../types';
import { toast } from 'sonner@2.0.3';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { EmployeeManagement } from './EmployeeManagement';
import { AuditLogViewer } from './AuditLogViewer';

interface AdminDashboardProps {
  onPageChange: (page: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onPageChange }) => {
  const { products, addProduct, updateProduct, deleteProduct } = useProducts();
  const { orders, updateOrderStatus } = useOrders();
  const { logout, user } = useAuth();
  const { sellers, addSeller, updateSeller, approveSeller, updateCommission, deleteSeller } = useSeller();
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddProductOpen, setIsAddProductOpen] = useState(false);
  const [isAddSellerOpen, setIsAddSellerOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  const [productForm, setProductForm] = useState<Partial<Product>>({
    name: '',
    description: '',
    price: 0,
    originalPrice: 0,
    category: '',
    brand: '',
    image: '',
    rating: 4.5,
    reviews: 0,
    inStock: true,
    tags: [],
  });

  const [sellerForm, setSellerForm] = useState({
    name: '',
    email: '',
    businessName: '',
    phone: '',
    gst: '',
    commission: '15',
    address: '',
    approved: false,
  });

  // Calculate statistics
  const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0);
  const totalOrders = orders.length;
  const totalProducts = products.length;
  const pendingOrders = orders.filter((o) => o.status === 'pending').length;

  const handleAddProduct = () => {
    if (!productForm.name || !productForm.price || !productForm.category) {
      toast.error('Please fill in all required fields');
      return;
    }

    const newProduct: Product = {
      id: Date.now().toString(),
      name: productForm.name!,
      description: productForm.description || '',
      price: productForm.price!,
      originalPrice: productForm.originalPrice,
      discount: productForm.originalPrice 
        ? Math.round(((productForm.originalPrice - productForm.price!) / productForm.originalPrice) * 100)
        : undefined,
      category: productForm.category!,
      brand: productForm.brand || 'Generic',
      image: productForm.image || 'https://images.unsplash.com/photo-1717295248494-937c3a5655b1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVjdHJvbmljcyUyMGdhZGdldHN8ZW58MXx8fHwxNzYxNjkyMTA3fDA&ixlib=rb-4.1.0&q=80&w=1080',
      rating: productForm.rating || 4.5,
      reviews: productForm.reviews || 0,
      inStock: productForm.inStock !== undefined ? productForm.inStock : true,
      tags: productForm.tags || [],
    };

    addProduct(newProduct);
    toast.success('Product added successfully!');
    setIsAddProductOpen(false);
    resetForm();
  };

  const handleUpdateProduct = () => {
    if (!editingProduct) return;

    updateProduct(editingProduct.id, productForm);
    toast.success('Product updated successfully!');
    setEditingProduct(null);
    resetForm();
  };

  const handleDeleteProduct = (id: string) => {
    if (confirm('Are you sure you want to delete this product?')) {
      deleteProduct(id);
      toast.success('Product deleted successfully!');
    }
  };

  const resetForm = () => {
    setProductForm({
      name: '',
      description: '',
      price: 0,
      originalPrice: 0,
      category: '',
      brand: '',
      image: '',
      rating: 4.5,
      reviews: 0,
      inStock: true,
      tags: [],
    });
  };

  const startEdit = (product: Product) => {
    setEditingProduct(product);
    setProductForm(product);
  };

  const filteredProducts = products.filter((p) =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.brand.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-500';
      case 'confirmed': return 'bg-blue-500';
      case 'shipped': return 'bg-purple-500';
      case 'delivered': return 'bg-green-500';
      case 'cancelled': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                onClick={() => onPageChange('home')}
                className="flex items-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                Back to Store
              </Button>
              <h1 className="text-2xl">Admin Dashboard</h1>
            </div>
            <div className="flex items-center gap-4">
              {user && (
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-600">Welcome, {user.name}</span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      logout();
                      onPageChange('home');
                    }}
                    className="flex items-center gap-2"
                  >
                    <LogOut className="w-4 h-4" />
                    Logout
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Revenue</p>
                  <p className="text-2xl">₹{totalRevenue.toFixed(2)}</p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Orders</p>
                  <p className="text-2xl">{totalOrders}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <ShoppingBag className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Products</p>
                  <p className="text-2xl">{totalProducts}</p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                  <Package className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Pending Orders</p>
                  <p className="text-2xl">{pendingOrders}</p>
                </div>
                <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-orange-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="products" className="space-y-6">
          <TabsList>
            <TabsTrigger value="products">Products</TabsTrigger>
            <TabsTrigger value="orders">Orders</TabsTrigger>
            <TabsTrigger value="sellers">Sellers</TabsTrigger>
            <TabsTrigger value="employees">Employees</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="audit">Audit Logs</TabsTrigger>
          </TabsList>

          {/* Products Tab */}
          <TabsContent value="products">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Product Management</CardTitle>
                  <Dialog open={isAddProductOpen || !!editingProduct} onOpenChange={(open) => {
                    setIsAddProductOpen(open);
                    if (!open) {
                      setEditingProduct(null);
                      resetForm();
                    }
                  }}>
                    <DialogTrigger asChild>
                      <Button onClick={() => setIsAddProductOpen(true)}>
                        <Plus className="w-4 h-4 mr-2" />
                        Add Product
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle>{editingProduct ? 'Edit Product' : 'Add New Product'}</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <Label>Product Name *</Label>
                            <Input
                              value={productForm.name}
                              onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
                              placeholder="Enter product name"
                            />
                          </div>
                          <div>
                            <Label>Brand *</Label>
                            <Input
                              value={productForm.brand}
                              onChange={(e) => setProductForm({ ...productForm, brand: e.target.value })}
                              placeholder="Enter brand name"
                            />
                          </div>
                        </div>

                        <div>
                          <Label>Description</Label>
                          <Textarea
                            value={productForm.description}
                            onChange={(e) => setProductForm({ ...productForm, description: e.target.value })}
                            placeholder="Enter product description"
                            rows={3}
                          />
                        </div>

                        <div className="grid md:grid-cols-3 gap-4">
                          <div>
                            <Label>Price (₹) *</Label>
                            <Input
                              type="number"
                              value={productForm.price}
                              onChange={(e) => setProductForm({ ...productForm, price: parseFloat(e.target.value) })}
                              placeholder="0.00"
                            />
                          </div>
                          <div>
                            <Label>Original Price (₹)</Label>
                            <Input
                              type="number"
                              value={productForm.originalPrice}
                              onChange={(e) => setProductForm({ ...productForm, originalPrice: parseFloat(e.target.value) })}
                              placeholder="0.00"
                            />
                          </div>
                          <div>
                            <Label>Category *</Label>
                            <Select
                              value={productForm.category}
                              onValueChange={(value) => setProductForm({ ...productForm, category: value })}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Select category" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Electronics">Electronics</SelectItem>
                                <SelectItem value="Fashion">Fashion</SelectItem>
                                <SelectItem value="Home">Home</SelectItem>
                                <SelectItem value="Sports">Sports</SelectItem>
                                <SelectItem value="Beauty">Beauty</SelectItem>
                                <SelectItem value="Books">Books</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        <div>
                          <Label>Image URL</Label>
                          <Input
                            value={productForm.image}
                            onChange={(e) => setProductForm({ ...productForm, image: e.target.value })}
                            placeholder="https://example.com/image.jpg"
                          />
                        </div>

                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <Label>Rating (0-5)</Label>
                            <Input
                              type="number"
                              step="0.1"
                              min="0"
                              max="5"
                              value={productForm.rating}
                              onChange={(e) => setProductForm({ ...productForm, rating: parseFloat(e.target.value) })}
                            />
                          </div>
                          <div>
                            <Label>In Stock</Label>
                            <Select
                              value={productForm.inStock ? 'true' : 'false'}
                              onValueChange={(value) => setProductForm({ ...productForm, inStock: value === 'true' })}
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="true">Yes</SelectItem>
                                <SelectItem value="false">No</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        <div className="flex gap-2">
                          <Button
                            onClick={editingProduct ? handleUpdateProduct : handleAddProduct}
                            className="flex-1"
                          >
                            {editingProduct ? 'Update Product' : 'Add Product'}
                          </Button>
                          <Button
                            variant="outline"
                            onClick={() => {
                              setIsAddProductOpen(false);
                              setEditingProduct(null);
                              resetForm();
                            }}
                          >
                            Cancel
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                <div className="mb-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                    <Input
                      placeholder="Search products..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                <div className="border rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Product</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Stock</TableHead>
                        <TableHead>Rating</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredProducts.map((product) => (
                        <TableRow key={product.id}>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <ImageWithFallback
                                src={product.image}
                                alt={product.name}
                                className="w-12 h-12 object-cover rounded"
                              />
                              <div>
                                <p className="text-sm">{product.name}</p>
                                <p className="text-xs text-gray-600">{product.brand}</p>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>{product.category}</TableCell>
                          <TableCell>
                            <div>
                              <p>₹{product.price}</p>
                              {product.originalPrice && (
                                <p className="text-xs text-gray-500 line-through">
                                  ₹{product.originalPrice}
                                </p>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant={product.inStock ? 'default' : 'destructive'}>
                              {product.inStock ? 'In Stock' : 'Out of Stock'}
                            </Badge>
                          </TableCell>
                          <TableCell>{product.rating} ★</TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => startEdit(product)}
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleDeleteProduct(product.id)}
                                className="text-red-600 hover:text-red-700"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Orders Tab */}
          <TabsContent value="orders">
            <Card>
              <CardHeader>
                <CardTitle>Order Management</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="border rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Order ID</TableHead>
                        <TableHead>Customer</TableHead>
                        <TableHead>Items</TableHead>
                        <TableHead>Total</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {orders.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                            No orders yet
                          </TableCell>
                        </TableRow>
                      ) : (
                        orders.map((order) => (
                          <TableRow key={order.id}>
                            <TableCell className="font-mono text-sm">{order.orderId}</TableCell>
                            <TableCell>
                              <div>
                                <p className="text-sm">{order.userName}</p>
                                <p className="text-xs text-gray-600">{order.userEmail}</p>
                              </div>
                            </TableCell>
                            <TableCell>{order.items.length} items</TableCell>
                            <TableCell>₹{order.total.toFixed(2)}</TableCell>
                            <TableCell>
                              <Select
                                value={order.status}
                                onValueChange={(value) => updateOrderStatus(order.orderId, value as any)}
                              >
                                <SelectTrigger className="w-32">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="pending">Pending</SelectItem>
                                  <SelectItem value="confirmed">Confirmed</SelectItem>
                                  <SelectItem value="shipped">Shipped</SelectItem>
                                  <SelectItem value="delivered">Delivered</SelectItem>
                                  <SelectItem value="cancelled">Cancelled</SelectItem>
                                </SelectContent>
                              </Select>
                            </TableCell>
                            <TableCell className="text-sm">
                              {new Date(order.createdAt).toLocaleDateString()}
                            </TableCell>
                            <TableCell>
                              <Button variant="ghost" size="sm">
                                <Eye className="w-4 h-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Sellers Tab */}
          <TabsContent value="sellers">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Manage Sellers</CardTitle>
                  <Dialog open={isAddSellerOpen} onOpenChange={setIsAddSellerOpen}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="w-4 h-4 mr-2" />
                        Add Seller
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle>Add New Seller</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="sellerName">Contact Person Name *</Label>
                            <Input
                              id="sellerName"
                              value={sellerForm.name}
                              onChange={(e) => setSellerForm({ ...sellerForm, name: e.target.value })}
                              placeholder="John Doe"
                            />
                          </div>
                          <div>
                            <Label htmlFor="sellerEmail">Email *</Label>
                            <Input
                              id="sellerEmail"
                              type="email"
                              value={sellerForm.email}
                              onChange={(e) => setSellerForm({ ...sellerForm, email: e.target.value })}
                              placeholder="seller@example.com"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="businessName">Business Name *</Label>
                            <Input
                              id="businessName"
                              value={sellerForm.businessName}
                              onChange={(e) => setSellerForm({ ...sellerForm, businessName: e.target.value })}
                              placeholder="My Shop"
                            />
                          </div>
                          <div>
                            <Label htmlFor="sellerPhone">Phone *</Label>
                            <Input
                              id="sellerPhone"
                              value={sellerForm.phone}
                              onChange={(e) => setSellerForm({ ...sellerForm, phone: e.target.value })}
                              placeholder="+91 9876543210"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="gst">GST Number</Label>
                            <Input
                              id="gst"
                              value={sellerForm.gst}
                              onChange={(e) => setSellerForm({ ...sellerForm, gst: e.target.value })}
                              placeholder="22AAAAA0000A1Z5"
                            />
                          </div>
                          <div>
                            <Label htmlFor="commission">Commission (%) *</Label>
                            <Input
                              id="commission"
                              type="number"
                              value={sellerForm.commission}
                              onChange={(e) => setSellerForm({ ...sellerForm, commission: e.target.value })}
                              placeholder="15"
                            />
                          </div>
                        </div>

                        <div>
                          <Label htmlFor="sellerAddress">Address *</Label>
                          <Textarea
                            id="sellerAddress"
                            value={sellerForm.address}
                            onChange={(e) => setSellerForm({ ...sellerForm, address: e.target.value })}
                            placeholder="Complete business address"
                            rows={3}
                          />
                        </div>

                        <div className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id="approved"
                            checked={sellerForm.approved}
                            onChange={(e) => setSellerForm({ ...sellerForm, approved: e.target.checked })}
                          />
                          <Label htmlFor="approved">Approve seller immediately</Label>
                        </div>

                        <Button
                          onClick={() => {
                            if (!sellerForm.name || !sellerForm.email || !sellerForm.businessName || !sellerForm.phone || !sellerForm.commission || !sellerForm.address) {
                              toast.error('Please fill all required fields');
                              return;
                            }

                            addSeller({
                              name: sellerForm.name,
                              email: sellerForm.email,
                              businessName: sellerForm.businessName,
                              phone: sellerForm.phone,
                              gst: sellerForm.gst,
                              commission: parseFloat(sellerForm.commission),
                              address: sellerForm.address,
                              approved: sellerForm.approved,
                            });

                            toast.success('Seller added successfully!');
                            setIsAddSellerOpen(false);
                            setSellerForm({
                              name: '',
                              email: '',
                              businessName: '',
                              phone: '',
                              gst: '',
                              commission: '15',
                              address: '',
                              approved: false,
                            });
                          }}
                          className="w-full"
                        >
                          Add Seller
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Business Name</TableHead>
                      <TableHead>Contact Person</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Phone</TableHead>
                      <TableHead>Commission</TableHead>
                      <TableHead>Total Sales</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sellers.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={8} className="text-center py-8">
                          No sellers found. Add your first seller!
                        </TableCell>
                      </TableRow>
                    ) : (
                      sellers.map((seller) => (
                        <TableRow key={seller.id}>
                          <TableCell>{seller.businessName}</TableCell>
                          <TableCell>{seller.name}</TableCell>
                          <TableCell>{seller.email}</TableCell>
                          <TableCell>{seller.phone}</TableCell>
                          <TableCell>{seller.commission}%</TableCell>
                          <TableCell>₹{seller.totalSales.toLocaleString('en-IN')}</TableCell>
                          <TableCell>
                            <Badge variant={seller.approved ? 'default' : 'secondary'}>
                              {seller.approved ? 'Approved' : 'Pending'}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              {!seller.approved && (
                                <Button
                                  size="sm"
                                  onClick={() => {
                                    approveSeller(seller.id);
                                    toast.success('Seller approved!');
                                  }}
                                >
                                  Approve
                                </Button>
                              )}
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button variant="outline" size="sm">
                                    <Edit className="w-4 h-4" />
                                  </Button>
                                </DialogTrigger>
                                <DialogContent>
                                  <DialogHeader>
                                    <DialogTitle>Update Commission</DialogTitle>
                                  </DialogHeader>
                                  <div className="space-y-4">
                                    <div>
                                      <Label>Commission (%)</Label>
                                      <Input
                                        type="number"
                                        defaultValue={seller.commission}
                                        id={`commission-${seller.id}`}
                                      />
                                    </div>
                                    <Button
                                      onClick={() => {
                                        const input = document.getElementById(`commission-${seller.id}`) as HTMLInputElement;
                                        updateCommission(seller.id, parseFloat(input.value));
                                        toast.success('Commission updated!');
                                      }}
                                      className="w-full"
                                    >
                                      Update
                                    </Button>
                                  </div>
                                </DialogContent>
                              </Dialog>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  if (confirm('Are you sure you want to delete this seller?')) {
                                    deleteSeller(seller.id);
                                    toast.success('Seller deleted!');
                                  }
                                }}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Employees Tab */}
          <TabsContent value="employees">
            <EmployeeManagement />
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Revenue Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Total Revenue</span>
                      <span className="text-xl">₹{totalRevenue.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Average Order Value</span>
                      <span className="text-xl">
                        ₹{totalOrders > 0 ? (totalRevenue / totalOrders).toFixed(2) : '0.00'}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Order Status Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {['pending', 'confirmed', 'shipped', 'delivered', 'cancelled'].map((status) => {
                      const count = orders.filter((o) => o.status === status).length;
                      const percentage = totalOrders > 0 ? (count / totalOrders) * 100 : 0;
                      return (
                        <div key={status}>
                          <div className="flex justify-between text-sm mb-1">
                            <span className="capitalize">{status}</span>
                            <span>{count} ({percentage.toFixed(0)}%)</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div
                              className={`h-2 rounded-full ${getStatusColor(status)}`}
                              style={{ width: `${percentage}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Top Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {Array.from(new Set(products.map((p) => p.category))).map((category) => {
                      const count = products.filter((p) => p.category === category).length;
                      return (
                        <div key={category} className="flex justify-between items-center py-2 border-b">
                          <span>{category}</span>
                          <Badge>{count} products</Badge>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {orders.slice(0, 5).map((order) => (
                      <div key={order.id} className="flex items-center justify-between py-2 border-b">
                        <div>
                          <p className="text-sm">Order #{order.orderId}</p>
                          <p className="text-xs text-gray-600">{order.userName}</p>
                        </div>
                        <Badge className={getStatusColor(order.status)}>
                          {order.status}
                        </Badge>
                      </div>
                    ))}
                    {orders.length === 0 && (
                      <p className="text-center text-gray-500 py-4">No recent activity</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Audit Logs Tab */}
          <TabsContent value="audit">
            <AuditLogViewer />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};