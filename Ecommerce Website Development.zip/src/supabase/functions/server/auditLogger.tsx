/**
 * Audit Logger Utility
 * Tracks all database actions with detailed context
 */

import * as kv from './kv_store.tsx';

export interface AuditLog {
  id: string;
  timestamp: string;
  userId: string | null;
  userEmail: string | null;
  userRole: string | null;
  action: AuditAction;
  entityType: EntityType;
  entityId: string | null;
  entityName: string | null;
  details: Record<string, any>;
  ipAddress: string | null;
  userAgent: string | null;
  success: boolean;
  errorMessage?: string;
}

export enum AuditAction {
  // Authentication
  LOGIN = 'LOGIN',
  LOGOUT = 'LOGOUT',
  SIGNUP = 'SIGNUP',
  LOGIN_FAILED = 'LOGIN_FAILED',
  
  // CRUD Operations
  CREATE = 'CREATE',
  READ = 'READ',
  UPDATE = 'UPDATE',
  DELETE = 'DELETE',
  
  // Specific Actions
  APPROVE = 'APPROVE',
  REJECT = 'REJECT',
  ACTIVATE = 'ACTIVATE',
  DEACTIVATE = 'DEACTIVATE',
  
  // Product Actions
  PRODUCT_ADD = 'PRODUCT_ADD',
  PRODUCT_UPDATE = 'PRODUCT_UPDATE',
  PRODUCT_DELETE = 'PRODUCT_DELETE',
  PRODUCT_VIEW = 'PRODUCT_VIEW',
  
  // Order Actions
  ORDER_CREATE = 'ORDER_CREATE',
  ORDER_UPDATE = 'ORDER_UPDATE',
  ORDER_CANCEL = 'ORDER_CANCEL',
  ORDER_STATUS_CHANGE = 'ORDER_STATUS_CHANGE',
  
  // Cart Actions
  CART_ADD = 'CART_ADD',
  CART_UPDATE = 'CART_UPDATE',
  CART_REMOVE = 'CART_REMOVE',
  CART_CLEAR = 'CART_CLEAR',
  
  // Employee Actions
  EMPLOYEE_ADD = 'EMPLOYEE_ADD',
  EMPLOYEE_UPDATE = 'EMPLOYEE_UPDATE',
  EMPLOYEE_DELETE = 'EMPLOYEE_DELETE',
  EMPLOYEE_APPROVE = 'EMPLOYEE_APPROVE',
  EMPLOYEE_REJECT = 'EMPLOYEE_REJECT',
  
  // Attendance Actions
  ATTENDANCE_MARK = 'ATTENDANCE_MARK',
  ATTENDANCE_UPDATE = 'ATTENDANCE_UPDATE',
  
  // Seller Actions
  SELLER_REGISTER = 'SELLER_REGISTER',
  SELLER_APPROVE = 'SELLER_APPROVE',
  SELLER_UPDATE = 'SELLER_UPDATE',
  SELLER_DELETE = 'SELLER_DELETE',
  
  // Admin Actions
  COMMISSION_UPDATE = 'COMMISSION_UPDATE',
  SETTINGS_UPDATE = 'SETTINGS_UPDATE',
}

export enum EntityType {
  USER = 'USER',
  PRODUCT = 'PRODUCT',
  ORDER = 'ORDER',
  CART = 'CART',
  EMPLOYEE = 'EMPLOYEE',
  ATTENDANCE = 'ATTENDANCE',
  SELLER = 'SELLER',
  COMMISSION = 'COMMISSION',
  SETTINGS = 'SETTINGS',
}

interface LogParams {
  userId?: string | null;
  userEmail?: string | null;
  userRole?: string | null;
  action: AuditAction;
  entityType: EntityType;
  entityId?: string | null;
  entityName?: string | null;
  details?: Record<string, any>;
  request?: Request;
  success?: boolean;
  errorMessage?: string;
}

/**
 * Log an audit entry
 */
export async function logAudit(params: LogParams): Promise<void> {
  try {
    const auditLog: AuditLog = {
      id: crypto.randomUUID(),
      timestamp: new Date().toISOString(),
      userId: params.userId || null,
      userEmail: params.userEmail || null,
      userRole: params.userRole || null,
      action: params.action,
      entityType: params.entityType,
      entityId: params.entityId || null,
      entityName: params.entityName || null,
      details: params.details || {},
      ipAddress: params.request?.headers.get('x-forwarded-for') || 
                 params.request?.headers.get('x-real-ip') || null,
      userAgent: params.request?.headers.get('user-agent') || null,
      success: params.success !== false,
      errorMessage: params.errorMessage,
    };

    // Store in KV with timestamped key for easy retrieval
    const key = `audit:${auditLog.timestamp}:${auditLog.id}`;
    await kv.set(key, auditLog);

    // Also store by user for quick user-specific queries
    if (params.userId) {
      const userKey = `audit:user:${params.userId}:${auditLog.timestamp}:${auditLog.id}`;
      await kv.set(userKey, auditLog);
    }

    // Store by entity for entity-specific queries
    if (params.entityId) {
      const entityKey = `audit:entity:${params.entityType}:${params.entityId}:${auditLog.timestamp}`;
      await kv.set(entityKey, auditLog);
    }

    console.log('Audit logged:', {
      action: auditLog.action,
      entity: auditLog.entityType,
      user: auditLog.userEmail,
    });
  } catch (error) {
    console.error('Failed to log audit:', error);
    // Don't throw - audit logging should not break the main flow
  }
}

/**
 * Get all audit logs (recent first)
 */
export async function getAuditLogs(limit: number = 100): Promise<AuditLog[]> {
  try {
    const logs = await kv.getByPrefix('audit:2'); // Get logs starting with "audit:2" (year 2xxx)
    
    // Sort by timestamp descending
    const sortedLogs = logs
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, limit);
    
    return sortedLogs;
  } catch (error) {
    console.error('Failed to get audit logs:', error);
    return [];
  }
}

/**
 * Get audit logs for a specific user
 */
export async function getAuditLogsByUser(userId: string, limit: number = 50): Promise<AuditLog[]> {
  try {
    const logs = await kv.getByPrefix(`audit:user:${userId}`);
    
    return logs
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, limit);
  } catch (error) {
    console.error('Failed to get user audit logs:', error);
    return [];
  }
}

/**
 * Get audit logs for a specific entity
 */
export async function getAuditLogsByEntity(
  entityType: EntityType,
  entityId: string,
  limit: number = 50
): Promise<AuditLog[]> {
  try {
    const logs = await kv.getByPrefix(`audit:entity:${entityType}:${entityId}`);
    
    return logs
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, limit);
  } catch (error) {
    console.error('Failed to get entity audit logs:', error);
    return [];
  }
}

/**
 * Get audit logs by action type
 */
export async function getAuditLogsByAction(action: AuditAction, limit: number = 50): Promise<AuditLog[]> {
  try {
    const allLogs = await getAuditLogs(1000); // Get more logs to filter
    
    return allLogs
      .filter(log => log.action === action)
      .slice(0, limit);
  } catch (error) {
    console.error('Failed to get audit logs by action:', error);
    return [];
  }
}

/**
 * Get audit logs within a date range
 */
export async function getAuditLogsByDateRange(
  startDate: string,
  endDate: string,
  limit: number = 100
): Promise<AuditLog[]> {
  try {
    const allLogs = await getAuditLogs(1000);
    
    return allLogs
      .filter(log => {
        const logDate = new Date(log.timestamp);
        return logDate >= new Date(startDate) && logDate <= new Date(endDate);
      })
      .slice(0, limit);
  } catch (error) {
    console.error('Failed to get audit logs by date range:', error);
    return [];
  }
}

/**
 * Get audit statistics
 */
export async function getAuditStats(): Promise<{
  totalLogs: number;
  logsByAction: Record<string, number>;
  logsByEntity: Record<string, number>;
  logsByUser: Record<string, number>;
  failedActions: number;
  recentActivity: AuditLog[];
}> {
  try {
    const logs = await getAuditLogs(500);
    
    const stats = {
      totalLogs: logs.length,
      logsByAction: {} as Record<string, number>,
      logsByEntity: {} as Record<string, number>,
      logsByUser: {} as Record<string, number>,
      failedActions: 0,
      recentActivity: logs.slice(0, 10),
    };
    
    logs.forEach(log => {
      // Count by action
      stats.logsByAction[log.action] = (stats.logsByAction[log.action] || 0) + 1;
      
      // Count by entity
      stats.logsByEntity[log.entityType] = (stats.logsByEntity[log.entityType] || 0) + 1;
      
      // Count by user
      if (log.userEmail) {
        stats.logsByUser[log.userEmail] = (stats.logsByUser[log.userEmail] || 0) + 1;
      }
      
      // Count failures
      if (!log.success) {
        stats.failedActions++;
      }
    });
    
    return stats;
  } catch (error) {
    console.error('Failed to get audit stats:', error);
    return {
      totalLogs: 0,
      logsByAction: {},
      logsByEntity: {},
      logsByUser: {},
      failedActions: 0,
      recentActivity: [],
    };
  }
}

/**
 * Clear old audit logs (older than specified days)
 */
export async function clearOldAuditLogs(daysToKeep: number = 90): Promise<number> {
  try {
    const logs = await kv.getByPrefix('audit:2');
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);
    
    const keysToDelete: string[] = [];
    
    logs.forEach(log => {
      if (new Date(log.timestamp) < cutoffDate) {
        // Add all related keys
        keysToDelete.push(`audit:${log.timestamp}:${log.id}`);
        if (log.userId) {
          keysToDelete.push(`audit:user:${log.userId}:${log.timestamp}:${log.id}`);
        }
        if (log.entityId) {
          keysToDelete.push(`audit:entity:${log.entityType}:${log.entityId}:${log.timestamp}`);
        }
      }
    });
    
    if (keysToDelete.length > 0) {
      await kv.mdel(keysToDelete);
    }
    
    return keysToDelete.length;
  } catch (error) {
    console.error('Failed to clear old audit logs:', error);
    return 0;
  }
}
