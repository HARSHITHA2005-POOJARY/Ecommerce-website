/**
 * Audit Log Routes
 * API endpoints for viewing and querying audit logs
 */

import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import {
  getAuditLogs,
  getAuditLogsByUser,
  getAuditLogsByEntity,
  getAuditLogsByAction,
  getAuditLogsByDateRange,
  getAuditStats,
  clearOldAuditLogs,
  AuditAction,
  EntityType,
} from './auditLogger.tsx';

const app = new Hono();

// Enable CORS
app.use('*', cors({
  origin: '*',
  credentials: true,
}));

/**
 * GET /make-server-6d108759/audit/logs
 * Get all audit logs (paginated)
 */
app.get('/make-server-6d108759/audit/logs', async (c) => {
  try {
    const limit = Number(c.req.query('limit')) || 100;
    const logs = await getAuditLogs(limit);
    
    return c.json({
      success: true,
      data: logs,
      count: logs.length,
    });
  } catch (error) {
    console.error('Error fetching audit logs:', error);
    return c.json({
      success: false,
      error: 'Failed to fetch audit logs',
      details: error.message,
    }, 500);
  }
});

/**
 * GET /make-server-6d108759/audit/logs/user/:userId
 * Get audit logs for a specific user
 */
app.get('/make-server-6d108759/audit/logs/user/:userId', async (c) => {
  try {
    const userId = c.req.param('userId');
    const limit = Number(c.req.query('limit')) || 50;
    
    const logs = await getAuditLogsByUser(userId, limit);
    
    return c.json({
      success: true,
      data: logs,
      count: logs.length,
    });
  } catch (error) {
    console.error('Error fetching user audit logs:', error);
    return c.json({
      success: false,
      error: 'Failed to fetch user audit logs',
      details: error.message,
    }, 500);
  }
});

/**
 * GET /make-server-6d108759/audit/logs/entity/:entityType/:entityId
 * Get audit logs for a specific entity
 */
app.get('/make-server-6d108759/audit/logs/entity/:entityType/:entityId', async (c) => {
  try {
    const entityType = c.req.param('entityType') as EntityType;
    const entityId = c.req.param('entityId');
    const limit = Number(c.req.query('limit')) || 50;
    
    const logs = await getAuditLogsByEntity(entityType, entityId, limit);
    
    return c.json({
      success: true,
      data: logs,
      count: logs.length,
    });
  } catch (error) {
    console.error('Error fetching entity audit logs:', error);
    return c.json({
      success: false,
      error: 'Failed to fetch entity audit logs',
      details: error.message,
    }, 500);
  }
});

/**
 * GET /make-server-6d108759/audit/logs/action/:action
 * Get audit logs by action type
 */
app.get('/make-server-6d108759/audit/logs/action/:action', async (c) => {
  try {
    const action = c.req.param('action') as AuditAction;
    const limit = Number(c.req.query('limit')) || 50;
    
    const logs = await getAuditLogsByAction(action, limit);
    
    return c.json({
      success: true,
      data: logs,
      count: logs.length,
    });
  } catch (error) {
    console.error('Error fetching audit logs by action:', error);
    return c.json({
      success: false,
      error: 'Failed to fetch audit logs by action',
      details: error.message,
    }, 500);
  }
});

/**
 * GET /make-server-6d108759/audit/logs/date-range
 * Get audit logs within a date range
 */
app.get('/make-server-6d108759/audit/logs/date-range', async (c) => {
  try {
    const startDate = c.req.query('startDate');
    const endDate = c.req.query('endDate');
    const limit = Number(c.req.query('limit')) || 100;
    
    if (!startDate || !endDate) {
      return c.json({
        success: false,
        error: 'startDate and endDate query parameters are required',
      }, 400);
    }
    
    const logs = await getAuditLogsByDateRange(startDate, endDate, limit);
    
    return c.json({
      success: true,
      data: logs,
      count: logs.length,
    });
  } catch (error) {
    console.error('Error fetching audit logs by date range:', error);
    return c.json({
      success: false,
      error: 'Failed to fetch audit logs by date range',
      details: error.message,
    }, 500);
  }
});

/**
 * GET /make-server-6d108759/audit/stats
 * Get audit statistics
 */
app.get('/make-server-6d108759/audit/stats', async (c) => {
  try {
    const stats = await getAuditStats();
    
    return c.json({
      success: true,
      data: stats,
    });
  } catch (error) {
    console.error('Error fetching audit stats:', error);
    return c.json({
      success: false,
      error: 'Failed to fetch audit stats',
      details: error.message,
    }, 500);
  }
});

/**
 * DELETE /make-server-6d108759/audit/logs/cleanup
 * Clear old audit logs
 */
app.delete('/make-server-6d108759/audit/logs/cleanup', async (c) => {
  try {
    const daysToKeep = Number(c.req.query('daysToKeep')) || 90;
    
    // Only allow admin to clear logs (you should add auth middleware)
    const deletedCount = await clearOldAuditLogs(daysToKeep);
    
    return c.json({
      success: true,
      message: `Cleared ${deletedCount} old audit log entries`,
      deletedCount,
    });
  } catch (error) {
    console.error('Error clearing old audit logs:', error);
    return c.json({
      success: false,
      error: 'Failed to clear old audit logs',
      details: error.message,
    }, 500);
  }
});

/**
 * GET /make-server-6d108759/audit/actions
 * Get list of all audit actions
 */
app.get('/make-server-6d108759/audit/actions', async (c) => {
  try {
    const actions = Object.values(AuditAction);
    
    return c.json({
      success: true,
      data: actions,
    });
  } catch (error) {
    console.error('Error fetching audit actions:', error);
    return c.json({
      success: false,
      error: 'Failed to fetch audit actions',
      details: error.message,
    }, 500);
  }
});

/**
 * GET /make-server-6d108759/audit/entities
 * Get list of all entity types
 */
app.get('/make-server-6d108759/audit/entities', async (c) => {
  try {
    const entities = Object.values(EntityType);
    
    return c.json({
      success: true,
      data: entities,
    });
  } catch (error) {
    console.error('Error fetching entity types:', error);
    return c.json({
      success: false,
      error: 'Failed to fetch entity types',
      details: error.message,
    }, 500);
  }
});

export default app;
