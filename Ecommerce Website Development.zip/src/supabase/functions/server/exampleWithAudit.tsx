/**
 * Example Controller with Audit Logging
 * 
 * This file demonstrates how to integrate audit logging into your routes.
 * Copy this pattern to all your existing controllers.
 */

import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logAudit, AuditAction, EntityType } from './auditLogger.tsx';
import * as kv from './kv_store.tsx';

const app = new Hono();

app.use('*', cors({ origin: '*', credentials: true }));

/**
 * EXAMPLE: Product Creation with Audit Logging
 */
app.post('/make-server-6d108759/products', async (c) => {
  const request = c.req.raw;
  let userId: string | null = null;
  let userEmail: string | null = null;
  let userRole: string | null = null;
  
  try {
    // Get user info from auth token (your existing auth logic)
    const authHeader = request.headers.get('Authorization');
    // ... decode JWT and get user info ...
    
    // Get request body
    const body = await c.req.json();
    const { name, price, category } = body;
    
    // Create product
    const product = {
      id: crypto.randomUUID(),
      name,
      price,
      category,
      createdAt: new Date().toISOString(),
    };
    
    await kv.set(`product:${product.id}`, product);
    
    // LOG SUCCESS: Product created
    await logAudit({
      userId,
      userEmail,
      userRole,
      action: AuditAction.PRODUCT_ADD,
      entityType: EntityType.PRODUCT,
      entityId: product.id,
      entityName: product.name,
      details: {
        price: product.price,
        category: product.category,
      },
      request,
      success: true,
    });
    
    return c.json({ success: true, data: product });
    
  } catch (error) {
    // LOG FAILURE: Product creation failed
    await logAudit({
      userId,
      userEmail,
      userRole,
      action: AuditAction.PRODUCT_ADD,
      entityType: EntityType.PRODUCT,
      entityId: null,
      entityName: null,
      details: {
        attemptedData: await c.req.json().catch(() => ({})),
      },
      request,
      success: false,
      errorMessage: error.message,
    });
    
    return c.json({ success: false, error: error.message }, 500);
  }
});

/**
 * EXAMPLE: Product Update with Audit Logging
 */
app.put('/make-server-6d108759/products/:id', async (c) => {
  const request = c.req.raw;
  let userId: string | null = null;
  let userEmail: string | null = null;
  let userRole: string | null = null;
  
  try {
    const productId = c.req.param('id');
    const updates = await c.req.json();
    
    // Get existing product
    const existingProduct = await kv.get(`product:${productId}`);
    
    if (!existingProduct) {
      throw new Error('Product not found');
    }
    
    // Update product
    const updatedProduct = { ...existingProduct, ...updates };
    await kv.set(`product:${productId}`, updatedProduct);
    
    // LOG SUCCESS: Product updated
    await logAudit({
      userId,
      userEmail,
      userRole,
      action: AuditAction.PRODUCT_UPDATE,
      entityType: EntityType.PRODUCT,
      entityId: productId,
      entityName: updatedProduct.name,
      details: {
        previousValues: existingProduct,
        newValues: updates,
      },
      request,
      success: true,
    });
    
    return c.json({ success: true, data: updatedProduct });
    
  } catch (error) {
    // LOG FAILURE: Product update failed
    await logAudit({
      userId,
      userEmail,
      userRole,
      action: AuditAction.PRODUCT_UPDATE,
      entityType: EntityType.PRODUCT,
      entityId: c.req.param('id'),
      entityName: null,
      details: {},
      request,
      success: false,
      errorMessage: error.message,
    });
    
    return c.json({ success: false, error: error.message }, 500);
  }
});

/**
 * EXAMPLE: Product Delete with Audit Logging
 */
app.delete('/make-server-6d108759/products/:id', async (c) => {
  const request = c.req.raw;
  let userId: string | null = null;
  let userEmail: string | null = null;
  let userRole: string | null = null;
  
  try {
    const productId = c.req.param('id');
    
    // Get product before deleting (for audit log)
    const product = await kv.get(`product:${productId}`);
    
    if (!product) {
      throw new Error('Product not found');
    }
    
    // Delete product
    await kv.del(`product:${productId}`);
    
    // LOG SUCCESS: Product deleted
    await logAudit({
      userId,
      userEmail,
      userRole,
      action: AuditAction.PRODUCT_DELETE,
      entityType: EntityType.PRODUCT,
      entityId: productId,
      entityName: product.name,
      details: {
        deletedProduct: product,
      },
      request,
      success: true,
    });
    
    return c.json({ success: true, message: 'Product deleted' });
    
  } catch (error) {
    // LOG FAILURE: Product deletion failed
    await logAudit({
      userId,
      userEmail,
      userRole,
      action: AuditAction.PRODUCT_DELETE,
      entityType: EntityType.PRODUCT,
      entityId: c.req.param('id'),
      entityName: null,
      details: {},
      request,
      success: false,
      errorMessage: error.message,
    });
    
    return c.json({ success: false, error: error.message }, 500);
  }
});

/**
 * EXAMPLE: Login with Audit Logging
 */
app.post('/make-server-6d108759/auth/login', async (c) => {
  const request = c.req.raw;
  
  try {
    const { email, password } = await c.req.json();
    
    // Your login logic here...
    const user = await authenticateUser(email, password);
    
    if (!user) {
      // LOG FAILURE: Login failed
      await logAudit({
        userId: null,
        userEmail: email,
        userRole: null,
        action: AuditAction.LOGIN_FAILED,
        entityType: EntityType.USER,
        entityId: null,
        entityName: email,
        details: { reason: 'Invalid credentials' },
        request,
        success: false,
        errorMessage: 'Invalid email or password',
      });
      
      return c.json({ success: false, error: 'Invalid credentials' }, 401);
    }
    
    // LOG SUCCESS: Login successful
    await logAudit({
      userId: user.id,
      userEmail: user.email,
      userRole: user.role,
      action: AuditAction.LOGIN,
      entityType: EntityType.USER,
      entityId: user.id,
      entityName: user.email,
      details: {
        loginTime: new Date().toISOString(),
      },
      request,
      success: true,
    });
    
    return c.json({ success: true, data: user });
    
  } catch (error) {
    // LOG FAILURE: Login error
    await logAudit({
      userId: null,
      userEmail: null,
      userRole: null,
      action: AuditAction.LOGIN_FAILED,
      entityType: EntityType.USER,
      entityId: null,
      entityName: null,
      details: {},
      request,
      success: false,
      errorMessage: error.message,
    });
    
    return c.json({ success: false, error: error.message }, 500);
  }
});

/**
 * EXAMPLE: Employee Attendance Mark with Audit Logging
 */
app.post('/make-server-6d108759/attendance', async (c) => {
  const request = c.req.raw;
  let userId: string | null = null;
  let userEmail: string | null = null;
  
  try {
    const { employeeId, status } = await c.req.json();
    
    // Get employee info
    const employee = await kv.get(`employee:${employeeId}`);
    
    if (!employee) {
      throw new Error('Employee not found');
    }
    
    // Create attendance record
    const attendance = {
      id: crypto.randomUUID(),
      employeeId,
      date: new Date().toISOString().split('T')[0],
      status,
      checkIn: new Date().toISOString(),
    };
    
    await kv.set(`attendance:${attendance.id}`, attendance);
    
    // LOG SUCCESS: Attendance marked
    await logAudit({
      userId: employeeId,
      userEmail: employee.email,
      userRole: 'EMPLOYEE',
      action: AuditAction.ATTENDANCE_MARK,
      entityType: EntityType.ATTENDANCE,
      entityId: attendance.id,
      entityName: `${employee.name} - ${status}`,
      details: {
        employeeId,
        employeeName: employee.name,
        status,
        date: attendance.date,
        checkIn: attendance.checkIn,
      },
      request,
      success: true,
    });
    
    return c.json({ success: true, data: attendance });
    
  } catch (error) {
    // LOG FAILURE: Attendance marking failed
    await logAudit({
      userId,
      userEmail,
      userRole: 'EMPLOYEE',
      action: AuditAction.ATTENDANCE_MARK,
      entityType: EntityType.ATTENDANCE,
      entityId: null,
      entityName: null,
      details: {},
      request,
      success: false,
      errorMessage: error.message,
    });
    
    return c.json({ success: false, error: error.message }, 500);
  }
});

// Dummy auth function for example
async function authenticateUser(email: string, password: string) {
  // Your actual authentication logic
  return null;
}

export default app;
