# ⚡ Quick Reference Card

## 🚀 Start Everything

```bash
# Terminal 1: Backend
cd backend
npm run dev

# Terminal 2: Frontend  
npm start

# Terminal 3: Database GUI
cd backend
npm run prisma:studio
```

**URLs:**
- Frontend: http://localhost:3000
- Backend API: http://localhost:5000
- Database GUI: http://localhost:5555

---

## 🔐 Default Logins

```
Admin:
  📧 admin@shophub.com
  🔑 admin123

Seller:
  📧 test@seller.com
  🔑 seller123
```

---

## 📡 API Base URL

```javascript
const API_URL = 'http://localhost:5000/api';
```

---

## 🔑 Common API Calls

### Authentication
```bash
# Login
POST /api/auth/login
Body: { "email": "admin@shophub.com", "password": "admin123" }

# Register
POST /api/auth/register
Body: { "name": "John", "email": "john@test.com", "password": "pass123" }
```

### Products
```bash
# Get all
GET /api/products

# Get one
GET /api/products/:id

# Create (needs auth)
POST /api/products
Headers: Authorization: Bearer <token>
Body: { "name": "Product", "price": 999, ... }
```

### Cart
```bash
# Add to cart (needs auth)
POST /api/cart/add
Headers: Authorization: Bearer <token>
Body: { "productId": "uuid", "quantity": 1 }
```

---

## 💾 Database Commands

```bash
# View database GUI
npm run prisma:studio

# Reset database (⚠️ deletes all data)
npx prisma migrate reset

# Run migrations
npm run prisma:migrate

# Seed data
npm run seed

# Generate Prisma client
npm run prisma:generate
```

---

## 🔍 Debug Commands

```bash
# Check if backend is running
curl http://localhost:5000/api/health

# Check PostgreSQL
psql -U postgres -l

# Kill port 5000
lsof -i :5000
kill -9 <PID>

# Kill port 3000
lsof -i :3000
kill -9 <PID>
```

---

## 📂 Important Files

```
Frontend:
  /App.tsx                    - Main app
  /context/AuthContext.tsx    - Auth state
  /context/ProductContext.tsx - Products state
  /utils/api.ts              - API client (create this!)

Backend:
  /backend/src/server.ts      - Server entry
  /backend/.env               - Environment vars
  /backend/prisma/schema.prisma - Database schema
```

---

## 🐛 Quick Fixes

### "Can't connect to database"
```bash
# Start PostgreSQL
sudo service postgresql start
```

### "Port already in use"
```bash
# Backend (5000)
lsof -i :5000 && kill -9 <PID>

# Frontend (3000)
lsof -i :3000 && kill -9 <PID>
```

### "Prisma Client not found"
```bash
cd backend
npm run prisma:generate
```

### "CORS Error"
```bash
# Check backend/.env
FRONTEND_URL=http://localhost:3000
```

---

## 📦 Install Dependencies

```bash
# Frontend
npm install axios

# Backend
cd backend
npm install
```

---

## 🔄 Update Context to Use API

### Pattern for all contexts:

```typescript
// 1. Import API
import api from '../utils/api';

// 2. Replace LocalStorage with API calls
const fetchData = async () => {
  const response = await api.get('/endpoint');
  setData(response.data);
};

// 3. Add useEffect to fetch on mount
useEffect(() => {
  fetchData();
}, []);
```

---

## 🧪 Test Endpoints

```bash
# cURL examples

# Health check
curl http://localhost:5000/api/health

# Login (save token from response)
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@shophub.com","password":"admin123"}'

# Get products
curl http://localhost:5000/api/products

# Create product (replace YOUR_TOKEN)
curl -X POST http://localhost:5000/api/products \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{"name":"Test","price":999,"category":"Electronics","brand":"Test","image":"https://via.placeholder.com/400","description":"Test product","stock":10}'
```

---

## 🎨 Frontend Integration Steps

1. ✅ Install axios: `npm install axios`
2. ✅ Create `/utils/api.ts`
3. ✅ Update `AuthContext.tsx`
4. ✅ Update `ProductContext.tsx`
5. ✅ Update `CartContext.tsx`
6. ✅ Update `OrderContext.tsx`
7. ✅ Update `SellerContext.tsx`
8. ✅ Update `EmployeeContext.tsx`
9. ✅ Test login
10. ✅ Test all features

---

## 🗂 File Structure

```
/
├── components/          # React components
├── context/            # State management (UPDATE THESE)
├── utils/              # API client (CREATE THIS)
├── backend/            # Backend server (NEW)
│   ├── src/           # Source code
│   ├── prisma/        # Database
│   └── .env           # Config
└── docs/              # All .md files
```

---

## 🔒 Environment Variables

### Frontend `.env`
```env
REACT_APP_API_URL=http://localhost:5000/api
```

### Backend `.env`
```env
DATABASE_URL="postgresql://postgres:password@localhost:5432/shophub"
JWT_SECRET="your-secret-key"
PORT=5000
FRONTEND_URL="http://localhost:3000"
```

---

## 📊 Database Tables

- `users` - User accounts
- `products` - Product catalog
- `sellers` - Seller info
- `orders` - Orders
- `order_items` - Order details
- `cart_items` - Shopping cart
- `employees` - Employee records
- `attendance` - Attendance tracking

---

## 🎯 Testing Checklist

- [ ] PostgreSQL running
- [ ] Backend server running (port 5000)
- [ ] Frontend running (port 3000)
- [ ] Can login as admin
- [ ] Products load from API
- [ ] Can add to cart
- [ ] Can create order
- [ ] Admin panel works
- [ ] Seller dashboard works
- [ ] Employee management works

---

## 📞 Help

**Documentation:**
- README.md
- backend/README.md
- BACKEND_INTEGRATION.md
- FULL_STACK_SUMMARY.md
- TROUBLESHOOTING.md

**Debug Tools:**
- Browser DevTools → Network tab
- Browser DevTools → Console
- Prisma Studio (http://localhost:5555)
- Postman for API testing

---

## 💡 Remember

- Backend must be running for frontend to work
- Login first to test protected routes
- Check Network tab for API errors
- Use Prisma Studio to view database
- Save JWT token for API testing

---

**Quick Tip:** Keep this file open while developing! 🚀
