# 🔧 ShopHub Troubleshooting Guide

## Common Issues & Solutions

### 1. **Seller Cannot Add Products**

**Problem:** After logging in as seller, I don't see the "Add Product" button or it's not working.

**Solutions:**
- ✅ Check if your seller account is approved by admin
- ✅ Login as admin (`admin@shophub.com` / `admin123`)
- ✅ Go to Admin Dashboard → Sellers tab
- ✅ Find your seller account and click "Approve"
- ✅ Logout and login again as seller

**Demo Seller (Pre-approved):**
- Email: `test@seller.com`
- Password: `seller123`

---

### 2. **Category Not Showing Products**

**Problem:** When I click on a category on the homepage, products don't filter correctly.

**Solutions:**
✅ **This is already implemented!** Categories work as follows:
1. Homepage → Click any category card (Electronics, Fashion, etc.)
2. It automatically redirects to Products page with search filter
3. Products matching that category are displayed

**How it works:**
```javascript
// When category is clicked:
onClick={() => {
  onSearch(category);      // Sets search query to category name
  onPageChange('products'); // Navigates to products page
}}

// ProductList filters by:
- Category name match
- Product name match
- Description match
```

**Test it:**
- Go to homepage
- Click "Electronics" category
- You'll see only electronics products

---

### 3. **Cannot Add More Than 30 Items to Cart**

**Problem:** The plus button is disabled in cart.

**Solution:**
✅ **This is intentional!** Maximum quantity limit is 30 per product.

**Why?**
- Prevents bulk buying
- Ensures fair distribution
- Prevents cart abuse

**What happens:**
- At 29 items: Plus button works
- At 30 items: 
  - Plus button becomes disabled
  - Shows "Max limit reached" message
  - Toast notification if you try to add more

**Workaround:** None - this is a business rule!

---

### 4. **Admin Panel Not Accessible**

**Problem:** I can't see the Admin button or access admin panel.

**Solutions:**
✅ **Login with admin credentials:**
- Email: `admin@shophub.com`
- Password: `admin123`

✅ **Check if you're logged in:**
- Look for user name in header
- If not logged in, click "Login" button

✅ **Verify role:**
- Admin button only shows for admin users
- Customer accounts won't see it

---

### 5. **Products Not Appearing in Category**

**Problem:** I added a product but it doesn't show in its category.

**Solutions:**
✅ **Verify product details:**
1. Go to Admin/Seller Dashboard → Products
2. Check the product's category field
3. Ensure category name matches exactly:
   - Electronics (not electronic or electronics)
   - Fashion (not fashion wear)
   - Home (not home decor)
   - Sports (not sports wear)
   - Beauty (not beauty products)
   - Books (not book)

✅ **Case sensitivity:**
- Categories are case-sensitive
- Use exact capitalization as shown above

✅ **Refresh page:**
- Products are cached in LocalStorage
- Hard refresh: `Ctrl + Shift + R` (Windows) or `Cmd + Shift + R` (Mac)

---

### 6. **Employee Attendance Not Saving**

**Problem:** Attendance marks disappear after page refresh.

**Solutions:**
✅ **This shouldn't happen** - attendance is saved to LocalStorage.

**If it does happen:**
1. Check browser console for errors (F12)
2. Verify LocalStorage is not disabled
3. Clear browser cache and try again:
   ```
   localStorage.clear()
   ```
4. Refresh page and re-mark attendance

✅ **Cannot mark attendance twice:**
- Attendance can only be marked once per day per employee
- If already marked, you'll see the status badge
- To change: Contact admin or modify in browser console (dev tool)

---

### 7. **Seller Dashboard Shows "Account Pending"**

**Problem:** After registering as seller, I see "Account Pending Approval" message.

**Solution:**
✅ **This is expected behavior!**

**Steps to approve:**
1. Logout from seller account
2. Login as admin (`admin@shophub.com` / `admin123`)
3. Go to Admin Dashboard
4. Click "Sellers" tab
5. Find your seller entry (status: Pending)
6. Click "Approve" button
7. Logout and login as seller again
8. You can now access full dashboard

**Bypass (For Testing):**
Use the pre-approved seller account:
- Email: `test@seller.com`
- Password: `seller123`

---

### 8. **Payroll Calculation Seems Wrong**

**Problem:** Employee salary doesn't match expectations.

**Understanding the Calculation:**

```
Formula:
Daily Rate = Monthly Salary ÷ Days in Month
Working Days = Present + (Half-Day × 0.5)
Payable Salary = Daily Rate × Working Days
```

**Example:**
```
Employee: John Doe
Base Salary: ₹50,000
Month: January (31 days)
Daily Rate: ₹50,000 ÷ 31 = ₹1,612.90

Attendance:
- Present: 20 days
- Half-Day: 2 days → counts as 1 day
- Absent: 9 days → ₹0

Working Days: 20 + 1 = 21 days
Payable: ₹1,612.90 × 21 = ₹33,870.97
```

**Troubleshooting:**
✅ Count attendance entries for the month
✅ Verify present + half-day count
✅ Check if correct month/year selected
✅ Leaves are treated as absent (no pay)

---

### 9. **Images Not Loading**

**Problem:** Product images show broken image icon or don't load.

**Solutions:**
✅ **Image URLs must be valid:**
- Use full URLs starting with `http://` or `https://`
- Unsplash images work: `https://images.unsplash.com/...`
- Local file paths won't work in browser

✅ **Using Unsplash:**
```
Good: https://images.unsplash.com/photo-xxx
Bad:  /images/product.jpg
Bad:  C:\images\product.jpg
```

✅ **Test image URL:**
- Copy image URL
- Paste in new browser tab
- If it loads there, it will work in app

✅ **Fallback system:**
- App uses ImageWithFallback component
- Shows placeholder if image fails
- No broken image icons

---

### 10. **Cart Total Calculation Wrong**

**Problem:** Cart total doesn't match expected amount.

**Understanding Calculation:**

```
Subtotal = Sum of (Price × Quantity) for all items

Shipping:
- If Subtotal > ₹500: Free (₹0)
- If Subtotal ≤ ₹500: ₹99

Tax = Subtotal × 10% (0.1)

Total = Subtotal + Shipping + Tax
```

**Example:**
```
Item 1: ₹1,000 × 2 = ₹2,000
Item 2: ₹500 × 1 = ₹500
Subtotal: ₹2,500

Shipping: ₹0 (over ₹500)
Tax: ₹2,500 × 0.1 = ₹250

Total: ₹2,500 + ₹0 + ₹250 = ₹2,750
```

**Troubleshooting:**
✅ Check individual item prices
✅ Verify quantities
✅ Confirm shipping calculation (₹500 threshold)
✅ Tax is 10% of subtotal (not total)

---

### 11. **LocalStorage Full / Data Loss**

**Problem:** Getting errors or data disappearing.

**Solutions:**
✅ **LocalStorage has limits:**
- Typically 5-10MB per domain
- Can fill up with lots of products/orders

✅ **Clear data:**
```javascript
// Open browser console (F12)
localStorage.clear()
// Refresh page
```

✅ **Selective clear:**
```javascript
// Clear only specific data
localStorage.removeItem('cart')
localStorage.removeItem('orders')
// Keep sellers, employees, products
```

✅ **Export data first:**
```javascript
// Backup before clearing
const backup = {
  cart: localStorage.getItem('cart'),
  orders: localStorage.getItem('orders'),
  // ... other keys
};
console.log(JSON.stringify(backup));
// Copy from console and save to file
```

---

### 12. **Cannot Login / Invalid Credentials**

**Problem:** Login fails with correct credentials.

**Solutions:**
✅ **Double-check credentials:**

**Admin:**
- Email: `admin@shophub.com` (exactly)
- Password: `admin123`

**Seller:**
- Email: `test@seller.com`
- Password: `seller123`

**Customer:**
- Create new account via Sign Up tab

✅ **Common mistakes:**
- Extra spaces before/after email
- Wrong capitalization (email is case-sensitive in this demo)
- Using wrong role credentials

✅ **Reset:**
```javascript
// Clear user session
localStorage.removeItem('user')
// Refresh and try again
```

---

### 13. **Commission Not Calculating**

**Problem:** Seller dashboard shows wrong commission/earnings.

**Calculation:**
```
Platform Commission = Total Sales × (Commission % ÷ 100)
Seller Earnings = Total Sales - Platform Commission
```

**Example:**
```
Total Sales: ₹10,000
Commission Rate: 15%

Platform Fee: ₹10,000 × 0.15 = ₹1,500
Your Earnings: ₹10,000 - ₹1,500 = ₹8,500
```

**Notes:**
✅ Commission set by admin
✅ Default is 15%
✅ Can vary per seller
✅ Only counts completed orders

---

### 14. **Responsive Design Issues**

**Problem:** Layout breaks on mobile/tablet.

**Solutions:**
✅ **Supported breakpoints:**
- Mobile: < 768px
- Tablet: 768px - 1023px
- Desktop: 1024px+

✅ **Test responsive:**
- Press F12 to open DevTools
- Click device toolbar icon (phone/tablet icon)
- Select device or drag to resize

✅ **Known issues:**
- Very small screens (< 320px): May have slight overflow
- Landscape mode on tablets: Use portrait for best experience

✅ **Browser zoom:**
- Reset zoom to 100%
- Some browsers cache zoom level

---

## 🚀 Performance Issues

### Slow Loading
✅ **Solutions:**
- Clear browser cache
- Reduce number of products (if too many added)
- Check internet connection (for images)
- Disable browser extensions
- Use incognito mode to test

### Memory Issues
✅ **Solutions:**
- Clear LocalStorage periodically
- Don't add thousands of products
- Close other tabs
- Restart browser

---

## 🆘 Emergency Reset

**Nuclear Option - Reset Everything:**

```javascript
// Open Console (F12)
localStorage.clear();
location.reload();
```

This will:
- ❌ Delete all data
- ❌ Remove all orders
- ❌ Clear cart
- ✅ Reset to initial state
- ✅ Default products restored
- ✅ Demo seller restored

---

## 📞 Still Having Issues?

### Debug Checklist:
1. ✅ Browser console errors (F12 → Console)
2. ✅ Browser: Chrome, Firefox, Edge (latest)
3. ✅ JavaScript enabled
4. ✅ LocalStorage enabled
5. ✅ No browser extensions interfering
6. ✅ Cache cleared
7. ✅ Page refreshed (hard refresh)

### Browser Console Commands:
```javascript
// Check current user
console.log(JSON.parse(localStorage.getItem('user')));

// Check sellers
console.log(JSON.parse(localStorage.getItem('sellers')));

// Check cart
console.log(JSON.parse(localStorage.getItem('cart')));

// Check products
console.log(JSON.parse(localStorage.getItem('products')));

// Check all keys
console.log(Object.keys(localStorage));
```

---

## 🎓 Understanding Error Messages

### "Please fill all required fields"
- Check form for empty fields
- Required fields have red asterisk (*)

### "Maximum quantity limit is 30"
- You're trying to add more than 30 items
- This is by design

### "Product added successfully!"
- This is success, not error!
- Product was added to database

### "Seller account pending approval"
- Your seller registration needs admin approval
- Login as admin to approve

### "No products found"
- Search query has no matches
- Try different search terms
- Or browse all products (clear search)

---

**💡 Pro Tip:** Most issues can be solved by:
1. Logging out
2. Clearing cache
3. Hard refresh (Ctrl + Shift + R)
4. Logging in again

---

**Need more help? Check the other documentation files:**
- `README.md` - Overview
- `SETUP_GUIDE.md` - Installation
- `ARCHITECTURE.md` - How it works
- `FEATURES.md` - Complete features list
