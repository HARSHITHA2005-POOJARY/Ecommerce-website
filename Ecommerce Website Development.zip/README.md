
  # Ecommerce Website Development

  This is a code bundle for Ecommerce Website Development. The original project is available at https://www.figma.com/design/8KLInpGusZurp4pQV1OqPp/Ecommerce-Website-Development.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  